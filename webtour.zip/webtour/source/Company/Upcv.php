<?php
    // kiểm tra chưa có session thì về login
    session_start();
    if(!isset($_SESSION["company_id"])){
        $login_page = '../Login/login.php';
        // include('final web/User/index.php');
        header("Location: $login_page");
        exit;
    }
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link  href = "../style.css" rel = "stylesheet"> 
    
    <!-- font -->
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@1,700&family=Tilt+Warp&display=swap" rel="stylesheet">
    <!-- icons -->
    
    <link href=" https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" rel = "stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <title> Choose A Job, Decide Your Future</title>
    <style>
    
        .card {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            width: 270px;
            height: 400px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            overflow: hidden;
        }
        .card-image {
            height:40%;
        }
        .card-image img {
        width: 100%;
        height: 100%;

        object-fit: cover;
        }
    
    </style>
</head>
<body class = "bg-light">
    <?php include("header.php");?>
    
    <div class="container-fluid" style="height: auto; margin-bottom: 40px;">
        
        <section class = "p-5" style="margin-top: 30px;">
            <div class = "container">
            <br>
                <div id="showJob" class = "row text-center g-4" action="">
                    
                <?php
                    require_once "../Login/database.php";
                    $idcty = $_SESSION["company_id"];
                    $sql = "SELECT * FROM DangViec where ID_CTY = $idcty";

                    // Thực hiện truy vấn và lưu kết quả vào biến $result
                    $result = $conn->query($sql);

                    // Kiểm tra số lượng bản ghi trả về có lớn hơn 0 hay không
                    if ($result->num_rows > 0) {
                    // Lặp qua từng bản ghi và in ra dữ liệu
                    while($row = $result->fetch_assoc()) {
                        //echo "ID: " . $row["ID_CTY"] . " - Name: " . $row["TenCTY"] . " - Email: " . $row["diachi"] . "<br>";
                            $image = "../image/ig".$row["ID_CTY"].".png";
                            $luong = number_format($row["Luong"], 0, ",", ".") . " VND";
                            echo 
                                '<div class="ctitem col-xs-12 col-lg-3 col-md-6 col-sm-6">
                                    <div class="card">
                                        <div class="card-image">
                                            <img src="' . $image . '">
                                        </div>
                                        <div class="card-content">
                                            <h3 class="card-title">' . $row["Tencongviec"] .  '</h3>
                                            <p><i class="fa-solid fa-location-dot"></i> '. $row["Diachi"] . '</p>
                                            <p><i class="fa-solid fa-money-bill"></i>'.$luong.'</p>
                                            <p><i class="fa-solid fa-briefcase"></i> '.$row["soluongtuyen"].' vị trí đang tuyển</p>
                                        </div>
                                
                                        <div class="card-action">
                                            <a class="mx-2 btn btn-primary"href="EditUpcv.php?idbaidang='.$row["ID_Dangviec"].'" >Sửa</a>
                                            <a class="btn btn-secondary" href="detail.php?idbaidang='.$row["ID_Dangviec"].'" >Detail</a>
                                            <a class="mx-2 btn btn-warning" onclick="xoabaidang('.$row["ID_Dangviec"].')" >Xóa</a>
                                        </div>  
                                    </div>
                                </div>';
                            }
                        
                    }
                    // } else {
                    // echo "0 results";
                    // }

                ?>  

                </div>
                <br><br>
            
            </div>
            <div id="pagination-container"></div>
        </section>
        
    </div>
    
</div>
    
<script>
    function xoabaidang(idbaidang){
        Swal.fire({
            title: 'Warning',
            text: "Bạn có chắc muốn xóa bài đăng này!",
            icon: 'warning',
            showCancelButton: true,
            cancelButtonColor: '#d33',
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'OK!'
          }).then(function(result){
            if (result.isConfirmed) {
                $.ajax({
                url: "../Controllers/C_dangbai.php",
                type: "post",
                data: {idbaidang,type:-1},
                success: function(data){
                    console.log(data)
                    const res = JSON.parse(data);
                    if (res.status ==1 ){
                                  Swal.fire({
                        title: 'Success',
                        text: "Xóa thành công!",
                        icon: 'success',
                        showCancelButton: false,
                        // cancelButtonColor: '#d33',
                        confirmButtonColor: '#3085d6',
                        confirmButtonText: 'OK!'
                    })
                    
                                }
                            }
                })
            }
          })
    }
</script>

    <!-- footer -->
   
    <style>
        a {
            color: #BCBABE;
        }
        strong{
            color: #BCBABE;
        }
    </style>
    <footer class="bg-dark text-white pt-5 pb4">

        <div class = "container text-center text-md-left">

            <div class =" row text-center g-4 text-md-left">
                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>About</h3><br>
                        
                        <p><a href="#" >our services</a></li>
                        <p><a href="#" >privacy policy</a></li>
                        <p><a href="#" >affiliate program</a></li>
                    

                </div>

                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>Company</h3><br>
                        <p><a href="#" >about us</a></li>
                        <p><a href="#" >our services</a></li>
                        <p><a href="#" >privacy policy</a></li>
                </div>
                

                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3 >Get Help</h3><br>
                    
                        <p><a href="#" >FAQ</a></li>
                        <p><a href="#" >Contact</a></li>
        
                </div>
                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>follow us</h3><br>
                    <div class="social-links">
                        <a href="#" ><i class="fab fa-facebook-f"></i></a>
                        <a href="#" ><i class="fab fa-twitter"></i></a>
                        <a href="#" ><i class="fab fa-instagram"></i></a>
                        <a href="#" ><i class="fab fa-linkedin-in"></i></a>
                    </div>

                </div>
                
            </div>

            <hr class="mb-4">
            <div class="row align-items-center">
                <div class="col-md-7 col-lg-8">
                    <b>Copyright @2022 All rights reserved by:
                        <a href=""# style="text-decoration: none;">
                            <strong class=" text-white">Pham Company</strong>
                        </a>
                    </b>
                    <p style="font-size: medium; color:#BCBABE;"> Contact: Ho Chi Minh:(+84) 0965323966 - Email: PhamCompany@gmail.com</li>
                    
                </div>
                
            </div>
            
        </div>

    </footer>

</body>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>