<?php
    // kiểm tra chưa có session thì về login
    session_start();
    if(!isset($_SESSION["company_id"])){
        $login_page = '../Login/login.php';
        // include('final web/User/index.php');
        header("Location: $login_page");
        exit;
    }
    $idbaidang = 1;
    if (isset($_GET["idbaidang"]))
        $idbaidang = $_GET["idbaidang"];
    require("../Login/database.php");
    $sql = "SELECT * FROM DangViec where ID_Dangviec = $idbaidang";
    $result = $conn->query($sql);
    $row2 = $result->fetch_assoc();
    // var_dump($row);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link  href = "../style.css" rel = "stylesheet"> 
    
    <!-- font -->
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@1,700&family=Tilt+Warp&display=swap" rel="stylesheet">
    <!-- icons -->
    
    <link href=" https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" rel = "stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <title> Choose A Job, Decide Your Future</title>
</head>
<body class = "bg-light">
    <?php include("header.php");?>
    
    <div class="container" style="height: 1000px;">
        <form id="suabaituyendung" action="../Controllers/C_dangbai.php" method="post" class="row g-3" style="margin-top: 100px;">
             <div style="text-align: center;">
                <h3 > Sửa bài đăng</h3>
             </div>
            <!-- <div class="row g-2 mt-3">
                <div class="col-12">
                    <label for="formFile" class="form-label">Hình ảnh công ty</label>
                    <input class="form-control" type="file" id="formFile">
                  </div>  
            </div> -->
            <div class="row g-2 mt-3">
              <div class="col-4">
                <label for="exampleFormControlTextarea1" class="form-label">Tên Công Việc</label>
                    <input value="<?php echo $row2["Tencongviec"] ?>" name="tencongviec" class="form-control" type="text" aria-label="default input example">
              </div>
              <div class="col-4">
                <label for="exampleFormControlTextarea1" class="form-label">Lương</label>
                    <input value="<?php echo $row2["Luong"] ?>" name="luong" class="form-control" type="text" aria-label="default input example">
              </div>
              <div class="col-4">
                <label for="exampleFormControlTextarea1" class="form-label">Chức Vụ</label>
                    <input value="<?php echo $row2["Chucvu"] ?>" name="chucvu" class="form-control" type="text" aria-label="default input example">
              </div>
            </div>

            <div class="row g-2 mt-3">
                <div class="form-group col-sm-4">
                    <label for="linhvuc">Lĩnh vực</label>
                    <select name="linhvuc" class="form-control" id="linhvuc">
                        <option value="<?php echo $row2["Linhvuc"] ?>"><?php echo $row2["Linhvuc"] ?></option>
                        <option>Công nghệ thông tin</option>
                        <option>Viễn thông</option>
                        <option>Marketing / Truyền thông / Quảng cáo</option>
                        <option>Nhà hàng / Khách sạn</option>
                        <option>Thời trang</option>
                        <option>Internet / Online</option>
                        <option>Bất động sản</option>
                        <option>Dược phẩm / Y tế / Công nghệ sinh học</option>
                        <option>Kế toán / Kiểm toán</option>
                        <option>Kinh doanh</option>
                        <option>Giáo dục</option>
                        <option>Văn phòng</option>
                        <option>Bảo hiểm</option>
                        <option>Luật</option>
                        <option>Giải trí</option>
                        <option>Agency</option>
                        <option>Tài chính / Ngân Hàng</option>
                        <option>Khác</option>
                    </select>
                </div>
                <div class="col-4">
                  <label for="exampleFormControlTextarea1" class="form-label">Email</label>
                    <input value="<?php echo $row2["Email"] ?>" name="email" class="form-control" type="text" aria-label="default input example">
                </div>
                <div class="form-group col-sm-4">
                    <label for="loaicv">Loại công việc</label>
                    <select name="loaicongviec" class="form-control" id="loaicv" required>
                        <option value="<?php echo $row2["Loaicongviec"] ?>"><?php if ($row2["Loaicongviec"]==1) echo "Toàn thời gian"; else echo "Bán thời gian";  ?></option>
                        <option value="1" >Toàn thời gian</option>
                        <option value="0" >Bán thời gian</option>
                    </select>
                </div>
            </div>

            <div class="row g-2 mt-3">
                <div class="col-12">
                    <label for="exampleFormControlTextarea1" class="form-label">Mô Tả Công Việc</label>
                    <textarea value="<?php echo $row2["Mota"] ?>" name="mota" class="form-control" id="exampleFormControlTextarea1" rows="2"></textarea>
                </div>       
            </div>

            <div class="row g-2 mt-3">
                <div class="col-6">
                    <label for="exampleFormControlTextarea1" class="form-label">Địa Chỉ</label>
                    <textarea value="<?php echo $row2["Diachi"] ?>" rows="1" name="diachi" class="form-control" type="text" aria-label="default input example"></textarea>
                </div>    
                <div class="col-3">
                    <label for="sdt">Số điện thoại</label>
                    <input value="<?php echo $row2["SDT"] ?>" name="sdt" class="form-control" type="number"q>
                </div>
                <div class="col-3">
                    <label for="soluongtuyen">Số lượng tuyển</label>
                    <input value="<?php echo $row2["soluongtuyen"] ?>" name="soluongtuyen" class="form-control" type="number"q>
                </div>
            </div>

            <div class="row g-2 mt-3">
                <div class="col-6">
                    <label for="exampleFormControlTextarea1" class="form-label">Kỹ Năng</label>
                    <textarea value="<?php echo $row2["Kynang"] ?>" name="kynang" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                </div>
                <div class="col-6">
                    <label for="exampleFormControlTextarea1" class="form-label">Yêu Cầu</label>
                    <textarea value="<?php echo $row2["Yeucau"] ?>" name="yeucau" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                  </div>  
            </div>

            <div class="row g-2 mt-3">
                <div class="col-12">
                    <label for="exampleFormControlTextarea1" class="form-label">Phúc Lợi Và Quyền Lợi</label>
                    <textarea value="<?php echo $row2["Quyenloi"] ?>" name="quyenloi" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                </div>
                   
            </div>

            <div class="row g-2 mt-3">
                <div class="col-12 text-center">
                    <button type="submit" class="btn btn-dark" >Sửa bài</button>
                </div>
            </div>
        </form>
    </div>
    

    <!-- footer -->
   
    <style>
        a {
            color: #BCBABE;
        }
        strong{
            color: #BCBABE;
        }
    </style>
    <footer class="bg-dark text-white pt-5 pb4">

        <div class = "container text-center text-md-left">

            <div class =" row text-center g-4 text-md-left">
                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>About</h3><br>
                        
                        <p><a href="#" >our services</a></li>
                        <p><a href="#" >privacy policy</a></li>
                        <p><a href="#" >affiliate program</a></li>
                    

                </div>

                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>Company</h3><br>
                        <p><a href="#" >about us</a></li>
                        <p><a href="#" >our services</a></li>
                        <p><a href="#" >privacy policy</a></li>
                </div>
                

                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3 >Get Help</h3><br>
                    
                        <p><a href="#" >FAQ</a></li>
                        <p><a href="#" >Contact</a></li>
        
                </div>
                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>follow us</h3><br>
                    <div class="social-links">
                        <a href="#" ><i class="fab fa-facebook-f"></i></a>
                        <a href="#" ><i class="fab fa-twitter"></i></a>
                        <a href="#" ><i class="fab fa-instagram"></i></a>
                        <a href="#" ><i class="fab fa-linkedin-in"></i></a>
                    </div>

                </div>
                
            </div>

            <hr class="mb-4">
            <div class="row align-items-center">
                <div class="col-md-7 col-lg-8">
                    <b>Copyright @2022 All rights reserved by:
                        <a href=""# style="text-decoration: none;">
                            <strong class=" text-white">Pham Company</strong>
                        </a>
                    </b>
                    <p style="font-size: medium; color:#BCBABE;"> Contact: Ho Chi Minh:(+84) 0965323966 - Email: PhamCompany@gmail.com</li>
                    
                </div>
                
            </div>
            
        </div>

    </footer>

<script>
    $("form#suabaituyendung").on("submit", function(e) {
        e.preventDefault();
        let form_data = $(this).serialize();
        console.log(form_data);
        $.ajax({
            url: $(this).attr("action"), // Đường dẫn xử lý form
            method: $(this).attr("method"), // Phương thức gửi dữ liệu
            data: {data: form_data,type:1,idbaidang: <?php echo $idbaidang; ?>}, // Dữ liệu gửi đi
            success: function(response) {
                console.log(response)
                const res = JSON.parse(response)
                console.log(res);
                if (res.status ==1){
                    Swal.fire({
                        title: 'Success',
                        text: "Sửa bài thành công!",
                        icon: 'success',
                        showCancelButton: false,
                        // cancelButtonColor: '#d33',
                        confirmButtonColor: '#3085d6',
                        confirmButtonText: 'OK!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                        // Xử lý khi người dùng chọn OK
                        window.location.href = "Upcv.php"
                        }
                    })
                } else 
                    Swal.fire({
                        title: 'warning',
                        text: res.message,
                        icon: 'warning',
                        showCancelButton: false,
                        // cancelButtonColor: '#d33',
                        confirmButtonColor: '#3085d6',
                        confirmButtonText: 'OK!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                        // Xử lý khi người dùng chọn OK
                        console.log("that bai")
                        }
                    })
            },
            error: function(xhr, textStatus, errorThrown) {
                // Xử lý lỗi nếu có
                console.log(xhr.textStatus);
            }
        })
    })
</script>

</body>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>