<?php
    require("../Login/database.php");
    $id = $_SESSION["company_id"];
    $sql = "SELECT * FROM CONGTY where ID_CTY = '$id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
?>
    <!-- jquery -->
    <script src="https://code.jquery.com/jquery-3.6.4.slim.min.js" integrity="sha256-a2yjHM4jnF9f54xUQakjZGaqYs/V1CYvWpoqZzC2/Bw=" crossorigin="anonymous"></script>
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <!-- Nhúng sweetalert2 từ CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <header>
        <nav class = "navbar navbar-expand-md bg">
            <a style="text-decoration: none;" href="" class = "narbar-brand fs-3 ms-5 text-white" >ITCompany</a>

            <button class="navbar-toggler me-3 text-white" type="button" data-bs-toggle="collapse" data-bs-target="#btn"><i class = 'bx bx-menu bx-md'></i></button>
            <div class="collapse navbar-collapse ul-bg" id="btn">
            <ul class="navbar-nav ms-auto" >
                    
                    <li class = "nav-item">
                        <a href="Comhome.php"  class="nav-link mx-4 text-white fs-8">Đăng Tuyển</a>
                    </li>
                    <li class = "nav-item">
                        <a href="Upcv.php"  class="nav-link mx-4 text-white fs-8">Bài Đăng</a>
                    </li>
                    <li class = "nav-item">
                        <a href="CV.php"  class="nav-link mx-4 text-white fs-8">Quản Lí Bài Đăng</a>
                    </li>
                    <li class = "nav-item">
                        <a href="Edithome.php"  class="nav-link mx-4 text-white fs-8">Quản Lí File CV</a>
                    </li>
                    <li class = "nav-item">
                        <a href="#"  class="nav-link mx-4 text-white fs-8"><?php echo $row["TenCTY"] ?></a>
                    </li>
                    <li class = "nav-item">
                        <a href="../Login/logout.php"  class="nav-link mx-4 text-white fs-8">Đăng Xuất</a>
                    </li>

                </ul>
            </div>
        </nav>  
    </header>