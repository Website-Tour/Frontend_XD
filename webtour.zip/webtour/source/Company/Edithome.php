<?php
    // kiểm tra chưa có session thì về login
    session_start();
    if(!isset($_SESSION["company_id"])){
        $login_page = '../Login/login.php';
        // include('final web/User/index.php');
        header("Location: $login_page");
        exit;
    }
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link  href = "../style.css" rel = "stylesheet"> 
    
    <!-- font -->
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@1,700&family=Tilt+Warp&display=swap" rel="stylesheet">
    <!-- icons -->
    
    <link href=" https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" rel = "stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <title> Choose A Job, Decide Your Future</title>
</head>
<body class = "bg-light">
    <?php include("header.php");?>
    
    <div id="main">
        <div id="content" class="container container-pageinfouser">
            <div class="col-xs-12 col-sm-10 my-5 mx-auto row-container col-content-pageinfouser">
                <div class="row ds-row-pageinfouser mx-auto">
                </div>
            </div>
        </div>
	</div>
    

    <!-- footer -->
   
    <style>
        a {
            color: #BCBABE;
        }
        strong{
            color: #BCBABE;
        }
    </style>
    <footer class="bg-dark text-white pt-5 pb4">

        <div class = "container text-center text-md-left">

            <div class =" row text-center g-4 text-md-left">
                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>About</h3><br>
                        
                        <p><a href="#" >our services</a></li>
                        <p><a href="#" >privacy policy</a></li>
                        <p><a href="#" >affiliate program</a></li>
                    

                </div>

                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>Company</h3><br>
                        <p><a href="#" >about us</a></li>
                        <p><a href="#" >our services</a></li>
                        <p><a href="#" >privacy policy</a></li>
                </div>
                

                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3 >Get Help</h3><br>
                    
                        <p><a href="#" >FAQ</a></li>
                        <p><a href="#" >Contact</a></li>
        
                </div>
                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>follow us</h3><br>
                    <div class="social-links">
                        <a href="#" ><i class="fab fa-facebook-f"></i></a>
                        <a href="#" ><i class="fab fa-twitter"></i></a>
                        <a href="#" ><i class="fab fa-instagram"></i></a>
                        <a href="#" ><i class="fab fa-linkedin-in"></i></a>
                    </div>

                </div>
                
            </div>

            <hr class="mb-4">
            <div class="row align-items-center">
                <div class="col-md-7 col-lg-8">
                    <b>Copyright @2022 All rights reserved by:
                        <a href=""# style="text-decoration: none;">
                            <strong class=" text-white">Pham Company</strong>
                        </a>
                    </b>
                    <p style="font-size: medium; color:#BCBABE;"> Contact: Ho Chi Minh:(+84) 0965323966 - Email: PhamCompany@gmail.com</li>
                    
                </div>
                
            </div>
            
        </div>

    </footer>

<script>
    // Disable form submissions if there are invalid fields
    (function() {
      'use strict';
      window.addEventListener('load', function() {
        // Get the forms we want to add validation styles to
        var forms = document.getElementsByClassName('needs-validation');
        // Loop over them and prevent submission
        var validation = Array.prototype.filter.call(forms, function(form) {
          form.addEventListener('submit', function(event) {
            if (form.checkValidity() === false) {
              event.preventDefault();
              event.stopPropagation();
            }
            form.classList.add('was-validated');
          }, false);
        });
      }, false);
    })();
</script>
<!-- api để lấy dữ liệu tỉnh của việt nam -->
  <script src='https://cdn.jsdelivr.net/gh/vietblogdao/js/districts.min.js'></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Nhúng sweetalert2 từ CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    $(document).ready(function () {
    getAllInfoUser();
});
  function getAllInfoUser() {
    $.post("../Controllers/C_inforAdmin.php", {
      type: "1",
    }).done(function (data, status) {
      console.log(data);
      console.log(status);
      const res = JSON.parse(data);
      if (status) {
        updateUser(res);
      }
    });
  }
  function updateUser(data){
    console.log("data")
    console.log(data)
    let ele = $("#content").children().children().html("");
    let res = `
  <form id="formUpdateUser" method="post" action="../Controllers/C_inforAdmin.php" class="needs-validation my-4" novalidate>
    <h1 class="text-center">Thông Tin Công Ty</h1>
    <div class="d-sm-flex align-center text-center flex-sm-row mt-4 px-auto" >
        <div class="col-4 mx-auto" style="height: auto; max-height: 200px;">
            <button title="Thay ảnh đại diện" id="avatarInfo" type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" style="border:none;background-color: transparent;">
                <span><img class="format-img-userxinviec-right" 
                src="../image/ig12.png" alt="avatar"></span>
            </button>
        </div>
    </div>
    <div class="d-sm-flex  flex-sm-row mt-4">
        <div class="form-group col-sm-7">
            <label for="name">Tên công ty</label>
            <input value='${data.TenCTY}' name="TenCTY" type="text" class="form-control py-2" id="name" placeholder="Nhập tên ở đây" required>
        </div>
        <div class="form-group col-sm-5">
            <label for="namework">Website công ty</label>
            <input value='${data.website}' name="website" type="text" class="form-control py-2" id="namework" placeholder="Nhập website" required>
        </div>

    </div>
    <div class="d-sm-flex flex-sm-row">
        <div class="form-group col-sm-5">
            <label for="linhvuc">Lĩnh vực công ty</label>
            <select name="linhvuc" class="form-control py-2" id="linhvuc">
                <option selected>${data.linhvuc}</option>
                <option>Công nghệ thông tin</option>
                <option>Viễn thông</option>
                <option>Marketing / Truyền thông / Quảng cáo</option>
                <option>Nhà hàng / Khách sạn</option>
                <option>Thời trang</option>
                <option>Internet / Online</option>
                <option>Bất động sản</option>
                <option>Dược phẩm / Y tế / Công nghệ sinh học</option>
                <option>Kế toán / Kiểm toán</option>
                <option>Kinh doanh</option>
                <option>Giáo dục</option>
                <option>Văn phòng</option>
                <option>Bảo hiểm</option>
                <option>Luật</option>
                <option>Giải trí</option>
                <option>Agency</option>
                <option>Tài chính / Ngân Hàng</option>
                <option>Khác</option>
            </select>
        </div>
        <div class="form-group col-sm-6">
            <label for="tp">Thành phố</label>
            <select  name="thanhpho" class="form-control" id="tp" required>
                <option disabled="disabled">Tỉnh / Thành phố</option>
                <option selected>${data.thanhpho}</option>
            </select>
            <input class="billing_address_1" name="" type="hidden" value="">
        </div>
    </div>
    <div class="d-sm-flex flex-sm-row">
        <div class="form-group col-sm-7">
            <label for="diachi">Địa chỉ</label>
            <input value='${data.diachi}' name="diachi" type="text" class="form-control py-2" id="diachi" placeholder="Nhập tên địa chỉ ở đây" required>
        </div>
    </div>
    <div class="form-group col-12">
        <label for="comment1">Mô tả</label>
        <textarea  name="mota" class="form-control" rows="3" id="comment1" placeholder="Nhập mô tả ở đây" required>${data.mota}</textarea>
    </div>
    <div class="form-group">
      <label for="changepass">Cập nhật mật khẩu</label> 
      <input type="checkbox" name="changepass" id="changepass"/>
    </div>
    
    <div class="d-sm-flex flex-sm-row">
        <div class="form-group col-sm-4">
            <label for="passNow">Mật khẩu hiện tại</label>
            <input class="form-control py-2" name="passNow" id="passNow" type="password">
        </div>
        <div class="form-group col-sm-4">
            <label for="newpass">Mật khẩu mới</label>
            <input name="newpass" type="password" class="form-control py-2" id="newpass">
        </div>
        <div class="form-group col-sm-4">
            <label for="confirmPass">Nhập lại mật khẩu mới</label>
            <input name="confirmPass" type="password" class="form-control py-2" id="confirmPass">
        </div>
    </div>

    <div class="offset-sm-4">
        <button type="submit" class="mx-auto btn btn-primary">CẬP NHẬT</button>
    </div>
<!-- </div> -->
</form>

    `;
    ele.html(res);
    $('select[name="thanhpho"]').each(function() {
      var $this = $(this),
        stc = ''
      c.forEach(function(i, e) {
        stc += '<option>' + i + '</option>'
        if (address_1 = localStorage.getItem('address_1_saved')) {
          $('select[name="thanhpho"] option').each(function() {
            if ($(this).text() == address_1) {
              $(this).attr('selected', '')
            }
          })
        }
      })
      $(this).append(stc)
    })

  $("#formUpdateUser").submit(function (e){
    e.preventDefault();
    // Lấy dữ liệu từ biểu mẫu
    var formData = $(this).serialize();
    // Gửi yêu cầu AJAX đến server
    $.ajax({
      url: $(this).attr('action'),
      type: $(this).attr('method'),
      data: {formData,type:"0"},
      success: function(response) {
        console.log(response)
        const res = JSON.parse(response)
        if (res.status === 1) {
          // Xử lý thành công
          console.log('Success!');
          // Tạo một cửa sổ thông báo với nội dung và tiêu đề tùy chỉnh
          Swal.fire({
            title: 'Success',
            text: "Cập nhật thành công!",
            icon: 'success',
            showCancelButton: false,
            // cancelButtonColor: '#d33',
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'OK!'
          }).then((result) => {
            if (result.isConfirmed) {
              // Xử lý khi người dùng chọn OK
            }
          })
        } else {
          // Xử lý lỗi
          Swal.fire({
            title: 'Fail',
            text: res.message,
            icon: 'warning',
            showCancelButton: false,
            // cancelButtonColor: '#d33',
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'OK!'
          }).then((result) => {
            if (result.isConfirmed) {
              // Xử lý khi người dùng chọn OK
            }
          })
        }
      },
      error: function(xhr) {
        // Xử lý lỗi khi gửi yêu cầu AJAX
        console.log(xhr.responseText);
      }
    });
  });
  }
</script>




    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>