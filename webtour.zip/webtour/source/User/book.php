<?php
    // kiểm tra chưa có session thì về login
    session_start();
    if(!isset($_SESSION["user_id"])){
        $login_page = '../Login/login.php';
        // include('final web/User/index.php');
        header("Location: $login_page");
        exit;
    }
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link  href = "../style.css" rel = "stylesheet">  
    
    <!-- font -->
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@1,700&family=Tilt+Warp&display=swap" rel="stylesheet">
    <!-- icons -->
    
    <link href=" https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" rel = "stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <title> Choose A Job, Decide Your Future</title>
</head>
<body>
    <header>
        <nav class = "navbar navbar-expand-md bg">
            <a style="text-decoration: none;" href="" class = "narbar-brand fs-3 ms-5 text-white" >ITCompany</a>

            <button class="navbar-toggler me-3 text-white" type="button" data-bs-toggle="collapse" data-bs-target="#btn"><i class = 'bx bx-menu bx-md'></i></button>
            <div class="collapse navbar-collapse ul-bg" id="btn">
            <ul class="navbar-nav ms-auto" >
                    <li class = "nav-item">
                        <a href="userhome.php"  class="nav-link mx-4 text-white fs-8">Tìm việc làm</a>
                    </li>
                    <li class = "nav-item">
                        <a href="CV.php"  class="nav-link mx-4 text-white fs-8">Tạo CV</a>
                    </li>

                    <li class = "nav-item">
                        <a href="pageInfo.php" class="nav-link mx-4 text-white fs-8">Thông tin</a>
                    </li>

                    <li class = "nav-item">
                        <a href="../Login/logout.php" class="nav-link mx-4 text-white fs-8">Đăng Xuất</a>
                    </li>
                </ul>
            </div>
        </nav>  
    </header>
    <!-- showcase -->
    <style>
    
        .card {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            width: 270px;
            height: 400px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            overflow: hidden;
        }
        .card-image img {
        width: 100%;
        height: 190px;
        object-fit: cover;
        }

        
        
    
    </style>

<div>
    <!-- High Salary j do -->
    <section class = "p-5" style="margin-top: 30px;">
        <div class = "container">
            <div class="col-sm-12 format-text-heading">
                <h4>Danh sách yêu thích</h4>
            </div>
        <br>
            <div class = "row text-center g-4">
                <?php
                    require_once "../Login/database.php";
                    $iduser = $_SESSION["user_id"];
                    $sql = "SELECT * FROM LuuCTY inner join DangViec where LuuCTY.ID_Dangviec = DangViec.ID_DangViec and LuuCTY.ID_NTV = $iduser";
                    // Thực hiện truy vấn và lưu kết quả vào biến $result
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()){
                            $image = "../image/ig".$row["ID_CTY"].".png";
                            $luong = number_format($row["Luong"], 0, ",", ".") . " VND";
                            echo 
                                '<div class="col-xs-12 col-lg-3 col-md-6 col-sm-6">
                                    <div class="card">
                                    <div class="card-image">
                                    <img src="'.$image.'">
                                    </div>
                                    <div class="card-content">
                                        <h3 class="card-title">' . $row["Tencongviec"] .  '</h3>
                                        <p><i class="fa-solid fa-location-dot"></i> '. $row["Diachi"] . '</p>
                                        <p><i class="fa-solid fa-money-bill"></i>'.$luong.'</p>
                                        <p><i class="fa-solid fa-briefcase"></i> '.$row["soluongtuyen"].' vị trí đang tuyển</p>
                                    </div>
                                
                                    <div class="card-action">
                                        <a href="detail.php?idbaidang='.$row["ID_Dangviec"].'" style="color: #336B87;">More Information</a>
                                    </div>  
                                </div>
                                </div>';
                        }
                    }
                ?>    
            </div>
            <br><br>
            <div class="col-sm-12 format-text-heading">
                <h4>Danh sách công việc đã ứng tuyển</h4>
            </div>
            <br>
            <div class="table-responsive">
                <table id="yeucautuyendung" class="table align-middle mb-0 bg-white format-table">
                    <thead class="format-thead-background">
                        <tr class="format-text">
                            <th></th>
                            <th>Tên Công Ty</th>
                            <th>Công Việc</th>
                            <th>Chi Tiết</th>
                            <th>Trạng Thái</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                    require_once "../Login/database.php";
                    $iduser = $_SESSION["user_id"];
                    $sql = "SELECT * FROM Ungtuyen inner join DangViec inner join CONGTY where DangViec.ID_CTY = CONGTY.ID_CTY and Ungtuyen.ID_Dangviec = DangViec.ID_DangViec and Ungtuyen.ID_NTV = $iduser";
                    // Thực hiện truy vấn và lưu kết quả vào biến $result
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()){
                            $image = "../image/ig".$row["ID_CTY"].".png";
                            if ($row["Daduyet"] == -1) $status = "Đã từ chối";
                            else if ($row["Daduyet"] == 1) $status = "Đồng ý phỏng vấn";
                            else $status ="Chờ duyệt";
                            echo 
                                '
                                <tr class="format-text">
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="'.$image.'" alt="" style="width: 45px; height: 45px" class="rounded-circle" />
                                    </div>
                                </td>
                                <td>
                                    <p class="fw-normal mb-1">'.$row['TenCTY'].'</p>
                                </td>
                                <td>'.$row["Tencongviec"].'</td>
                                <td class="format-td">
                                    <div class="format-td-hoso">
                                        <a class="format-hoso" role="button" href="detail.php?idbaidang='.$row["ID_Dangviec"].'" class="btn btn-primary  btn-rounded">
                                            Xem hồ sơ
                                        </a>
                                    </div>
    
                                </td>
                                <td>
                                    <span class="format-text-datuchoi"> '.$status.' </span>
                                </td>
                            </tr>
                                ';
                        }
                    }
                ?>    
                    </tbody>
                </table>
            </div>
        </div>
    </section>

</div>

    

    <!-- footer -->

    <style>
       footer a {
            color: #BCBABE;
        }
        strong{
            color: #BCBABE;
        }
    </style>

    <footer class="bg-dark text-white pt-5 pb4">

        <div class = "container text-center text-md-left">

            <div class =" row text-center g-4 text-md-left">
                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>About</h3><br>
                        <!-- <p><a href="#" >about us</a></li> -->
                        <p><a href="#" >our services</a></li>
                        <p><a href="#" >privacy policy</a></li>
                        <p><a href="#" >affiliate program</a></li>
                    

                </div>

                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>Company</h3><br>
                        <p><a href="#" >about us</a></li>
                        <p><a href="#" >our services</a></li>
                        <p><a href="#" >privacy policy</a></li>
                </div>
                

                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3 >Get Help</h3><br>
                    
                        <p><a href="#" >FAQ</a></li>
                        <p><a href="#" >Contact</a></li>
        
                </div>
                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>follow us</h3><br>
                    <div class="social-links">
                        <a href="#" ><i class="fab fa-facebook-f"></i></a>
                        <a href="#" ><i class="fab fa-twitter"></i></a>
                        <a href="#" ><i class="fab fa-instagram"></i></a>
                        <a href="#" ><i class="fab fa-linkedin-in"></i></a>
                    </div>

                </div>
                
            </div>

            <hr class="mb-4">
            <div class="row align-items-center">
                <div class="col-md-7 col-lg-8">
                    <b>Copyright @2022 All rights reserved by:
                        <a href=""# style="text-decoration: none;">
                            <strong class=" text-white">Pham Company</strong>
                        </a>
                    </b>
                    <p style="font-size: medium; color:#BCBABE;"> Contact: Ho Chi Minh:(+84) 0965323966 - Email: PhamCompany@gmail.com</li>
                    
                </div>
                
            </div>
            
        </div>

    </footer>

</body>














    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>