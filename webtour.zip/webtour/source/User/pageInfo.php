<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link  href = "../style.css" rel = "stylesheet">  
    
    <!-- font -->
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@1,700&family=Tilt+Warp&display=swap" rel="stylesheet">
    <!-- icons -->
    
    <link href=" https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" rel = "stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="../Styles/pageinfouser.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <!-- jquery -->
    <script src="https://code.jquery.com/jquery-3.6.4.slim.min.js" integrity="sha256-a2yjHM4jnF9f54xUQakjZGaqYs/V1CYvWpoqZzC2/Bw=" crossorigin="anonymous"></script>
    <title> Choose A Job, Decide Your Future</title>
</head>
<body>
    <header>
        <nav class = "navbar navbar-expand-md bg">
            <a style="text-decoration: none;" href="" class = "narbar-brand fs-3 ms-5 text-white" >ITCompany</a>

            <button class="navbar-toggler me-3 text-white" type="button" data-bs-toggle="collapse" data-bs-target="#btn"><i class = 'bx bx-menu bx-md'></i></button>
            <div class="collapse navbar-collapse ul-bg" id="btn">
            <ul class="navbar-nav ms-auto" >
                    <li class = "nav-item">
                        <a href="userhome.php"  class="nav-link mx-4 text-white fs-8">Tìm việc làm</a>
                    </li>
                    <li class = "nav-item">
                        <a href="CV.php"  class="nav-link mx-4 text-white fs-8">Tạo CV</a>
                    </li>
                    <li class = "nav-item">
                        <a href="book.php"class="nav-link mx-4 text-white fs-8">Hoạt động</a>
                    </li>
                    <li class = "nav-item">
                        <a href="../Login/logout.php" class="nav-link mx-4 text-white fs-8">Đăng Xuất</a>
                    </li>
                </ul>
            </div>
        </nav>  
    </header>
    <!-- showcase -->
    <div id="main">
		<?php
            // require_once("infor.php");
            require_once("inforUser.php");
            ?>
	</div>


<script>
    // Disable form submissions if there are invalid fields
    (function() {
      'use strict';
      window.addEventListener('load', function() {
        // Get the forms we want to add validation styles to
        var forms = document.getElementsByClassName('needs-validation');
        // Loop over them and prevent submission
        var validation = Array.prototype.filter.call(forms, function(form) {
          form.addEventListener('submit', function(event) {
            if (form.checkValidity() === false) {
              event.preventDefault();
              event.stopPropagation();
            }
            form.classList.add('was-validated');
          }, false);
        });
      }, false);
    })();
</script>
<!-- api để lấy dữ liệu tỉnh của việt nam -->
  <script src='https://cdn.jsdelivr.net/gh/vietblogdao/js/districts.min.js'></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Nhúng sweetalert2 từ CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="../Scripts/Inforuser.js"></script>
</body>
</html>