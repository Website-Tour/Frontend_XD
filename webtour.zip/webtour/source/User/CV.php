<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link  href = "../style.css" rel = "stylesheet"> 
    
    <!-- font -->
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@1,700&family=Tilt+Warp&display=swap" rel="stylesheet">
    <!-- icons -->
    
    <link href=" https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" rel = "stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <title> Choose A Job, Decide Your Future</title>
</head>
<body class = "bg-light">
    <header>
        <nav class = "navbar navbar-expand-md bg">
            <a style="text-decoration: none;" href="" class = "narbar-brand fs-3 ms-5 text-white" >ITCompany</a>

            <button class="navbar-toggler me-3 text-white" type="button" data-bs-toggle="collapse" data-bs-target="#btn"><i class = 'bx bx-menu bx-md'></i></button>
            <div class="collapse navbar-collapse ul-bg" id="btn">
            <ul class="navbar-nav ms-auto" >
                    <li class = "nav-item">
                        <a href="userhome.php"  class="nav-link mx-4 text-white fs-8">Tìm việc làm</a>
                    </li>

                    <li class = "nav-item">
                        <a href="book.php"class="nav-link mx-4 text-white fs-8">Hoạt động</a>
                    </li>

                    <li class = "nav-item">
                        <a href="pageInfo.php" class="nav-link mx-4 text-white fs-8">Thông tin</a>
                    </li>

                    <li class = "nav-item">
                        <a href="../Login/logout.php" class="nav-link mx-4 text-white fs-8">Đăng Xuất</a>
                    </li>
                </ul>
            </div>
        </nav>  
    </header>
    
    <div class="container" style="height: 1100px;">
        <form class="row g-3" style="margin-top: 100px;">
            
            <div class="row g-2 mt-3">
              <div class="col-6">
                <label for="exampleFormControlTextarea1" class="form-label">Họ Và Tên</label>
                    <input class="form-control" type="text" aria-label="default input example">
              </div>
              <div class="col-6">
                <label for="exampleFormControlTextarea1" class="form-label">Ngày Sinh</label>
                    <input class="form-control" type="date" aria-label="default input example">
              </div>
              
            </div>
            <div class="row g-2 mt-3">
                <div class="col-6">
                  <label for="exampleFormControlTextarea1" class="form-label">Email</label>
                  <input type=" text" class = "form-control" placeholder="Email">
                </div>
                <div class="col-6">
                    <label for="exampleFormControlTextarea1" class="form-label">Phone Number</label>
                    <input class="form-control" type="text" aria-label="default input example">
                </div>    
            </div>
            <div class="row g-2 mt-3">
                <p style="margin-left: 12px;">Sex</p>
                <div class="form-check mb-3" style="margin-left: 19px;">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
                    <label class="form-check-label" for="flexRadioDefault1">
                        Nam
                    </label>
                  </div>
                  <div class="form-check mb-3 " style="margin-left: 19px;">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2">
                    <label class="form-check-label" for="flexRadioDefault2">
                        Nữ
                    </label>
                </div> 
            </div>
            <div class="row g-2 mt-3">
                <div class="col-12">
                    <label for="exampleFormControlTextarea1" class="form-label"> Gioi Thiệu Bản Thân </label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                </div>       
            </div>
            <div class="row g-2 mt-3">
                <div class="col-6">
                    <label for="exampleFormControlTextarea1" class="form-label">Kỹ Năng</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                </div>
                <div class="col-6">
                    <label for="exampleFormControlTextarea1" class="form-label">Kinh Nghiệm</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                </div>  
            </div>
            <div class="row g-2 mt-3">
                <div class="col-6">
                  <label for="exampleFormControlTextarea1" class="form-label">Vị Trí Muốn làm</label>
                      <input class="form-control" type="text" aria-label="default input example">
                </div>
                <div class="col-6">
                  <label for="exampleFormControlTextarea1" class="form-label">Kinh nghiệm</label>
                      <input class="form-control" type="date" placeholder="Nếu có" aria-label="default input example">
                </div>
            </div>
            <div class="row g-2 mt-3">
                <p style="margin-left: 12px;">Trình độ</p>
                <div class="form-check mb-3" style="margin-left: 19px;">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
                    <label class="form-check-label" for="flexRadioDefault1">
                        Đã tốt nghiệp
                    </label>
                  </div>
                  <div class="form-check mb-3 " style="margin-left: 19px;">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2">
                    <label class="form-check-label" for="flexRadioDefault2">
                        Đang học
                    </label>
                </div> 
            </div>

            <div class="row g-2 mt-3">
                <div style="margin-left: 10px; margin-right: -10px;">
                    <select class="form-select" aria-label="Default select example">
                        <option selected>Employent Time</option>
                        <option value="1">Inter</option>
                        <option value="2">Full</option>
                        <option value="3">Part</option>
                      </select>
                </div>
            </div>
            <div class="col-12 text-center">
                <button type="submit" class="btn btn-dark" >Submit</button>
            </div>
        </form>
    </div>
</div>    

    <!-- footer -->
   
    <style>
        a {
            color: #BCBABE;
        }
        strong{
            color: #BCBABE;
        }
    </style>
    <footer class="bg-dark text-white pt-5 pb4">

        <div class = "container text-center text-md-left">

            <div class =" row text-center g-4 text-md-left">
                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>About</h3><br>
                        
                        <p><a href="#" >our services</a></li>
                        <p><a href="#" >privacy policy</a></li>
                        <p><a href="#" >affiliate program</a></li>
                    

                </div>

                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>Company</h3><br>
                        <p><a href="#" >about us</a></li>
                        <p><a href="#" >our services</a></li>
                        <p><a href="#" >privacy policy</a></li>
                </div>
                

                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3 >Get Help</h3><br>
                    
                        <p><a href="#" >FAQ</a></li>
                        <p><a href="#" >Contact</a></li>
        
                </div>
                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>follow us</h3><br>
                    <div class="social-links">
                        <a href="#" ><i class="fab fa-facebook-f"></i></a>
                        <a href="#" ><i class="fab fa-twitter"></i></a>
                        <a href="#" ><i class="fab fa-instagram"></i></a>
                        <a href="#" ><i class="fab fa-linkedin-in"></i></a>
                    </div>

                </div>
                
            </div>

            <hr class="mb-4">
            <div class="row align-items-center">
                <div class="col-md-7 col-lg-8">
                    <b>Copyright @2022 All rights reserved by:
                        <a href=""# style="text-decoration: none;">
                            <strong class=" text-white">Pham Company</strong>
                        </a>
                    </b>
                    <p style="font-size: medium; color:#BCBABE;"> Contact: Ho Chi Minh:(+84) 0965323966 - Email: PhamCompany@gmail.com</li>
                    
                </div>
                
            </div>
            
        </div>

    </footer>

</body>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>