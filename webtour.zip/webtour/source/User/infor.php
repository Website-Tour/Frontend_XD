<div id="content" class="container container-pageinfouser">
    <div class="offset-sm-3 col-sm-6 col-content-pageinfouser">
        <div class="row ds-row-pageinfouser">
            <div class="col-sm-12 infor-userxinviec col-pageinfouserabove">
                <div class="card-info-userxinviec">
                    <div class="body">
                        <div class="row">
                            <div class="col-sm-12 img-userxinviec-right">
                                <button title="Thay ảnh đại diện" id="avatarInfo" type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" style="border:none;background-color: transparent;">
                                    <span><img class="format-img-userxinviec-right" src="../image/ig1.png" alt=""></span>
                                </button>
                            </div>
                            <div class="col-sm-12">
                                <h5 class="card-title format-text-bold">William Shakespeare</h5>
                                <h6 class="card-subtitle mb-2">Nhân viên bán hàng</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 ">
                <div class="card-basicinfo">
                    <div class="body">
                        <div class="row">
                            <div class="col-sm-12 mgl-col-content2-right-below">
                                <h5 class="card-title format-text-bold">Thông tin cơ bản</h5>
                            </div>
                            <div class="col-sm-12  mgl-col-content2-right-below format-mt-item">
                                <span class="format-span-img-cake"><img class="format-img-cake" src="../../../../src/assets/Image/ic_cake_24px.png" alt="">1/1/2000</span>
                                <span class="format-span-img-gender"><img class="format-img-gender" src="../../../../src/assets/Image/ic_wc_24px.png" alt="">Nữ</span>
                            </div>

                            <div class="col-sm-12  mgl-col-content2-right-below format-mt-item">
                                <span class="format-span-img-call"><img class="format-img-call" src="../../../../src/assets/Image/ic_call_24px.png" alt="">0987654321</span>
                                <span class="format-span-img-letter"><img class="format-img-letter" src="../../../../src/assets/Image/ic_markunread_24px.png" alt="">William@gmail.com</span>
                            </div>

                            <div class="col-sm-12  mgl-col-content2-right-below format-mt-item">
                                <span><img class="format-img-place" src="../../../../src/assets/Image/ic_place_24px.png" alt="">19 Đ. Nguyễn Hữu Thọ, Tân Hưng, Quận 7, Thành phố Hồ Chí Minh</span>
                            </div>

                            <div class="col-sm-12 mgl-col-content2-right-below col-muctieu">
                                <h5 class="card-title format-text-bold">Mục tiêu nghề nghiệp</h5>
                                <span>
                                    <p class="p-muctieu">Áp dụng những kinh nghiệm về kỹ năng bán hàng và sự hiểu biết về
                                        thị trường để trở thành một nhân viên bán hàng chuyên nghiệp,
                                        mang đến nhiều giá trị cho khách hàng. Từ đó giúp Công ty tăng số
                                        lượng khách hàng và mở rộng tập khách hàng.
                                    </p>
                                </span>
                            </div>

                            <div class="col-sm-12 mgl-col-content2-right-below col-hocvan">
                                <h5 class="card-title format-text-bold">Học vấn</h5>
                                <span>
                                    <p class="p-hocvan">Đại học Tôn Đức Thắng
                                        </br>
                                        Quản trị Doanh nghiệp
                                        </br>
                                        10/2010 - 05/2014
                                        </br>
                                        Tốt nghiệp loại Giỏi, điểm trung bình 8.0
                                    </p>
                                </span>
                            </div>

                            <div class="col-sm-12 mgl-col-content2-right-below col-kynang">
                                <h5 class="card-title format-text-bold">Kỹ năng</h5>
                                <span>
                                    <p class="p-kynang">Tin học văn phòng :
                                        </br>
                                        -Sử dụng thành thạo các công cụ Word, Excel, Power Point
                                        </br>
                                        Tiếng Anh:
                                        </br>
                                        -Khả năng giao tiếp Tiếng Anh trôi chảy

                                    </p>
                                </span>
                            </div>
                            <div class="col-sm-12 mgl-col-content2-right-below col-kinhnghiem">
                                <h5 class="card-title format-text-bold">Kinh nghiệm làm việc</h5>
                                <span>
                                    <p class="p-kinhnghiem">
                                        Công ty ABC
                                        </br>
                                        Nhân viên bán hàng 03/2015 - Hiện tại
                                        </br>
                                        - Hỗ trợ viết bài quảng cáo sản phẩm qua kênh facebook, các
                                        forum,...
                                        </br>
                                        - Giới thiệu, tư vấn sản phẩm, giải đáp các vấn đề thắc mắc của khách
                                        hàng qua điện thoại và email.
                                        Cửa hàng XYZ
                                        </br>
                                        Nhân viên bán hàng 06/2014 - 02/2015
                                        </br>
                                        - Bán hàng trực tiếp tại cửa hàng cho người nước ngoài và người Việt.
                                        </br>
                                        - Quảng bá sản phẩm thông qua các ấn phẩm truyền thông: banner,
                                        poster, tờ rơi...
                                        </br>
                                        - Lập báo cáo sản lượng bán ra hàng ngày.

                                    </p>
                                </span>
                            </div>
                            
                            
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>


