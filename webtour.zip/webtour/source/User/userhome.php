<?php
    // kiểm tra chưa có session thì về login
    session_start();
    if(!isset($_SESSION["user_id"])){
        $login_page = '../Login/login.php';
        // include('final web/User/index.php');
        header("Location: $login_page");
        exit;
    }
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link  href = "../style.css" rel = "stylesheet">  
    
    <!-- font -->
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@1,700&family=Tilt+Warp&display=swap" rel="stylesheet">
    <!-- icons -->
    
    <link href=" https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" rel = "stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <!-- jquery -->
    <script src="https://code.jquery.com/jquery-3.6.4.slim.min.js" integrity="sha256-a2yjHM4jnF9f54xUQakjZGaqYs/V1CYvWpoqZzC2/Bw=" crossorigin="anonymous"></script>
    <title> Choose A Job, Decide Your Future</title>
    <!-- font awesome    -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/brands.min.css" integrity="sha512-9YHSK59/rjvhtDcY/b+4rdnl0V4LPDWdkKceBl8ZLF5TB6745ml1AfluEU6dFWqwDw9lPvnauxFgpKvJqp7jiQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/fontawesome.min.css" integrity="sha512-SgaqKKxJDQ/tAUAAXzvxZz33rmn7leYDYfBP+YoMRSENhf3zJyx3SBASt/OfeQwBHA1nxMis7mM3EV/oYT6Fdw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/regular.min.css" integrity="sha512-WidMaWaNmZqjk3gDE6KBFCoDpBz9stTsTZZTeocfq/eDNkLfpakEd7qR0bPejvy/x0iT0dvzIq4IirnBtVer5A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/solid.min.css" integrity="sha512-yDUXOUWwbHH4ggxueDnC5vJv4tmfySpVdIcN1LksGZi8W8EVZv4uKGrQc0pVf66zS7LDhFJM7Zdeow1sw1/8Jw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- css -->
    <link rel="stylesheet" href="../Styles/paginate.css">
    <!-- paginate -->
    
<script src='https://cdnjs.cloudflare.com/ajax/libs/simplePagination.js/1.6/jquery.simplePagination.js'></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
</head>
<body>
    <header>
        <nav class = "navbar navbar-expand-md bg">
            <a style="text-decoration: none;" href="" class = "narbar-brand fs-3 ms-5 text-white" >ITCompany</a>

            <button class="navbar-toggler me-3 text-white" type="button" data-bs-toggle="collapse" data-bs-target="#btn"><i class = 'bx bx-menu bx-md'></i></button>
            <div class="collapse navbar-collapse ul-bg" id="btn">
            <ul class="navbar-nav ms-auto" >

                    <li class = "nav-item">
                        <a href="CV.php"  class="nav-link mx-4 text-white fs-8">Tạo CV</a>
                    </li>
                    <li class = "nav-item">
                        <a href="book.php"class="nav-link mx-4 text-white fs-8">Hoạt động</a>
                    </li>

                    <li class = "nav-item">
                        <a href="pageInfo.php" class="nav-link mx-4 text-white fs-8">Thông tin</a>
                    </li>

                    <li class = "nav-item">
                        <a href="../Login/logout.php" class="nav-link mx-4 text-white fs-8">Đăng Xuất</a>
                    </li>
                </ul>
            </div>
        </nav>  
    </header>
    <!-- showcase -->

    <style>
    
        .card {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            width: 270px;
            height: 400px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            overflow: hidden;
        }
        .card-image {
            height:40%;
        }
        .card-image img {
        width: 100%;
        height: 100%;

        object-fit: cover;
        }
    
    </style>

<div>
    <style>
        .section-background {
            background-image: url("../image/a.png");
            background-size: cover;
            background-position: center center;
            background-repeat: no-repeat;
        }
    </style>
    <!-- tìm kiếm -->
    <section class = "p-5 text-center text-sm-start section-background" style="margin-top: 48px;">
        <br>
        <div class = "container">
            <!-- <div class = "d-sm-flex"> -->
            <div class="">
                <div>
                    <h1> Find your IT job</h1>
                    <p class="lead my-4">We are here for you to find your dream job</li><br>
                    <br>        
                </div>    
            </div>
            <div class = "search-wrapper">
                <div class = "search-box">
                    <div class = "search-card">
                        <input value="" id="search_input" class="search-input" type = "text" placeholder="Nhập từ khóa liên quan như: Tên, Thành phố, Kỹ năng, Lương,...">
                        <div>
                            <button id="btnsearch"  class ="search-button"><img src ="../image/search.png" ></button>
                        </div>
                    </div>
                </div>
            </div>

            <div>
                <div class="filter-box">
                    <select class = "filter-select" id="filterSalary" name="filterSalary">
                        <option value="-1">Salary</option>
                        <option value="1"><i class="fa-solid fa-down"></i>High to low</option>
                        <option value="0"><i class="fa-solid fa-up"></i>Low to high</option>
                    </select>
                    
                    <select class = "filter-select" id="employment_type" name="type">
                        <option value="">Employment Type</option>
                        <option value="0">Part Time</option>
                        <option value="1">Full Time</option>
                    </select>
                    <!-- <select class = "filter-select" id="location" name="location">
                        <option>Locations</option>
                        <option>Hà Nội</option>
                        <option>Hồ Chí Minh</option>
                        <option>Đà Nẵng</option>
                    </select> -->
                </div>
            </div>
           
        </div>
    </section>
    <!-- High Salary j do -->
    <section class = "p-5" style="margin-top: 30px;">
        <div class = "container">
        <br>
            <div id="showJob" class = "row text-center g-4" action="">
                
            <?php
                require_once "../Login/database.php";
                $sql = "SELECT * FROM DangViec";

                // Thực hiện truy vấn và lưu kết quả vào biến $result
                $result = $conn->query($sql);

                // Kiểm tra số lượng bản ghi trả về có lớn hơn 0 hay không
                if ($result->num_rows > 0) {
                // Lặp qua từng bản ghi và in ra dữ liệu
                while($row = $result->fetch_assoc()) {
                    //echo "ID: " . $row["ID_CTY"] . " - Name: " . $row["TenCTY"] . " - Email: " . $row["diachi"] . "<br>";
                        $image = "../image/ig".$row["ID_CTY"].".png";
                        $luong = number_format($row["Luong"], 0, ",", ".") . " VND";
                        echo 
                            '<div class="ctitem col-xs-12 col-lg-3 col-md-6 col-sm-6">
                                <div class="card">
                                    <div class="card-image">
                                        <img src="' . $image . '">
                                    </div>
                                    <div class="card-content">
                                        <h3 class="card-title">' . $row["Tencongviec"] .  '</h3>
                                        <p><i class="fa-solid fa-location-dot"></i> '. $row["Diachi"] . '</p>
                                        <p><i class="fa-solid fa-money-bill"></i>'.$luong.'</p>
                                        <p><i class="fa-solid fa-briefcase"></i> '.$row["soluongtuyen"].' vị trí đang tuyển</p>
                                    </div>
                            
                                    <div class="card-action">
                                        <a href="detail.php?idbaidang='.$row["ID_Dangviec"].'" style="color: #336B87;">More Information</a>
                                    </div>  
                                </div>
                            </div>';
                        }
                    
                }
                // } else {
                // echo "0 results";
                // }

            ?>  

            </div>
            <br><br>
           
        </div>
        <div id="pagination-container"></div>
    </section>


</div>

    <!-- footer -->
    <style>
        a {
            color: #BCBABE;
        }
        strong{
            color: #BCBABE;
        }
    </style>
    <footer class="bg-dark text-white pt-5 pb4">

        <div class = "container text-center text-md-left">

            <div class =" row text-center g-4 text-md-left">
                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>About</h3><br>
                        <!-- <p><a href="#" >about us</a></li> -->
                        <p><a href="#" >our services</a></li>
                        <p><a href="#" >privacy policy</a></li>
                        <p><a href="#" >affiliate program</a></li>
                    

                </div>

                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>Company</h3><br>
                        <p><a href="#" >about us</a></li>
                        <p><a href="#" >our services</a></li>
                        <p><a href="#" >privacy policy</a></li>
                </div>
                

                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3 >Get Help</h3><br>
                    
                        <p><a href="#" >FAQ</a></li>
                        <p><a href="#" >Contact</a></li>
        
                </div>
                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>follow us</h3><br>
                    <div class="social-links">
                        <a href="#" ><i class="fab fa-facebook-f"></i></a>
                        <a href="#" ><i class="fab fa-twitter"></i></a>
                        <a href="#" ><i class="fab fa-instagram"></i></a>
                        <a href="#" ><i class="fab fa-linkedin-in"></i></a>
                    </div>

                </div>
                
            </div>

            <hr class="mb-4">
            <div class="row align-items-center">
                <div class="col-md-7 col-lg-8">
                    <b>Copyright @2022 All rights reserved by:
                        <a href=""# style="text-decoration: none;">
                            <strong class=" text-white">Pham Company</strong>
                        </a>
                    </b>
                    <p style="font-size: medium; color:#BCBABE;"> Contact: Ho Chi Minh:(+84) 0965323966 - Email: PhamCompany@gmail.com</li>
                    
                </div>
                
            </div>
            
        </div>

    </footer>

<!-- phân trang -->
<script>
            // PHÂN TRANG
            var items = $('.ctitem');
    // console.log(items);
    numItems = $('#showJob .ctitem:last').index()+1;
    var perPage = 8;
    items.slice(perPage).hide();
    console.log($('#pagination-container'));
    $('#pagination-container').pagination({
        items: numItems,
        itemsOnPage: perPage,
        prevText: "&laquo;",
        nextText: "&raquo;",
        onPageClick: function (pageNumber) {
            var showFrom = perPage * (pageNumber - 1);
            var showTo = showFrom + perPage;
            items.hide().slice(showFrom, showTo).show();
            }
    });
</script>

    <script>
        $(document).ready(function() {
            $("#btnsearch").on("click", function(e) {
                e.preventDefault()
                const valueSearch = $("#search_input").val();
                const filter = $("#employment_type").val();
                const filterSalary = $("#filterSalary").val();
                console.log(filterSalary);
                const currentPath = window.location.href;
                console.log(currentPath)
                $.ajax({
                    url: "../Controllers/C_search.php",
                    type: "POST", // Thay đổi phương thức thành POST
                    data: { value: valueSearch, filter: filter, filterSalary:filterSalary}, // Dữ liệu gửi đi
                    success: function(response) {
                        const result = JSON.parse(response)
                        console.log(result)
                        if (result.length ==0)
                           {Swal.fire({
                                title: 'warning',
                                text: "Không tìm thấy dữ liệu!",
                                icon: 'warning',
                                showCancelButton: false,
                                // cancelButtonColor: '#d33',
                                confirmButtonColor: '#3085d6',
                                confirmButtonText: 'OK!'
                            })
                        }
                        else
                        {$("#showJob").children().remove()
                        result.forEach(function(a,b){
                            let image = `../image/ig${a.ID_CTY}.png`;
                            let luong = parseInt(a.Luong).toLocaleString("vi-VN", { style: "currency", currency: "VND" });
                            let job = `
                            <div class="col-xs-12 col-lg-3 col-md-6 col-sm-6">
                                <div class="card">
                                    <div class="card-image">
                                        <img src="${image}">
                                    </div>
                                    <div class="card-content">
                                        <h3 class="card-title">${a.Tencongviec}</h3>
                                        <p><i class="fa-solid fa-location-dot"></i> ${a.Diachi}</p>
                                        <p><i class="fa-solid fa-money-bill"></i> ${luong}</p>
                                        <p><i class="fa-solid fa-briefcase"></i> ${a.soluongtuyen} vị trí đang tuyển</p>
                                    </div>
                            
                                    <div class="card-action">
                                        <a href="detail.php?idbaidang=${a.ID_Dangviec}" style="color: #336B87;">More Information</a>
                                    </div>  
                                </div>
                            </div>
                            `;
                            $("#showJob").append(job)
                        })}
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.log(xhr.responseText);
                    }
                })
            })
        })
    </script>

</body>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <!-- Nhúng sweetalert2 từ CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  </body>
</html>

<?php   $conn->close(); ?>