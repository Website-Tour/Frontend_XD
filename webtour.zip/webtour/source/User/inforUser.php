<div id="content" class="container container-pageinfouser">
    <div class="col-xs-12 col-sm-10 my-5 mx-auto row-container col-content-pageinfouser">
        <div class="row ds-row-pageinfouser mx-auto">
        </div>
    </div>
</div>