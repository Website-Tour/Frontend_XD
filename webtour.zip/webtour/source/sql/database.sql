SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";
CREATE DATABASE IF NOT EXISTS `WEB_TimViec` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `WEB_TimViec`;

drop table if exists CONGTY;

-- ---------------------- BẢNG CÔNG TY------------------
CREATE TABLE CONGTY
(
  ID_CTY int auto_increment not null,
  TenCTY varchar(20) not null default "",
  diachi varchar(50) not null default "",
  thanhpho varchar(20) not null default "",
  linhvuc varchar(20) not null default "",
  website varchar(50) not null default "",
  linkavatar varchar(500) not null default "",
  mota varchar(2000) not null default "",
  xoa int(10) not null default 0,
  primary key(ID_CTY)
)engine = innoDB default charset=utf8 collate=utf8_unicode_ci;

alter table CONGTY auto_increment=01;

drop table if exists AD_CTY;

-- -----------------BẢNG ADMIN CÔNG TY----------- --
CREATE TABLE AD_CTY
(
  ID_CTY int not null,
  Tendangnhap varchar(30) not null,
  Matkhau varchar(30) not null,
  SDT varchar(11) not null default "0123456789",
  Email varchar(50) not null,
  primary key(Tendangnhap,Email),
  foreign key(ID_CTY) references CONGTY(ID_CTY)
);

drop table if exists DangViec;
-- ----------------------BẢNG ĐĂNG VIỆC CỦA CÔNG TY ------------
CREATE TABLE DangViec
(
  ID_Dangviec int auto_increment not null,
  Tencongviec varchar(30) not null,
  Loaicongviec varchar(30) not null,
  Chucvu varchar(30) not null,
  Luong varchar(20) not null,
  Linhvuc varchar(30) not null,
  Diachi varchar(100) not null,
  Email varchar(50) not null,
  SDT varchar(11) not null,
  Mota varchar(1000) not null,
  Kynang varchar(100) not null,
  Thoigianlamviec varchar(20) not null default "",
  Yeucau varchar(1000) not null,
  Quyenloi varchar(1000) not null,
  Xoa int(10) not null default 0,
  soluongtuyen int(10) default 10,
  ID_CTY int not null,
  primary key(ID_Dangviec),
  foreign key(ID_CTY) references CONGTY(ID_CTY)
)engine=InnoDB charset=utf8 collate=utf8_unicode_ci;

alter table DangViec auto_increment=01;

drop table if exists NguoiTimViec;
-- -------------------BẢNG NGƯỜI TÌM VIỆC--------------
create table NguoiTimViec
(
  ID_NTV int auto_increment not null,
  Hoten varchar(50) not null default "",
  Ngaysinh date not null default "1990-01-01",
  Gioitinh varchar(10) not null,
  Email varchar(50) not null default "",
  SDT varchar(11) not null default "",
  Linkavatar varchar(100) not null default "",
  Congviec varchar(50) not null default "",
  Loaicongviec varchar(50) not null default "",
  Linhvuc varchar(30) not null default "",
  Thanhpho varchar(20) not null default "",
  Diachi varchar(100) not null default "",
  Hocvan varchar(20) not null default "",
  Kynang varchar(100) not null default "",
  Kinhnghiem varchar(200) not null default "",
  Muctieu varchar(100) not null default "",
  Chitiet varchar(100) not null default "",
  Xoa int(10) not null default 0,
  primary key(ID_NTV)
)engine=InnoDB default charset=utf8 collate=utf8_unicode_ci;

alter table NguoiTimViec auto_increment=01;

drop table if exists AD_NTV;
-- -----------------BẢNG ADMIN Người tìm việc----------- --
CREATE TABLE AD_NTV
(
  Tendangnhap varchar(30) not null,
  Matkhau varchar(30) not null,
  Email varchar(50) not null,
  ID_NTV int not null,
  primary key(Tendangnhap,Email),
  foreign key(ID_NTV) references NguoiTimViec(ID_NTV)
);

drop table if exists Ungtuyen;
-- ---------------------BẢNG NGƯỜI TÌM VIỆC ỨNG TUYỂN--------------
create table Ungtuyen
(
  MaUT int auto_increment not null,
  Daxoa int(10) not null default 0,
  Daduyet int not null default 0,
  ID_NTV int not null,
  ID_Dangviec int not null,
  primary key(MaUT),
  foreign key(ID_NTV) references NguoiTimViec(ID_NTV),
  foreign key(ID_Dangviec) references Dangviec(ID_Dangviec)
)engine=InnoDB default charset=utf8 collate=utf8_unicode_ci;

alter table Ungtuyen auto_increment=01;

drop table if exists CongViecDuocMoi;
-- --------------------BẢNG CÔNG VIỆC ĐƯỢC MỜI------------------
create table CongViecDuocMoi
(
  ID_CTY int not null,
  ID_NTV int not null,
  Daduyet int not null,
  foreign key(ID_CTY) references CONGTY(ID_CTY),
  foreign key(ID_NTV) references NguoiTimViec(ID_NTV)
);

drop table if exists LuuNTV;
-- ---------------BẢNG LƯU NGƯỜI TÌM VIỆC ĐÃ THÍCH------------------
create table LuuNTV
(
  ID_NTV int not null,
  ID_CTY int not null,
  primary key(ID_NTV,ID_CTY),
  foreign key(ID_NTV) references NguoiTimViec(ID_NTV),
  foreign key(ID_CTY) references CONGTY(ID_CTY)
);

drop table if exists LuuCTY;
-- ----------------BẢNG LƯU CÔNG TY ĐÃ THÍCH--------------------
create table LuuCTY
(
  ID_NTV int not null,
  ID_CTY int not null,
  ID_Dangviec int not null,
  primary key(ID_NTV,ID_CTY,ID_Dangviec),
  foreign key(ID_NTV) references NguoiTimViec(ID_NTV),
  foreign key(ID_CTY) references CONGTY(ID_CTY),
  foreign key(ID_Dangviec) references DangViec(ID_Dangviec)
);


--  CÔng TY-----

insert into CONGTY(
  TenCTY,
  diachi,
  thanhpho,
  linhvuc,
  website,
  linkavatar,
  mota
)values(
  "VETC VietNam", 
  "Quận Nam Từ Liêm, Hà Nội",
  "Hà Nội",
  "Công nghệ thông tin",
  "VETC.vn",
  "../../../source/image/vetc_company.png",
  "Công ty VETC được thành lập với mục tiêu trở thành đơn vị triển khai và vận hành hệ thống thu phí tự động ETC (Electronic Toll Collection) tại Việt Nam. Mong muốn của VETC là mang đến giải pháp thu phí ứng dụng công nghệ hiện đại góp phần tăng tốc cho sự phát triển chung của lĩnh vực Giao thông Vận tải nói riêng và nền kinh tế Việt Nam nói chung. 
  
Ý tưởng đầu tư hệ thống thu phí tự động không dừng của VETC được bắt nguồn từ những đánh giá về lợi ích mà hệ thống này mang lại, đồng thời dựa trên thực tế thành công của nhiều quốc gia/vùng lãnh thổ trên thế giới."
  ),(
  "APOLLO Solutions",
  "Quận Phú Nhuận, Hồ Chí Minh",
  "Hồ Chí Minh",
  "Công nghệ thông tin",
  "Apollo.com",
  "../../../source/image/Apollo.png",
  "Apollo cung cấp giải pháp gia tăng năng lực phân tích dữ liệu, đẩy mạnh hoạt động chuyển đổi số, hỗ trợ ra quyết định giúp giải quyết những vấn đề thực sự, thử thách của khách hàng và cùng khách hàng xây dựng một xã hội an toàn, tốt đẹp hơn."
  ),(
  "Code Engine Studio",
  "Quận Hải Châu, Đà Nẵng",
  "Đà Nẵng",
  "Công nghệ thông tin",
  "CES.com",
  "../../../source/image/CES.png",
  "Code Engine Studio is a strategic technology and implementation partner focused on helping our global clientele succeed by turning ideas and strategies into high-end digital products with measurable results.

We take pride in creating a great company culture that builds up the team, believing that together we can accomplish anything! We are also more than our work, and give back to our community through service and development programs."
  ),(
  "RP Soft",
  "Quận Đống Đa, Hà Nội",
  "Hà Nội",
  "Công nghệ thông tin",
  "RP.vn",
  "../../../source/image/RPSoft.png",
  "Viralize The World
VIRALSOFT., JSC chuyên phát triển các sản phẩm phần mềm cho thị trường Nhật bản, Thái Lan, Singapore… 

Với đội ngũ nhân sự chủ chốt từng có thời gian dài học tập và làm việc tại Nhật Bản, Singapore.  VIRALSOFT  đã và đang xây dựng môi trường làm việc chuyên nghiệp và luôn đề cao sự cởi mở và thân thiện. "
  ),(
  "Dynu in Media",
  "Quận Liên Chiểu, Đà Nẵng",
  "Đà Nẵng",
  "Công nghệ thông tin",
  "Dynu.com",
  "../../../source/image/Dynu.png",
  "Công nghệ nâng tầm giá trị
  
Dynu in Media được thành lập với mục tiêu đem trí tuệ của mình để làm giàu chính đáng cho bản thân và cho xã hội bằng việc cung cấp các sản phẩm, dịch vụ Công nghệ thông tin, truyền thông có uy tín, chất lượng cao. Chúng tôi lấy công nghệ làm nền tảng cho sự phát triển với tiêu chí “Công nghệ mang lại giá trị gia tăng”. "
  ),(
  "Intratech",
  "Thành phố Thủ Đức, Hồ Chí Minh",
  "Hồ Chí Minh",
  "Công nghệ thông tin",
  "Intra.com",
  "../../../source/image/Intra.png",
  "Specialized in 3D Digital Transformation to create new business processes, culture, and customer experiences
Intratech is a Korea-based software company, its primary business area is 3D Transformation and visualization software for Digital Transformation For 4th Industrial Revolution. Major customers are Samsung Heavy Industry, Samsung Engineering and multinational companies; McDermott Engineering, Wooley Parsons, etc."
  ),(
  "Luvina Software",
  "Quận Cầu Giấy, Hà Nội",
  "Hà Nội",
  "Công nghệ thông tin",
  "Luv.vn",
  "../../../source/image/Luv.png",
  "Imperfect Human, Perfect Product
Được thành lập từ tháng 7/2004, sau hơn 17 năm phát triển, Luvina Hà Nội - Đà Nẵng - Nhật Bản đã làm nên thành tích đáng kể và gần đây nhất chính là lọt TOP Doanh nghiệp CNTT hàng đầu Việt Nam trong lĩnh vực xuất khẩu phần mềm (2020).

Đối tác khách hàng của Luvina phần lớn đến từ Nhật Bản, giải pháp công nghệ Luvina - Đảm nhận công việc từ khâu thiết kế, phát triển tới bảo trì vận hành cũng như làm mới các sản phẩm IT."
  ),(
  "BrickMate Group",
  "Quận 10, Hồ Chí Minh",
  "Hồ Chí Minh",
  "Công nghệ thông tin",
  "BM.com",
  "../../../source/image/BMG.png",
  "BrickMate Group

BrickMate Group (BMG) is a global IT development agency headquartered in Seoul, Korea, with satellite and alliance offices in HCMC.

We are different. It's not just another development agency. It was founded and operated by global startup serial entrepreneurs with exit experience. We are fully equipped with startup DNA and mindset."
  ),(
  "Net Company",
  "Quận Bình Thạnh, Hồ Chí Minh",
  "Hồ Chí Minh",
  "Công nghệ thông tin",
  "NetC.com",
  "../../../source/image/NetC.png",
  "Tổng Công ty Hạ tầng mạng (tên gọi tắt VNPT-Net) là đơn vị thành viên hạch toán phụ thuộc của Tập đoàn Bưu chính Viễn thông Việt Nam. Được thành lập theo Quyết định số 86/QĐ-VNPT-HĐTV-TCCB ngày 08 tháng 5 năm 2015của Hội đồng thành viên Tập đoàn Bưu chính Viễn thông Việt Nam trên cơ sở tổ chức lại Công ty Viễn thông Liên tỉnh (VTN), bộ phận quản lý và điều hành viễn thông của Tập đoàn, bộ phận hạ tầng của các đơn vị Công ty Dịch vụ Viễn thông (Vinaphone), Công ty Điện toán và Truyền số liệu (VDC), Công ty Viễn thông Quốc tế (VNPT-I), vệ tinh Vinasat 1, 2 và hạ tầng kỹ thuật của các Trung tâm Chuyển mạch Truyền dẫn thuộc 63 viễn thông tỉnh thành phố. "
  ),(
  "MGM technology",
  "Quận hải Châu, Đà Nẵng",
  "Đà Nẵng",
  "Công nghệ thông tin",
  "MGM.com",
  "../../../source/image/mgm.png",
  "MGM technology partners is a fast-growing brand where passionate doers and builders solve tough software challenges for e-commerce, commercial insurance, and the public sector. More than 850 colleagues come together at our 17 locations across Europe, North America, and Asia to execute a singular vision: Innovation Implemented. If you are looking to make the business world more technologically savvy, you’re in the right place!"
  ),(
  "FPT Software",
  "Quận Cầu Giấy, Hà Nội",
  "Hà Nội",
  "Công nghệ thông tin",
  "FPT.com",
  "../../../source/image/fpt.png",
  "FPT Software là công ty thành viên thuộc Tập đoàn FPT. Được thành lập từ năm 1999, FPT Software hiện là công ty chuyên cung cấp các dịch vụ và giải pháp phần mềm cho các khách hàng quốc tế, với hơn 28000 nhân viên, hiện diện tại 27 quốc gia trên toàn cầu. Nhiều năm liền, FPT Software được bình chọn là Nhà Tuyển dụng được yêu thích nhất và nằm trong TOP các công ty có môi trường làm việc tốt nhất Việt Nam."
  ),(
  "THANKSLAB",
  "Quận Tân Phú, Hồ Chí Minh",
  "Hồ Chí Minh",
  "Công nghệ thông tin",
  "thankslab.com",
  "../../../source/image/thankslab.png",
  "Challenge The Next Stage
Công ty chúng tôi thực hiện các dự án phát triển App của SmartPhone, phát triển Game 3D trên nền tảng Unity và phát triển các dịch vụ Web cho nhiều loại hình kinh doanh khác nhau. Thankslab là một môi trường làm việc quốc tế với nhiều thành viên đến từ nhiều quốc gia khác nhau, có kiến thức chuyên môn cùng kĩ năng cao trong việc lập trình, phát triển Game và thiết kế 3D v.v… “Challenge The Next Stage” chính là phương châm hoạt động của chúng tôi. Công nghệ thông tin luôn thay đổi và phát triển từng ngày, chính vì vậy cả công ty và nhân viên đều không thể phát triển bằng cách lặp lại những điều tương tự như ngày hôm qua."
  );

-- insert ADmin CTY----
insert into AD_CTY(ID_CTY, Tendangnhap, Matkhau, SDT, Email)
values
  (01, "vetc", "vetc1234","0865239751","vetc@gmail.com"),
  (02, "apollo", "apollo1234","0865239842","apollo@gmail.com"),
  (03, "cestudio", "cestudio1234","0865239165","cestudio@gmail.com"),
  (04, "dynu", "dynu1234","0865239368","dynu@gmail.com"),
  (05, "intratech", "intra1234","0865239157","intratech@gmail.com"),
  (06, "luvina", "luvina1234","0865239459","luvina@gmail.com"),
  (07, "brickmategroup", "brickmate1234","0865239123","brickmategroup@gmail.com"),
  (08, "netcompany", "netc1234","0865239451","netcompany@gmail.com"),
  (09, "mgmtech", "mgm1234","0865239159","mgmtech@gmail.com"),
  (10, "fptsoftware", "fpt1234","0865239157","fpt@gmail.com"),
  (11, "thankslab", "thankslab1234","0865239751","thankslab@gmail.com");
  
-- insert người tìm việc------
insert into DangViec(
  ID_CTY,
  Tencongviec,
  Loaicongviec,
  Chucvu,
  Luong,
  Linhvuc,
  Diachi,
  Email,
  SDT,
  Mota,
  Kynang,
  Thoigianlamviec,
  soluongtuyen,
  Yeucau,
  Quyenloi
  )values(
   01,
  "Java Developer",
  "1",
  "Nhân viên",
  "20000000",
  "Công nghệ thông tin",
  "Quận Nam Từ Liêm, Hà Nội",
  "vetc@gmail.com",
  "0865239751",
  "Software",
  "OOP, Oracle, Java Core, Java Spring Boot",
  "full-time",
  3,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
   01,
  "Front-end Developer",
  "1",
  "Nhân viên",
  "22000000",
  "Công nghệ thông tin",
  "Quận Nam Từ Liêm, Hà Nội",
  "vetc@gmail.com",
  "0865239751",
  "Software",
  "Frondend, ReactJS, VueJS, Angular",
  "full-time",
  3,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
   01,
  "Bussiness Analyst",
  "1",
  "Nhân viên",
  "22220000",
  "Công nghệ thông tin",
  "Quận Nam Từ Liêm, Hà Nội",
  "vetc@gmail.com",
  "0865239751",
  "Software",
  "Oracle, SQL, Bussiness Analyst",
  "full-time",
  2,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
   02,
  "DevOps Developer",
  "1",
  "Nhân viên",
  "12000000",
  "Công nghệ thông tin",
  "Quận Phú Nhuận, Hồ Chí Minh",
  "apollo@gmail.com",
  "0865239842",
  "Phần mềm",
  "DevOps, Docker, CI/CD",
  "full-time",
  2,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
   02,
  "UI/UX Designer",
  "1",
  "Nhân viên",
  "13000000",
  "Công nghệ thông tin",
  "Quận Phú Nhuận, Hồ Chí Minh",
  "apollo@gmail.com",
  "0865239842",
  "Phần mềm",
  "UI/UX Design, Photoshop, Illustrator, Sketch",
  "full-time",
  2,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
   02,
  "Software Engineer",
  "1",
  "Nhân viên",
  "15200000",
  "Công nghệ thông tin",
  "Quận Phú Nhuận, Hồ Chí Minh",
  "apollo@gmail.com",
  "0865239842",
  "Phần mềm",
  "Python, Node JS, Backend, Software Engineer",
  "full-time",
  2,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
   03,
  "Middle PHP Drupal",
  "1",
  "Nhân viên",
  "9000000",
  "Công nghệ thông tin",
  "Quận Hải Châu, Đà Nẵng",
  "cestudio@gmail.com",
  "0865239165",
  "Gia công phần mềm",
  "PHP, Magento, Drupal, Lavarel, Back-end, CI/CD",
  "full-time",
  3,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
   03,
  "Senior React",
  "1",
  "Nhân viên",
  "9000000",
  "Công nghệ thông tin",
  "Quận Hải Châu, Đà Nẵng",
  "cestudio@gmail.com",
  "0865239165",
  "Gia công phần mềm",
  "JavaScript, NodeJS, ReactJS, TypeScript",
  "full-time",
  2,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
   04,
  "QA,QC(Tester)",
  "1",
  "Nhân viên",
  "8000000",
  "Công nghệ thông tin",
  "Quận Liên Chiểu, Đà Nẵng",
  "dynu@gmail.com",
  "0865239368",
  "Phần mềm",
  "Tester, QA/QC",
  "full-time",
  1,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
   04,
  "UX/Ui Designer",
  "1",
  "Nhân viên",
  "8900000",
  "Công nghệ thông tin",
  "Quận Liên Chiểu, Đà Nẵng",
  "dynu@gmail.com",
  "0865239368",
  "Phần mềm",
  "UX/UI Designer, Photoshop, Illustrator, Sketch, After Effect, Adobe XD",
  "full-time",
  2,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
  05,
  "Middle/Intern Unity 3D Developer",
  "1",
  "Nhân viên",
  "15600000",
  "Công nghệ thông tin",
  "Thành phố Thủ Đức, Hồ Chí Minh",
  "intratech@gmail.com",
  "0865239157",
  "Software",
  "Unity, C#, Unity 3D, .NET core",
  "full-time",
  1,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
  05,
  "Middle/Intern .NET Developer",
  "1",
  "Nhân viên",
  "18000000",
  "Công nghệ thông tin",
  "Thành phố Thủ Đức, Hồ Chí Minh",
  "intratech@gmail.com",
  "0865239157",
  "Software",
  "ASP.NET, C#, .NET",
  "full-time",
  3,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
  06,
  "Team Leader(C#, Java/X++)",
  "1",
  "Nhân viên",
  "25000000",
  "Công nghệ thông tin",
  "Quận Cầu Giấy, Hà Nội",
  "luvina@gmail.com",
  "0865239459",
  "Phần mềm",
  "Java, C#, SQL, Technical Leader",
  "full-time",
  4,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
  06,
  "IT Comtor",
  "1",
  "Nhân viên",
  "30000000",
  "Công nghệ thông tin",
  "Quận Cầu Giấy, Hà Nội",
  "luvina@gmail.com",
  "0865239459",
  "Phần mềm",
  "Japanese, IT comtor",
  "full-time",
  5,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
  07,
  "3D Game Artist(English, Figma)",
  "1",
  "Nhân viên",
  "29000000",
  "Công nghệ thông tin",
  "Quận 10, Hồ Chí Minh",
  "brickmategroup@gmail.com",
  "0865239123",
  "Product, Phần mềm",
  "Game Design, UI Desgin, 3D Modelling",
  "full-time",
  2,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
  07,
  "Game Developer(Unity, English)",
  "1",
  "Nhân viên",
  "31000000",
  "Công nghệ thông tin",
  "Quận 10, Hồ Chí Minh",
  "brickmategroup@gmail.com",
  "0865239123",
  "Product, Phần mềm",
  "C#, Unity, Game Programmer",
  "full-time",
  3,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
  08,
  "Cloud DevOps Engineer(Azure)",
  "1",
  "Nhân viên",
  "23000000",
  "Công nghệ thông tin",
  "Quận Bình Thạnh, Hồ Chí Minh",
  "netcompany@gmail.com",
  "0865239451",
  "Phần mềm",
  "DevOps, Azure, CI/CD, Kubermetes",
  "full-time",
  2,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
  08,
  "IT System Operator",
  "1",
  "Nhân viên",
  "28880000",
  "Công nghệ thông tin",
  "Quận Bình Thạnh, Hồ Chí Minh",
  "netcompany@gmail.com",
  "0865239451",
  "Phần mềm",
  "Linux, Server, Network, Windows, System Engineer",
  "full-time",
  3,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
  08,
  "Network Engineer",
  "1",
  "Nhân viên",
  "18000000",
  "Công nghệ thông tin",
  "Quận Bình Thạnh, Hồ Chí Minh",
  "netcompany@gmail.com",
  "0865239451",
  "Phần mềm",
  "Cisco, CCNA, Network, LAN, CCNP",
  "full-time",
  1,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
  09,
  "Fullstack Developer(Java, ReactJS)",
  "1",
  "Nhân viên",
  "10000000",
  "Công nghệ thông tin",
  "Quận Hải Châu, Đà Nẵng",
  "mgmtech@gmail.com",
  "0865239159",
  "Phần mềm",
  "Java, SQL, Fullstack, ReactJS, HTML&CSS, Angular",
  "full-time",
  4,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
  09,
  "Java Developer",
  "1",
  "Nhân viên",
  "12300000",
  "Công nghệ thông tin",
  "Quận Hải Châu, Đà Nẵng",
  "mgmtech@gmail.com",
  "0865239159",
  "Phần mềm",
  "Java, J2EE, Spring, English-Good, Kotlin",
  "full-time",
  5,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
  10,
  "Technical Leader(.NET)",
  "1",
  "Nhân viên",
  "35000000",
  "Công nghệ thông tin",
  "Quận Cầu Giấy Hà Nội",
  "fpt@gmail.com",
  "0865239157",
  "Phần mềm",
  "ASP.NET, C#, .NET, Docker, Technical Leader, AWs, Azure, .NET core, Kubermetes",
  "full-time",
  3,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
  11,
  "Game CLient/Server Developers(C++)",
  "1",
  "Nhân viên",
  "30000000",
  "Công nghệ thông tin",
  "Quận Bình Thạnh, Hồ Chí Minh",
  "thankslab@gmail.com",
  "0865239751",
  "Giải trí/Game",
  "C++, Server, Game Developer, Game Programmer",
  "full-time",
  2,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
  11,
  "Bridge Software Engineer(BrSE)",
  "1",
  "Nhân viên",
  "32000000",
  "Công nghệ thông tin",
  "Quận Bình Thạnh, Hồ Chí Minh",
  "thankslab@gmail.com",
  "0865239751",
  "Giải trí/Game",
  "Japanese-N2, BrSE, Bridge SE",
  "full-time",
  3,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  ),(
  11,
  "Junior/Senior 3D Game Modelers",
  "1",
  "Nhân viên",
  "34000000",
  "Công nghệ thông tin",
  "Quận Bình Thạnh, Hồ Chí Minh",
  "thankslab@gmail.com",
  "0865239751",
  "Giải trí/Game",
  "Game, Photoshop, 3D Artist, 3D Max, 3D Modelling",
  "full-time",
  1,
  "Hybrid working model (1 - 2 days in office)
Long-term and stable job. Flexible working hours (Mon - Fri)
13th salary + Various bonus",
  "Chế độ lương tháng 13

 Review lương định kỳ

 Tham gia BHXH full lương theo yêu cầu

 Môi trường làm việc chuyên nghiệp, cởi mở, hòa đồng và thân thiện

 Du lịch và party định kỳ (Noel, Halloween, Tiệc cuối năm)

 Nghỉ trưa relax 1.5 tiếng

 Đuợc trang bị hai màn hình và có cơ hội tiếp xúc với các thiết bị hiện đại

 Từ thứ 2 đến thứ 6 (Sáng 8h30-12h00, Chiều 13h30-18h00)"
  );

-- Insert Người TÌm Việc --------------
insert into NguoiTimViec(
  Hoten,
  Ngaysinh,
  Gioitinh,
  Email,
  SDT,
  Linkavatar,
  Congviec,
  Loaicongviec,
  Linhvuc,
  Thanhpho,
  Diachi,
  Hocvan,
  Kynang,
  Kinhnghiem,
  Muctieu,
  Chitiet
  )values(
  "Nguyễn Trường Duy",
  "2003-01-01",
  "Nam",
  "duy@gmail.com",
  "0865931458",
  "../../../source/image/user.png",
  "Lập trình viên",
  "1",
  "Công nghệ thông tin",
  "Hồ Chí Minh",
  "Huyện Nhà Bè, Hồ CHí Minh",
  "Tốt nghiệp đại học",
  "Game, Photoshop, 3D Artist, 3D Max",
  "2 năm",
  "$3000",
  "mycv.io"
  ),(
  "Phạm Quang Đức",
  "2003-02-01",
  "Nam",
  "qduc@gmail.com",
  "0865931418",
  "../../../source/image/user.png",
  "Lập trình viên",
  "1",
  "Công nghệ thông tin",
  "Hồ Chí Minh",
  "Quận 7, Hồ CHí Minh",
  "Tốt nghiệp đại học",
  "Game, Photoshop, 3D Artist",
  "1 năm",
  "$3000",
  "mycv.io"
  ),(
  "Nguyễn Văn Tâm",
  "2003-01-06",
  "Nam",
  "tamy@gmail.com",
  "0865931178",
  "../../../source/image/user.png",
  "Lập trình viên",
  "1",
  "Công nghệ thông tin",
  "Hà Nội",
  "Quận Đống Đa, Hà Nội",
  "Tốt nghiệp đại học",
  "UI/UX Design, Photoshop",
  "dưới 1 năm",
  "$2000",
  "mycv.io"
  ),(
  "Nguyễn Quang Khải",
  "2001-02-06",
  "Nam",
  "qkhai@gmail.com",
  "0865934728",
  "../../../source/image/user.png",
  "Lập trình viên",
  "1",
  "Công nghệ thông tin",
  "Hà Nội",
  "Quận Bắc Từ Liêm, Hà Nội",
  "Tốt nghiệp đại học",
  "Frondend, ReactJS, VueJS",
  "3 năm",
  "$2000",
  "mycv.io"
  ),(
  "Trần Thị Vân",
  "2001-02-14",
  "Nữ",
  "tranvan@gmail.com",
  "0865931230",
  "../../../source/image/user.png",
  "Lập trình viên",
  "1",
  "Công nghệ thông tin",
  "Đà Nẵng",
  "Huyện Nam Hải, Đà Nẵng",
  "Tốt nghiệp cao đẳng",
  "PHP, Magento, Back-end, CI/CD",
  "2.5 năm",
  "$4000",
  "mycv.io"
  ),(
   "Trần Nhật Quang",
  "2003-02-14",
  "Nam",
  "quang@gmail.com",
  "0865931268",
  "../../../source/image/user.png",
  "Lập trình viên",
  "1",
  "Công nghệ thông tin",
  "Đà Nẵng",
  "Quận Liên Chiểu, Đà Nẵng",
  "Tốt nghiệp cao đẳng",
  "UX/UI, Designer, Photoshop",
  "2 năm",
  "$2500",
  "mycv.io"
  );
  
-- insert ADMIN người tìm việc----
insert into AD_NTV(
  ID_NTV,
  Tendangnhap,
  Matkhau,
  Email
  )values(
  01,
  "duyga16",
  "duy1234",
  "duy@gmail.com"
  ),(
  02,
  "quangduc02",
  "duc1234",
  "qduc@gmail.com"
  ),(
  03,
  "vantam03",
  "tam1234",
  "tamy@gmail.com"
  ),(
  04,
  "quangkhai04",
  "khai1234",
  "qkhai@gmail.com"
  ),(
  05,
  "tranvan02",
  "van1234",
  "tranvan@gmail.com"
  ),(
  06,
  "quang06",
  "quang1234",
  "quang@gmail.com"
  );
  
-- insert ứng tuyển--------
insert into Ungtuyen(
  Daduyet,
  ID_NTV,
  ID_Dangviec
  )values(-1,01,03),
  (0,02,04),
  (1,03,05);
  
  -- insert công việc được mời--------
insert into CongViecDuocMoi(
  ID_CTY,
  ID_NTV,
  Daduyet
  )values(04,02,-1),
  (01,05,0),
  (10,01,1);
  
  
-- insert LuuNTV----
insert into LuuNTV(
  ID_NTV,
  ID_CTY
  )values(01,11),
  (03,02),
  (04,03),
  (06,07);
  
-- insert LuuCTY----
insert into LuuCTY(
  ID_NTV,
  ID_CTY,
  ID_Dangviec
  )values(02,10,13),
  (03,05,15),
  (01,08,04),
  (06,05,06);

  
  
