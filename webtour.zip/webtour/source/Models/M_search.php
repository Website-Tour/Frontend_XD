<?php
class M_search{
    public function searchFromUser($value,$filter,$salary){
        require_once "../Login/database.php";
        $value = isset($_POST["value"]) ? $_POST["value"] : "%";
        $filter = isset($_POST["filter"]) ? $_POST["filter"] : "%";
        if ($salary =="-1")
        $sql = "SELECT * FROM DangViec WHERE 
                                    (Tencongviec LIKE '%$value%' 
                                    OR Diachi LIKE '%$value%' 
                                    OR Kynang LIKE '%$value%' 
                                    OR Linhvuc LIKE '%$value%' 
                                    OR Luong LIKE '%$value%' 
                                    OR Chucvu LIKE '%$value%') 
                                    AND Loaicongviec LIKE '%$filter%'";
        else if ($salary =="1")
        $sql = "SELECT * FROM DangViec WHERE 
                        (Tencongviec LIKE '%$value%' 
                        OR Diachi LIKE '%$value%' 
                        OR Kynang LIKE '%$value%' 
                        OR Linhvuc LIKE '%$value%' 
                        OR Luong LIKE '%$value%' 
                        OR Chucvu LIKE '%$value%') 
                        AND Loaicongviec LIKE '%$filter%'
                        ORDER BY CAST(Luong AS UNSIGNED) DESC"; // sắp xếp theo lương giảm dần
        else 
        $sql = "SELECT * FROM DangViec WHERE 
                    (Tencongviec LIKE '%$value%' 
                    OR Diachi LIKE '%$value%' 
                    OR Kynang LIKE '%$value%' 
                    OR Linhvuc LIKE '%$value%' 
                    OR Luong LIKE '%$value%' 
                    OR Chucvu LIKE '%$value%') 
                    AND Loaicongviec LIKE '%$filter%'
                    ORDER BY CAST(Luong AS UNSIGNED) ASC"; // sắp xếp theo lương tăng dần

        // Thực hiện truy vấn và lưu kết quả vào biến $result
        $result = $conn->query($sql);
        return $result;
    }
}

?>