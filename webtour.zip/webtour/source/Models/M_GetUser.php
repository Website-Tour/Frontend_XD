<?php
class Model_GetUser{
    // public function getUser($id){
    //     // session_start();
    //     require("../Login/database.php");
    //     $sql = $conn -> query("SELECT Hoten,Linkavatar FROM NguoiTimViec WHERE ID_NTV = '$id';");
    //     if ($sql) 
    //         return $sql;
    //     else {
    //         die("Can't get job from database");
    //     }
    // }
    public function getAllInfoUser($id){
        require("../Login/database.php");
        $sql = $conn -> query("SELECT * FROM NguoiTimViec INNER JOIN AD_NTV
        ON NguoiTimViec.ID_NTV = AD_NTV.ID_NTV
        WHERE NguoiTimViec.ID_NTV = '$id';");
        if ($sql) 
            return $sql;
        else {
            die("Can't get job from database");
        }
    }
    // public function getAllUser(){
    //     require("../Login/database.php");
    //     $sql = $conn -> query("SELECT * FROM NguoiTimViec INNER JOIN AD_NTV 
    //     ON NguoiTimViec.ID_NTV = AD_NTV.ID_NTV
    //     ;");
    //     if ($sql) 
    //         return $sql;
    //     else {
    //         die("Can't get job from database");
    //     }
    // }
    // public function getUserWithID($id){
    //     require("../Login/database.php");
    //     $sql = $conn -> query("SELECT * FROM NguoiTimViec INNER JOIN AD_NTV 
    //     ON NguoiTimViec.ID_NTV = AD_NTV.ID_NTV
    //     WHERE NguoiTimViec.ID_NTV = '$id';");
    //     if ($sql) 
    //         return $sql;
    //     else {
    //         die("Can't get job from database");
    //     }
    // }
}
?>