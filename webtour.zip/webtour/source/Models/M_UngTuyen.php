<?php
class Model_UngTuyenNgay
{
    public function ungTuyenNgay($iduser, $idbaidang)
    {
        require("./Login/database.php");
        $test = "SELECT * from Ungtuyen where ID_Dangviec = '$idbaidang' and ID_NTV = '$iduser'";
        $num = mysqli_num_rows($conn->query($test));
        if ($num ==0){
            $sql = "INSERT INTO Ungtuyen(
                Daduyet,
                ID_Dangviec,
                ID_NTV
            )
            values(-1,$idbaidang,$iduser);";
            if ($conn->query($sql) === TRUE) {
                return 1;
            } else {
                return 0;
            }
        } else return 0;
        $conn->close();
    }
    public function tuyenNgay($idcongty, $iduser){
        require("Login/database.php");
        $test = "SELECT * from CongViecDuocMoi where ID_CTY = '$idcongty' and ID_NTV = '$iduser'";
        $num = mysqli_num_rows($conn->query($test));
        if ($num ==0){
            $sql = "INSERT INTO CongViecDuocMoi(
                daduyet,
                ID_CongTy,
                ID_user
            )
            values(-1,$idcongty,$iduser);";
            if ($conn->query($sql) === TRUE) {
                return 1;
            } else {
                return 0;
            }
        } else return 0;
        $conn->close();
    }
}
