<?php
class Model_updateUser{
    public function updateUser($changepass,$passnow,$id,$hoten,$congviec,$ngaysinh,$gioitinh,$loaicongviec,$linhvuc,$sdt,$email,$thanhpho,$diachi,$muctieunghenghiep,$hocvan,$kinang,$kinhnghiem,$chitiet){
        require("../Login/database.php");
        $sql = $conn -> query("UPDATE NguoiTimViec SET 
            Hoten = '$hoten', Congviec = '$congviec', 
            Ngaysinh = '$ngaysinh', Loaicongviec = '$loaicongviec', 
            Gioitinh = '$gioitinh',
            Linhvuc = '$linhvuc', Thanhpho = '$thanhpho',
            Diachi = '$diachi', Muctieu = '$muctieunghenghiep', 
            Hocvan = '$hocvan', Kynang = '$kinang', 
            Kinhnghiem = '$kinhnghiem', Chitiet = '$chitiet'
        WHERE ID_NTV = $id");
        // $sql2 = $conn -> query("UPDATE AD_NTV SET
        //     sdt = '$sdt', email = '$email'
        // WHERE ID_NTV = '$id'");
        // if ($sql && $sql2)
        $sql2 = $conn->query("SELECT * FROM AD_NTV WHERE Matkhau = '$passnow'");
        if ($sql2->num_rows == 1 || $changepass==false) {
          $sql2 = 1;
        } else {
          $sql2 = 0;
        }
        if ($sql && $sql2)
        return 1;
        else return 0;
    }
    public function updatePass($userid, $passNew){
        require("../Login/database.php");
        $sql = $conn -> query("UPDATE AD_NTV SET 
            Matkhau = '$passNew'
        WHERE ID_NTV = $userid");
        if ($sql) return 1;
        else return 0;
    }
    // public function dangviecAdmin($idcongty,$tencongviec,$yeucaubangcap,$linhvuc,$chucvu,$luong,$loaicongviec,$diachi,$soluongtuyendung,$sdt,$thoihan, $email,$motacongviec,$quyenloi,$yeucaucongviec){
    //     require("../connection.php");
    //     $sql = $conn -> query("
    //     insert into DangViec(
    //         ID_CongTy,
    //         tencongviec,
    //         linhvuc,
    //         chucvu,
    //         luong,
    //         loaicongviec,
    //         diachi,
    //         sdt,
    //         email,
    //         motacongviec,
    //         tagkinang,
    //         yeucaubangcap,
    //         yeucaucongviec,
    //         quyenloi,
    //         thoihan,
    //         soluongtuyendung
    //     )
    //     values('$idcongty','$tencongviec','$linhvuc','$chucvu','$luong','$loaicongviec','$diachi',$sdt,'$email','$motacongviec','$tagkinang','$yeucaubangcap','$yeucaucongviec','$quyenloi','$thoihan','$soluongtuyendung');
    //     ");
    //     if ($sql) return 1;
    //     else return 0;
    // }
    // public function updateAdmin($id,$TenCongTy,$linhvuc,$website,$sdt,$email,$thanhpho,$diachi,$motacongty,$phucloi){
    //     require("../connection.php");
    //     $sql = $conn -> query("UPDATE CongTy SET 
    //         TenCongTy = '$TenCongTy', linhvuc = '$linhvuc', 
    //         website = '$website',
    //         thanhpho = '$thanhpho', motacongty = '$motacongty',
    //         diachi = '$diachi', phucloi = '$phucloi'
    //     WHERE ID_CongTy = '$id'");
    //     $sql2 = $conn -> query("UPDATE Admin SET
    //         sdt = '$sdt', email = '$email'
    //     WHERE ID_CongTy = '$id'");
    //     if ($sql && $sql2)
    //     return 1;
    //     else return 0;
    // }
}