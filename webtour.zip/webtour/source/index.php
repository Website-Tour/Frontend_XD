<?php
    // kiểm tra có sesion rồi thì về homeuser
    session_start();
    if(isset($_SESSION["user_id"])){
        $user_home = './User/userhome.php';
        // include('final web/User/index.php');
        header("Location: $user_home");
        exit;
    }
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link  href = "style.css" rel = "stylesheet">  
    
    <!-- font -->
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@1,700&family=Tilt+Warp&display=swap" rel="stylesheet">
    <!-- icons -->
    
    <link href=" https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" rel = "stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <title> Choose A Job, Decide Your Future</title>
</head>
<body>
    <header>
        <nav class = "navbar navbar-expand-md bg">
            <a style="text-decoration: none;" href="" class = "narbar-brand fs-3 ms-5 text-white" >ITCompany</a>

            <button class="navbar-toggler me-3 text-white" type="button" data-bs-toggle="collapse" data-bs-target="#btn"><i class = 'bx bx-menu bx-md'></i></button>
            <div class="collapse navbar-collapse ul-bg" id="btn">
                <ul class="navbar-nav ms-auto" >
    
                    <li class = "nav-item">
                        <a href="Login/login.php"  class="nav-link mx-4 text-white fs-8">Tìm Việc</a>
                    </li>
                    
                    <li class = "nav-item">
                        <a href="Login/login.php"class="nav-link mx-4 text-white fs-8">Đăng Tuyển</a>
                    </li>
                    <li class = "nav-item">
                        <a href="Login/login.php"class="nav-link mx-4 text-white fs-8">Tạo CV</a>
                    </li>
                    <li class = "nav-item">
                        <a href="Login/login.php" class="nav-link mx-4 text-white fs-8">Đăng Nhập</a>
                    </li>
                </ul>
                
            </div>
        </nav>  
    </header>

    


    <!-- showcase -->

<div>
    <style>
        .section-background {
            background-image: url("image/a.png");
            background-size: cover;
            background-position: center center;
            background-repeat: no-repeat;
        }
    </style>
        <!-- service -->
    <section class="p-5 text-center text-sm-start section-background" style="margin-top: 48px;">
        <br>
        <div class = "container">
            <!-- <div class = "d-sm-flex"> -->
            <div class="">
                <div>
                    <h1> Find your IT job</h1>
                    <p class="lead my-4">We are here for you to find your dream job</li><br>
                    <br>        
                </div>    
            </div>
            <div class = "search-wrapper">
                <div class = "search-box">
                    <div class = "search-card">
                        <input class = "search-input" type = "text" placeholder="Find A Job That You Want...">
                        <div>
                            <button class ="search-button"><img src ="image/search.png" ></button>
                        </div>
                    </div>
                </div>
            </div>

            <div>
                <div class="filter-box">
                    <select class = "filter-select" id="job-level" name="job-level">
                        <option>Job Level</option>
                        <option>Entry</option>
                        <option>Mid-Senior</option>
                        <option>Director</option>
                    </select>
                    
                    <select class = "filter-select" id="employment" name="employment">
                        <option>Employment Type</option>
                        <option>Part Time</option>
                        <option>Full Time</option>
                    </select>
                    <select class = "filter-select" id="location" name="location">
                        <option>Locations</option>
                        <option>Ha Noi</option>
                        <option>Tp Ho Chi Minh</option>
                    </select>
                </div>
            </div>
           
        </div>
    </section>

    <!-- box -->

    <style>
        .card {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            width: 270px;
            height: 400px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            overflow: hidden;
        }
        .card-image img {
        width: 100%;
        height: 190px;
        object-fit: cover;
        }
    </style>
    
    <!-- High Salary j do -->
    <section class = "p-5">
        <div class = "container">
            <div class = "d-sm-flex sx-textcenter">
                <!-- <div class=""> -->
                <div>
                    <h3>Top Employers</h3>
                    <br>        
                </div>
                    
            </div>
            <div class = "row text-center g-4">
                
            <?php
                $mysql = require_once "Login/database.php";
                $sql = "SELECT * FROM CONGTY";

                // Thực hiện truy vấn và lưu kết quả vào biến $result
                $result = $conn->query($sql);

                // Kiểm tra số lượng bản ghi trả về có lớn hơn 0 hay không
                if ($result->num_rows > 0) {
                // Lặp qua từng bản ghi và in ra dữ liệu
                    while($row = $result->fetch_assoc()) {
                        for ($i = 1; $i < 5; $i++){
                            if($i==$row["ID_CTY"]){
                        //echo "ID: " . $row["ID_CTY"] . " - Name: " . $row["TenCTY"] . " - Email: " . $row["diachi"] . "<br>";
                                $image = "image/ig".$i.".png";
                                // if($row["ID_CTY"]==$row2["ID_CTY"]){

                                //     $count += 1;
                                // }

                                    echo 
                                        '<div class="col-xs-12 col-lg-3 col-md-6 col-sm-6">
                                            <div class="card">
                                                <div class="card-image" style="width=100%">
                                                    <img src="' . $image . '">
                                                </div>
                                                <div class="card-content">
                                                    <h3 class="card-title">' . $row["TenCTY"] .  '</h3>
                                                    <p><i class="fa-solid fa-location-dot"> </i>'. $row["diachi"] . '</p>
                                                    <p>'. $row["linhvuc"] . '</p>
                                                </div>
                                                <div class="card-action">
                                                    <a href="Login/login.php" style="color: #336B87;">More Information</a>
                                                </div>  
                                            </div>
                                        </div>';

                                
                            }
                        }
                    }
                } else {
                echo "0 results";
                }

            ?>

            </div>
    </section>

    <section class = "p-5">
        <div class = "container">
            <div class = "d-sm-flex sx-textcenter">
                <!-- <div class=""> -->
                <div>
                    <h3>Top High Salary</h3>
                    <br>        
                </div>
                    
            </div>
            <div class = "row text-center g-4">
                
            <?php
                $mysql = require_once "Login/database.php";
                $sql = "SELECT * FROM DangViec";

                // Thực hiện truy vấn và lưu kết quả vào biến $result
                $result = $conn->query($sql);

                // Kiểm tra số lượng bản ghi trả về có lớn hơn 0 hay không
                if ($result->num_rows > 0) {
                // Lặp qua từng bản ghi và in ra dữ liệu
                while($row = $result->fetch_assoc()) {
                    for ($i = 10; $i < 13; $i++){
                        if($i==$row["ID_CTY"]){
                    //echo "ID: " . $row["ID_CTY"] . " - Name: " . $row["TenCTY"] . " - Email: " . $row["diachi"] . "<br>";
                            $image = "image/ig".$i.".png";
                            $luong = number_format($row["Luong"], 0, ",", ".") . " VND";
                            echo 
                                '<div class="col-xs-12 col-lg-3 col-md-6 col-sm-6">
                                    <div class="card">
                                        <div class="card-image">
                                            <img src="' . $image . '">
                                        </div>
                                        <div class="card-content">
                                            <h3 class="card-title">' . $row["Tencongviec"] .  '</h3>
                                            <p><i class="fa-solid fa-location-dot"> </i> '. $row["Diachi"] . '</p>
                                            <p>'. $row["Linhvuc"] . '</p>
                                             <p><i class="fa-solid fa-money-bill"></i>'.$luong.'</p>
                                        </div>
                                        <div class="card-action">
                                            <a href="Login/login.php" style="color: #336B87;">More Information</a>
                                        </div>  
                                    </div>
                                </div>';
                        }
                    }
                }
                } else {
                echo "0 results";
                }

            ?>

            </div>
    </section>
    <section class = "p-5" style="margin-top: 30px;">
        <div class = "container">
            <div class = "d-sm-flex sx-textcenter">
                <!-- <div class=""> -->
                <div>
                    <h3>IT Jobs</h3>
                    <br>        
                </div>
                    
            </div>                
            <div class = "row text-center g-4" action="">
                
            <?php
                $mysql = require_once "Login/database.php";
                $sql = "SELECT * FROM DangViec";

                // Thực hiện truy vấn và lưu kết quả vào biến $result
                $result = $conn->query($sql);

                // Kiểm tra số lượng bản ghi trả về có lớn hơn 0 hay không
                if ($result->num_rows > 0) {
                // Lặp qua từng bản ghi và in ra dữ liệu
                while($row = $result->fetch_assoc()) {

                    //echo "ID: " . $row["ID_CTY"] . " - Name: " . $row["TenCTY"] . " - Email: " . $row["diachi"] . "<br>";
                        $image = "image/ig".$row["ID_CTY"].".png";

                        echo 
                            '<div class="col-xs-12 col-lg-3 col-md-6 col-sm-6">
                                <div class="card">
                                    <div class="card-image">
                                        <img src="' . $image . '">
                                    </div>
                                    <div class="card-content">
                                        <h3 class="card-title">' . $row["Tencongviec"] .  '</h3>
                                        <p>'. $row["Diachi"] . '</p>
                                        <p>'.$row["Kynang"].'</p>
                                    </div>
                            
                                    <div class="card-action">
                                        <a href="Login/login.php" style="color: #336B87;">More Information</a>
                                    </div>  
                                </div>
                            </div>';
                        }
                    
                }
                // } else {
                // echo "0 results";
                // }

            ?>  

            </div>
            <br><br>
           
        </div>
    </section>
</div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>

    <!-- footer -->

    <style>
        a {
            color: #BCBABE;
        }
        strong{
            color: #BCBABE;
        }
    </style>

    <footer class="bg-dark text-white pt-5 pb4">

        <div class = "container text-center text-md-left">

            <div class =" row text-center g-4 text-md-left">
                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>About</h3><br>
                        <!-- <p><a href="#" >about us</a></li> -->
                        <p><a href="#" >our services</a></li>
                        <p><a href="#" >privacy policy</a></li>
                        <p><a href="#" >affiliate program</a></li>
                    

                </div>

                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>Company</h3><br>
                        <p><a href="#" >about us</a></li>
                        <p><a href="#" >our services</a></li>
                        <p><a href="#" >privacy policy</a></li>
                </div>
                

                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3 >Get Help</h3><br>
                    
                        <p><a href="#" >FAQ</a></li>
                        <p><a href="#" >Contact</a></li>
        
                </div>
                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>follow us</h3><br>
                    <div class="social-links">
                        <a href="#" ><i class="fab fa-facebook-f"></i></a>
                        <a href="#" ><i class="fab fa-twitter"></i></a>
                        <a href="#" ><i class="fab fa-instagram"></i></a>
                        <a href="#" ><i class="fab fa-linkedin-in"></i></a>
                    </div>

                </div>
                
            </div>

            <hr class="mb-4">
            <div class="row align-items-center">
                <div class="col-md-7 col-lg-8">
                    <b>Copyright @2022 All rights reserved by:
                        <a href=""# style="text-decoration: none;">
                            <strong class=" text-white">Pham Company</strong>
                        </a>
                    </b>
                    <p style="font-size: medium; color:#BCBABE;"> Contact: Ho Chi Minh:(+84) 0965323966 - Email: PhamCompany@gmail.com</li>
                    
                </div>
                
            </div>
            
        </div>

    </footer>

</body>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>