<?php
class C_bookmark{
    public function savetobookmark($idbaidang,$idcty){
        session_start();
        require("../Login/database.php");
        
        // Kiểm tra xem dữ liệu đã tồn tại trong cơ sở dữ liệu hay chưa
        $sql_check = "SELECT * FROM LuuCTY WHERE ID_NTV = ? AND ID_CTY = ? AND ID_DangViec = ?";
        $stmt_check = $conn->prepare($sql_check);
        $stmt_check->bind_param("iii", $_SESSION["user_id"], $idcty, $idbaidang);
        $stmt_check->execute();
        $result = $stmt_check->get_result();
        
        // Nếu dữ liệu đã tồn tại, trả về status = 0
        if ($result->num_rows > 0) {
            echo json_encode(array("status" => 0,"message"=> "bài viết này đã được thêm"));
        } else {
            // Nếu dữ liệu chưa tồn tại, thêm mới vào cơ sở dữ liệu
            $sql_insert = "INSERT INTO LuuCTY (ID_NTV, ID_CTY, ID_DangViec) VALUES (?, ?, ?)";
            $stmt_insert = $conn->prepare($sql_insert);
            $stmt_insert->bind_param("iii", $_SESSION["user_id"], $idcty, $idbaidang);
            if ($stmt_insert->execute()) {
                echo json_encode(array("status" => 1));
            } else {
                echo json_encode(array("status" => 0));
            }
        }
    }
}
$c_bookmark = new C_bookmark();

$c_bookmark -> savetobookmark($_POST["idbaidang"],$_POST["idcty"]);
?>