<?php
class C_inforAdmin{
    public function getAll(){
        session_start();
        require("../Login/database.php");
        $id = $_SESSION["company_id"];
        $user = $conn -> query("SELECT * FROM CONGTY INNER JOIN AD_CTY
        ON CONGTY.ID_CTY = AD_CTY.ID_CTY
        WHERE CONGTY.ID_CTY = '$id';");
        $data = array();
        while ($r = $user->fetch_assoc()) {
            $data[] = ["TenCTY" => $r["TenCTY"], "diachi" => $r["diachi"],"thanhpho" => $r["thanhpho"],"linhvuc" => $r["linhvuc"],"website" => $r["website"],"linkavatar" => $r["linkavatar"],"mota" => $r["mota"]];
        }
        echo json_encode($data[0]);
    }
    public function update($form_data){
        session_start();
        require("../Login/database.php");
        $form_data = urldecode($form_data); // Decode the form data string
        parse_str($form_data, $form_data_array); // Parse the form data into an array
        // var_dump($data["tencongviec"]);
        $TenCTY = $form_data_array["TenCTY"];
        $diachi = $form_data_array["diachi"];
        $thanhpho  = $form_data_array["thanhpho"];
        $linhvuc = $form_data_array["linhvuc"];
        $website = $form_data_array["website"];
        // $linkavatar = $form_data_array["linkavatar"];
        $mota = $form_data_array["mota"];
        $id = $_SESSION["company_id"];
        $mota = $form_data_array["mota"];
        $matkhau = $form_data_array["passNow"];
        $matkhaumoi = $form_data_array["newpass"];
        $matkhauconfirm = $form_data_array["confirmPass"];
        $res2 = $conn->query("SELECT * FROM AD_CTY WHERE Matkhau = '$matkhau'");
        // var_dump($res2->num_rows);
        if ($res2->num_rows == 0 && (isset($form_data_array["changepass"]) &&$form_data_array["changepass"]=="on")){
          echo json_encode(array("status"=>0,"message"=>"mật khẩu không đúng"));
          return;
        } else {
            $sql = $conn -> query("UPDATE CONGTY SET
            TenCTY = '$TenCTY',
                    diachi = '$diachi',
                    thanhpho = '$thanhpho',
                    linhvuc = '$linhvuc',
                    website = '$website',
                    linkavatar = '../image/ig12.png',
                    mota = '$mota'
                    WHERE ID_CTY = '$id'");
            if (isset($form_data_array["changepass"])&&$form_data_array["changepass"]=="on"){
                if ($matkhauconfirm === $matkhaumoi){
                    $sql = $conn -> query("UPDATE AD_CTY SET 
                        Matkhau = '$matkhaumoi'
                    WHERE ID_CTY = $id");
                    if ($sql) $res2 =  1;
                } else $res2 =0;
            } else $res2 = 1;
            if ($sql && $res2){
                echo json_encode(array('status' => 1));
            }
            else {
                if ($res2 ==0){
                    echo json_encode(array('status' => 0,"message"=>"Mật khẩu không khớp!"));
                    return;
                }
                echo json_encode(array('status' => 0,"message"=>"Cập nhật không thành công!"));
            }
        }
    }
}

$C_inforAdmin = new C_inforAdmin();
if (isset($_POST["type"])){
    if ($_POST["type"]=="0"){
        $C_inforAdmin -> update($_POST["formData"]);
    } else if ($_POST["type"]=="1"){
        $C_inforAdmin -> getAll();
    }
}
?>