<?php
class updateUser{
    public function updateCLient($changepass,$passnow,$newpass,$confirmpass,$hoten,$congviec,$ngaysinh,$gioitinh,$loaicongviec,$linhvuc,$sdt,$email,$thanhpho,$diachi,$muctieunghenghiep,$hocvan,$kinang,$kinhnghiem,$chitiet){
        session_start();
        require_once("../Models/M_updateUser.php");
        $Model_updateUser = new Model_updateUser();
        $res = $Model_updateUser -> updateUser($changepass,$passnow,$_SESSION["user_id"],$hoten,$congviec,$ngaysinh,$gioitinh,$loaicongviec,$linhvuc,$sdt,$email,$thanhpho,$diachi,$muctieunghenghiep,$hocvan,$kinang,$kinhnghiem,$chitiet);
        if ($changepass=="on"){
            if ($confirmpass === $newpass){
                $res2 = $Model_updateUser -> updatePass($_SESSION["user_id"],$newpass);
            } else $res2 =0;
        } else $res2 = 1;
        if ($res && $res2){
            echo json_encode(array('status' => 1));
        }
        else echo json_encode(array('status' => 0));
    }
    // public function dangviecAdmin($tencongviec,$yeucaubangcap,$linhvuc,$chucvu,$luong,$loaicongviec,$diachi,$soluongtuyendung,$sdt,$thoihan, $email,$motacongviec,$quyenloi,$yeucaucongviec){
    //     session_start();
    //     require_once("../Models/Model_updateUser.php");
    //     $Model_updateUser = new Model_updateUser();
    //     $res = $Model_updateUser -> dangviecAdmin($_SESSION["IDUser"],$tencongviec,$yeucaubangcap,$linhvuc,$chucvu,$luong,$loaicongviec,$diachi,$soluongtuyendung,$sdt,$thoihan, $email,$motacongviec,$quyenloi,$yeucaucongviec,$tagkinang);
    //     if ($res){
    //         header("Location: C_SignIn.php");
    //     }
    //     else echo "khong dang bai thanh cong ";
    // }
    // public function updateAdmin($TenCongTy,$linhvuc,$website,$sdt,$email,$thanhpho,$diachi,$motacongty,$phucloi){
    //     session_start();
    //     require_once("../Models/Model_updateUser.php");
    //     $Model_updateUser = new Model_updateUser();
    //     $res = $Model_updateUser -> updateAdmin($_SESSION["IDUser"],$TenCongTy,$linhvuc,$website,$sdt,$email,$thanhpho,$diachi,$motacongty,$phucloi);
    //     if ($res){
    //         header("Location: C_SignIn.php");
    //     }
    //     else echo "khong cap nhat thanh cong ";
    // }
}
$updateUser = new UpdateUser();
if (isset($_POST["dviec"])){
    // $updateUser -> dangviecAdmin($_POST["tencongviec"],$_POST["yeucaubangcap"],$_POST["linhvuc"],$_POST["chucvu"],$_POST["luong"],$_POST["loaicongviec"],$_POST["diachi"],$_POST["soluongtuyendung"],$_POST["sdt"],$_POST["thoihan"],$_POST["email"],$_POST["motacongviec"],$_POST["quyenloi"],$_POST["yeucaucongviec"],$_POST["tagkinang"]);
}else if (isset($_POST["updateAdmin"])){
    // $updateUser -> updateAdmin($_POST["TenCongTy"],$_POST["linhvuc"],$_POST["website"],$_POST["sdt"],$_POST["email"],$_POST["thanhpho"],$_POST["diachi"],$_POST["motacongty"],$_POST["phucloi"]);
}
else{
    if (isset($_POST["changepass"]))
        $change = $_POST["changepass"];
    else $change = false;
$updateUser -> updateCLient($change,$_POST["passNow"],$_POST["newpass"],$_POST["confirmPass"],$_POST["hoten"],$_POST["congviec"],$_POST["ngaysinh"],$_POST["gioitinh"],$_POST["loaicongviec"],$_POST["linhvuc"],$_POST["sdt"],$_POST["email"],$_POST["thanhpho"],$_POST["diachi"],$_POST["muctieunghenghiep"],$_POST["hocvan"],$_POST["kinang"],$_POST["kinhnghiemlamviec"],$_POST["chitiet"]);
}