<?php
class C_search{
    public function getFilterFromUser($value,$filter,$salary){
        require_once("../Models/M_search.php");
        $M_search = new M_search();
        // $value = $_POST["value"] == "" ? $_POST["value"] : "%";
        // $filter = $_POST["filter"] == "" ? $_POST["filter"] : "%";
        $res = $M_search->searchFromUser($value,$filter,$salary);
        $data = array();
        while ($r = $res->fetch_assoc())
        {
            $data[] = ["Luong"=>$r["Luong"],"soluongtuyen"=>$r["soluongtuyen"],"Diachi"=>$r["Diachi"],"Tencongviec"=>$r["Tencongviec"],"Kynang"=>$r["Kynang"],"ID_CTY"=>$r["ID_CTY"],"ID_Dangviec"=>$r["ID_Dangviec"]];
        }
        echo json_encode($data);
    }
}

$C_search = new C_search();
$C_search -> getFilterFromUser($_POST["value"],$_POST["filter"],$_POST["filterSalary"]);

?>