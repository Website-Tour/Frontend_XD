<?php
class C_InfoUser{
    // public function getOnlyId(){
    //     session_start();
    //     require_once("Models/M_GetUser.php");
    //     $Model_GetUser = new Model_GetUser();
    //     $iduser = $Model_GetUser -> getUser($_SESSION['user_id']);
    //     $data = array();
    //     while ($r = $iduser->fetch_assoc()) {
    //         $data[] = ["type"=>"Client","Hoten" => $r["Hoten"], "Linkavatar" => $r["Linkavatar"]];
    //     }
    //     echo json_encode($data[0]);
    // }
    public function getAll(){
        session_start();
        require_once("../Models/M_GetUser.php");
        $Model_GetUser = new Model_GetUser();
        $user = $Model_GetUser -> getAllInfoUser($_SESSION['user_id']);
        $data = array();
        while ($r = $user->fetch_assoc()) {
            $data[] = ["Hoten" => $r["Hoten"], "Linkavatar" => $r["Linkavatar"],"Congviec" => $r["Congviec"],"Thanhpho" => $r["Thanhpho"],"Loaicongviec" => $r["Loaicongviec"],"ngaysinh" => $r["Ngaysinh"],"gioitinh" => $r["Gioitinh"],"linhvuc" => $r["Linhvuc"],"diachi" => $r["Diachi"],"muctieunghenghiep" => $r["Muctieu"],"hocvan" => $r["Hocvan"],"Kynang" => $r["Kynang"],"kinhnghiem" => $r["Kinhnghiem"],"chitiet" => $r["Chitiet"],"SDT" => $r["SDT"],"Email" => $r["Email"]];
        }
        echo json_encode($data[0]);
        // return json_encode($data[0]);
    }
    // public function getAllUser(){
    //     require_once("../Models/M_GetUser.php");
    //     $Model_GetUser = new Model_GetUser();
    //     $user = $Model_GetUser -> getAllUser();
    //     $data = array();
    //     while ($r = $user->fetch_assoc()) {
    //         $data[] = ["Thanhpho"=>$r["Thanhpho"],"Loaicongviec"=>$r["Loaicongviec"],"id" => $r["ID_NTV"],"hoten" => $r["Hoten"], "linkava" => $r["Linkavatar"],"congviec" => $r["Congviec"],"ngaysinh" => $r["Ngaysinh"],"gioitinh" => $r["Gioitinh"],"linhvuc" => $r["Linhvuc"],"diachi" => $r["Diachi"],"muctieu" => $r["Muctieu"],"hocvan" => $r["Hocvan"],"kinang" => $r["Kynang"],"kinhnghiem" => $r["Kinhnghiem"],"chitiet" => $r["Chitiet"],"sdt" => $r["SDT"],"email" => $r["Email"]];
    //     }
    //     echo json_encode($data);
    // }
    // public function getUserWithID($id){
    //     session_start();
    //     require_once("../Models/M_GetUser.php");
    //     $Model_GetUser = new Model_GetUser();
    //     $user = $Model_GetUser -> getUserWithID($id);
    //     $data = array();
    //     while ($r = $user->fetch_assoc()) {
    //         $data[] = ["ID_user"=>$r["ID_NTV"],"thanhpho"=>$r["Thanhpho"],"loaicongviec"=>$r["Loaicongviec"],"hoten" => $r["Hoten"], "linkava" => $r["Linkavatar"],"congviec" => $r["Congviec"],"ngaysinh" => $r["Ngaysinh"],"gioitinh" => $r["Gioitinh"],"linhvuc" => $r["Linhvuc"],"diachi" => $r["Diachi"],"muctieu" => $r["Muctieu"],"hocvan" => $r["Hocvan"],"kinang" => $r["Kynang"],"kinhnghiem" => $r["Kinhnghiem"],"Chitiet" => $r["Chitiet"],"SDT" => $r["SDT"],"Email" => $r["Email"]];
    //     }
    //     echo json_encode($data[0]);
    // }

}

$C_InfoUser = new C_InfoUser();
if (isset($_POST["type"])){
    if ($_POST["type"]=="0"){
        // $C_InfoUser -> getOnlyId();
    } else if ($_POST["type"]=="1"){
        $C_InfoUser -> getAll();
    // } else if ($_POST["type"]=="2"){
        // $C_InfoUser -> getAllUser();
    // } else{
        // $C_InfoUser -> getUserWithID($_POST["iduser"]);
    }

}
?>