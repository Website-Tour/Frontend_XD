<?php
class C_Dangbai{
    public function upload($form_data){
        session_start();
        require("../Login/database.php");
        $data = array();
        parse_str($form_data, $data);
        if (
            !isset($data["tencongviec"]) || $data["tencongviec"] == "" ||
            !isset($data["loaicongviec"]) || $data["loaicongviec"] == "" ||
            !isset($data["chucvu"]) || $data["chucvu"] == "" ||
            !isset($data["luong"]) || $data["luong"] == "" ||
            !isset($data["linhvuc"]) || $data["linhvuc"] == "" ||
            !isset($data["diachi"]) || $data["diachi"] == "" ||
            !isset($data["email"]) || $data["email"] == "" ||
            !isset($data["sdt"]) || $data["sdt"] == "" ||
            !isset($data["mota"]) || $data["mota"] == "" ||
            !isset($data["kynang"]) || $data["kynang"] == "" ||
            !isset($data["yeucau"]) || $data["yeucau"] == "" ||
            !isset($data["quyenloi"]) || $data["quyenloi"] == "" ||
            !isset($data["soluongtuyen"]) || $data["soluongtuyen"] == ""
        ) {
            // var_dump($data);
            echo json_encode(array("status" => 0,"message"=> "Nhập đầy đủ các trường"));
            return;
        }
        $sql_insert = "INSERT INTO DangViec (
                                Tencongviec, Loaicongviec,
                                Chucvu, Luong,
                                Linhvuc, Diachi,
                                Email, SDT,
                                Mota, Kynang,
                                Thoigianlamviec, Yeucau,
                                Quyenloi, soluongtuyen,
                                ID_CTY) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        $stmt_insert = $conn->prepare($sql_insert);
        $thoigianlamviec = $data["loaicongviec"]=="1"?"Toàn thời gian":"Bán thời gian";
        $stmt_insert->bind_param("sssssssssssssii", 
                    $data["tencongviec"], $data["loaicongviec"],
                    $data["chucvu"],$data["luong"],
                    $data["linhvuc"],$data["diachi"],
                    $data["email"],$data["sdt"],
                    $data["mota"],$data["kynang"],
                    $thoigianlamviec,$data["yeucau"],
                    $data["quyenloi"],$data["soluongtuyen"],
                    $_SESSION["company_id"]
                );
        if ($stmt_insert->execute()) {
            echo json_encode(array("status" => 1));
        } else {
            echo json_encode(array("status" => 0,"message"=>"Cập nhật không thành công"));
        }
    }

    public function delete($idbaidang){
        require("../Login/database.php");
        
        // Delete dependent records in Ungtuyen table first
        $sql1 = "DELETE FROM Ungtuyen WHERE ID_Dangviec = $idbaidang";
        $res1 = $conn->query($sql1);
        
        // Delete record in DangViec table
        $sql2 = "DELETE FROM DangViec WHERE ID_Dangviec = $idbaidang";
        $res2 = $conn->query($sql2);
        
        if ($res2) {
            echo json_encode(array("status"=>1));
        } else {
            echo json_encode(array("status"=>0));
        }
    }
    public function suabai($form_data,$idbaidang){
        require("../Login/database.php");
        $form_data = urldecode($form_data); // Decode the form data string
        parse_str($form_data, $form_data_array); // Parse the form data into an array
        // var_dump($data["tencongviec"]);
        $tencongviec = $form_data_array["tencongviec"];
        $loaicongviec = $form_data_array["loaicongviec"];
        $chucvu  = $form_data_array["chucvu"];
        $luong = $form_data_array["luong"];
        $linhvuc = $form_data_array["linhvuc"];
        $diachi = $form_data_array["diachi"];
        $email = $form_data_array["email"];
        $sdt = $form_data_array["sdt"];
        $mota = $form_data_array["mota"];
        $kynang = $form_data_array["kynang"];
        $yeucau = $form_data_array["yeucau"];
        $quyenloi = $form_data_array["quyenloi"];
        $soluongtuyen = $form_data_array["soluongtuyen"];
        $sql = "UPDATE DangViec SET
            Tencongviec = '$tencongviec',
            Loaicongviec = '$loaicongviec',
            Chucvu = '$chucvu',
            Luong = '$luong',
            Linhvuc = '$linhvuc',
            Diachi = '$diachi',
            Email = '$email',
            SDT = '$sdt',
            Mota = '$mota',
            Kynang = '$kynang',
            Thoigianlamviec = 'random',
            Yeucau = '$yeucau',
            Quyenloi = '$quyenloi',
            soluongtuyen = '$soluongtuyen'
            WHERE ID_Dangviec = '$idbaidang'";
        $res = $conn->query($sql);
        if ($res) {
            echo json_encode(array("status" => 1));
        } else {
            echo json_encode(array("status" => 0));
        }
    }
}

$c_dangbai = new C_Dangbai();
if (isset($_POST["type"]) && $_POST["type"] == "-1"){
$c_dangbai -> delete($_POST["idbaidang"]);
}
else if(isset($_POST["type"]) && $_POST["type"] == "1"){
    $c_dangbai -> suabai($_POST["data"],$_POST["idbaidang"]);

}
else
$c_dangbai -> upload($_POST["data"]);