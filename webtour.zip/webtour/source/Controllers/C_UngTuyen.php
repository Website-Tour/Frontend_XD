<?php
class C_ungtuyen
{
    public function ungtuyen($idbaidang)
    {
        session_start();
        require("../Login/database.php");
        
        // Kiểm tra xem dữ liệu đã tồn tại trong cơ sở dữ liệu hay chưa
        $sql_check = "SELECT * FROM Ungtuyen WHERE ID_NTV = ? AND ID_DangViec = ?";
        $stmt_check = $conn->prepare($sql_check);
        $stmt_check->bind_param("ii", $_SESSION["user_id"], $idbaidang);
        $stmt_check->execute();
        $result = $stmt_check->get_result();
        
        // Nếu dữ liệu đã tồn tại, trả về status = 0
        if ($result->num_rows > 0) {
            echo json_encode(array("status" => 0,"message"=> "Bạn đã ứng tuyển trước đó, hãy đợi phản hồi"));
        } else {
            // Nếu dữ liệu chưa tồn tại, thêm mới vào cơ sở dữ liệu
            $sql_insert = "INSERT INTO Ungtuyen (ID_NTV, ID_Dangviec) VALUES (?, ?)";
            $stmt_insert = $conn->prepare($sql_insert);
            $stmt_insert->bind_param("ii", $_SESSION["user_id"], $idbaidang);
            if ($stmt_insert->execute()) {
                echo json_encode(array("status" => 1));
            } else {
                echo json_encode(array("status" => 0));
            }
        }
    }
    public function xetduyetdongy($iduser,$idbaidang,$type){
        require("../Login/database.php");
        $sql = $conn -> query("UPDATE Ungtuyen SET 
            Daduyet = '$type'
        WHERE ID_NTV = '$iduser' and ID_Dangviec = '$idbaidang'");
        if ($sql){
            echo json_encode(array('status' => 1));
        } else echo json_encode(array('status' => 0));
    }
}
$c_ungtuyen = new C_ungtuyen();

if (isset($_POST["type"]))
$c_ungtuyen -> xetduyetdongy($_POST["iduser"],$_POST["idbaidang"],$_POST["type"]);
else
$c_ungtuyen -> ungtuyen($_POST["idbaidang"]);
