let dataG=null;
$(document).ready(function () {
    getAllInfoUser();
});
  function getAllInfoUser() {
    $.post("../Controllers/C_Inforuser.php", {
      type: "1",
    }).done(function (data, status) {
      data = JSON.parse(data);
      dataG = data;
      console.log(data);
      console.log(status);
      if (status) {
        showAllDataUser(data);
      }
    });
  }
  function showAllDataUser(data) {
    let ele = $("#content").children().children();
    let res = `
                      <div class="col-sm-12 infor-userxinviec col-pageinfouserabove">
                          <div class="card-info-userxinviec">
                              <div class="body">
                                  <div class="row">
                                      <div class="col-sm-12 img-userxinviec-right">
                                          <button title="Thay ảnh đại diện" id="avatarInfo" type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" style="border:none;background-color: transparent;">
                                          <span><img class="format-img-userxinviec-right" src="${
                                            data.Linkavatar == "" ? "../image/user.png":data.Linkavatar
                                          }" alt="avatar"></span>
                                      </button>
                                      </div>
                                      <div class="col-sm-12">
                                          <h5 class="card-title format-text-bold">${
                                            data.Hoten
                                          }</h5>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="col-sm-12 ">
                          <div class="card-basicinfo">
                              <div class="body">
                                  <div class="row">
                                      <div class="col-sm-12 mgl-col-content2-right-below">
                                          <h5 class="card-title format-text-bold">Thông tin cơ bản</h5>
                                      </div>
                                      <div class="col-sm-12  mgl-col-content2-right-below format-mt-item">
                                          <p class="format-span-img-cake"><img class="format-img-cake" src="../../../../src/assets/Images/ic_cake_24px.png" alt="">
                                          Ngày sinh: ${
                                            data.ngaysinh
                                          }</p>
                                          <p class="format-span-img-gender"><img class="format-img-gender" src="../../../../src/assets/Images/ic_wc_24px.png" alt="">
                                          Giới tính: ${
                                            data.gioitinh
                                          }</p>
                                      </div>
                                      <div class="col-sm-12  mgl-col-content2-right-below format-mt-item">
                                          <p class="format-span-img-call"><img class="format-img-call" src="../../../../src/assets/Images/ic_call_24px.png" alt="">
                                          Số điện thoại: ${
                                            data.SDT
                                          }</p>
                                          <p class="format-span-img-letter"><img class="format-img-letter" src="../../../../src/assets/Images/ic_markunread_24px.png" alt="">
                                          Email: ${
                                            data.Email
                                          }</p>
                                      </div>
                                      <div class="col-sm-12  mgl-col-content2-right-below format-mt-item">
                                          <p><img class="format-img-place" src="../../../../src/assets/Images/ic_place_24px.png" alt="">
                                          Địa chỉ: ${
                                            data.diachi
                                          }</p>
                                      </div>
                                      <div class="col-sm-12 mgl-col-content2-right-below col-muctieu">
                                          <h5 class="card-title format-text-bold">Mục tiêu nghề nghiệp</h5>
                                          <span><p class="p-muctieu">${
                                            data.muctieunghenghiep
                                          }</p></span>
                                      </div>
                                      <div class="col-sm-12 mgl-col-content2-right-below col-hocvan">
                                          <h5 class="card-title format-text-bold">Học vấn</h5>
                                          <span><p class="p-hocvan">${
                                            data.hocvan
                                          }</p></span>
                                      </div>
                                      <div class="col-sm-12 mgl-col-content2-right-below col-kynang">
                                          <h5 class="card-title format-text-bold">Kỹ năng</h5>
                                          <span><p class="p-kynang">${
                                            data.Kynang
                                          }</p></span>
                                      </div>
                                      <div class="col-sm-12 mgl-col-content2-right-below col-kinhnghiem">
                                          <h5 class="card-title format-text-bold">Kinh nghiệm làm việc</h5>
                                          <span><p class="p-kinhnghiem">${
                                            data.kinhnghiem
                                          }</p></span>
                                      </div>
                                      <div class="col-sm-12 mgl-col-content2-right-below col-linhvuc">
                                      <h5 class="card-title format-text-bold">Lĩnh vực</h5>
                                      <span>
                                          <p class="p-linhvuc">
                                              ${data.linhvuc}
              
                                          </p>
                                      </span>
                                  </div>
                                      <div class="col-sm-12 mgl-col-content2-right-below col-chitiet">
                                          <h5 class="card-title format-text-bold">Chi tiết</h5>
                                          <span><p class="p-chitiet">${
                                            data.chitiet
                                          }</p></span>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <button onclick="updateUser(dataG)" class="btn btn-primary col-sm-8 mx-auto" > Cập nhật thông tin cá nhân</button>
      `;
    
//     let res = `
//   <form id="formUpdateUser" method="post" action="../Controllers/C_updateUser.php" class="needs-validation my-4" novalidate>
//     <h1 class="text-center">Thông Tin Cá Nhân</h1>
//     <div class="d-sm-flex  flex-sm-row mt-4">
//         <div class="form-group col-sm-7">
//             <label for="name">Tên</label>
//             <input value='${data.Hoten}' name="hoten" type="text" class="form-control py-3" id="name" placeholder="Nhập họ tên ở đây" required>
//         </div>
//         <div class="form-group col-sm-5">
//             <label for="namework">Công việc</label>
//             <input value='${data.Congviec}' name="congviec" type="text" class="form-control py-3" id="namework" placeholder="Nhập tên công việc ở đây" required>
//         </div>

//     </div>
//     <div class="d-sm-flex flex-sm-row">

//         <div class="form-group col-sm-3">
//             <label for="ns">Ngày sinh</label>
//             <input value='${data.ngaysinh}' name="ngaysinh" type="date" class="form-control " id="ns" required>
//         </div>
//         <div class="form-group col-sm-2">
//             <label for="gt">Giới tính</label>
//             <select value="${data.gioitinh}" name="gioitinh" class="form-control" id="gt" required>
//                 <option value="nam" ${data.gioitinh.toLowerCase() == "nam" ? "selected" : ""}>Nam</option>
//                 <option value="nữ" ${data.gioitinh.toLowerCase() == "nữ" ? "selected" : ""}>Nữ</option>
//             </select>
//         </div>
//         <div class="form-group col-sm-4">
//             <label for="loaicv">Loại công việc</label>
//             <select name="loaicongviec" class="form-control" id="loaicv" required>
//                 <option value="1" ${data.Loaicongviec == "1" ? "selected" : ""}>Toàn thời gian</option>
//                 <option value="0" ${data.Loaicongviec  == "0" ? "selected" : ""}>Bán thời gian</option>
//             </select>
//         </div>
//         <div class="form-group col-sm-3">
//             <label for="linhvuc">Lĩnh vực</label>
//             <select name="linhvuc" class="form-control" id="linhvuc">
//                 <option selected>${data.linhvuc}</option>
//                 <option>Công nghệ thông tin</option>
//                 <option>Viễn thông</option>
//                 <option>Marketing / Truyền thông / Quảng cáo</option>
//                 <option>Nhà hàng / Khách sạn</option>
//                 <option>Thời trang</option>
//                 <option>Internet / Online</option>
//                 <option>Bất động sản</option>
//                 <option>Dược phẩm / Y tế / Công nghệ sinh học</option>
//                 <option>Kế toán / Kiểm toán</option>
//                 <option>Kinh doanh</option>
//                 <option>Giáo dục</option>
//                 <option>Văn phòng</option>
//                 <option>Bảo hiểm</option>
//                 <option>Luật</option>
//                 <option>Giải trí</option>
//                 <option>Agency</option>
//                 <option>Tài chính / Ngân Hàng</option>
//                 <option>Khác</option>
//             </select>
//         </div>
//     </div>
//     <div class="d-sm-flex flex-sm-row">
//         <div class="form-group col-sm-6">
//             <label for="number">Số điện thoại</label>
//             <input value='${data.SDT}' name="sdt" type="number" class="form-control py-3" id="number" placeholder="Nhập tên số điện thoại ở đây" required>
//         </div>
//         <div class="form-group col-sm-6">
//             <label for="email">Email</label>
//             <input readonly value='${data.Email}' name="email" type="email" class="form-control py-3" id="email" placeholder="Nhập tên email ở đây" required>
//         </div>
//     </div>
//     <div class="d-sm-flex flex-sm-row">
//         <div class="form-group col-sm-5">
//             <label for="tp">Thành phố</label>

//             <select  name="thanhpho" class="form-control" id="tp" required>
//                 <option disabled="disabled">Tỉnh / Thành phố</option>
//                 <option selected>${data.Thanhpho}</option>
//             </select>
//             <input class="billing_address_1" name="" type="hidden" value="">

//         </div class="d-sm-flex flex-sm-row">
//         <div class="form-group col-sm-7">
//             <label for="diachi">Địa chỉ</label>
//             <input value='${data.diachi}' name="diachi" type="text" class="form-control py-3" id="diachi" placeholder="Nhập tên địa chỉ ở đây" required>
//         </div>
//     </div>
//     <div class="form-group col-12">
//         <label for="comment1">Mục tiêu nghề nghiệp</label>
//         <textarea  name="muctieunghenghiep" class="form-control" rows="3" id="comment1" placeholder="Nhập mô tả ở đây" required>${data.muctieunghenghiep}</textarea>
//     </div>
//     <div class="form-group col-12">
//         <label for="comment2">Học vấn</label>
//         <textarea  name="hocvan" class="form-control" rows="3" id="comment2" placeholder="Nhập mô tả ở đây" required>${data.hocvan}</textarea>
//     </div>
//     <div class="form-group col-12">
//         <label for="comment3">Kỹ năng</label>
//         <textarea  name="kinang" class="form-control" rows="3" id="comment3" placeholder="Nhập mô tả ở đây" required>${data.Kynang}</textarea>
//     </div>
//     <div class="form-group col-12">
//         <label for="comment4">Kinh nghiệm làm việc</label>
//         <textarea  name="kinhnghiemlamviec" class="form-control" rows="3" id="comment4" placeholder="Nhập mô tả ở đây" required>${data.kinhnghiem}</textarea>
//     </div>
//     <div class="form-group col-12">
//         <label for="comment5">Chi tiết</label>
//         <textarea  name="chitiet" class="form-control" rows="3" id="comment5" placeholder="Nhập mô tả ở đây" required>${data.chitiet}</textarea>
//     </div>

//     <div class="offset-sm-4">
//         <button type="submit" class="mx-auto btn btn-primary">CẬP NHẬT</button>
//     </div>
// <!-- </div> -->
// </form>

//     `;
    ele.html(res);

    console.log(c)
    $('select[name="thanhpho"]').each(function() {
      var $this = $(this),
        stc = ''
      c.forEach(function(i, e) {
        stc += '<option>' + i + '</option>'
        if (address_1 = localStorage.getItem('address_1_saved')) {
          $('select[name="thanhpho"] option').each(function() {
            if ($(this).text() == address_1) {
              $(this).attr('selected', '')
            }
          })
        }
      })
      $(this).append(stc)
    })

  $("#formUpdateUser").submit(function (e){
    e.preventDefault();
    // Lấy dữ liệu từ biểu mẫu
    var formData = $(this).serialize();
    // Gửi yêu cầu AJAX đến server
    $.ajax({
      url: $(this).attr('action'),
      type: $(this).attr('method'),
      data: formData,
      success: function(response) {
        const res = JSON.parse(response)
        if (res.status === 1) {
          // Xử lý thành công
          console.log('Success!');
          // Tạo một cửa sổ thông báo với nội dung và tiêu đề tùy chỉnh
          Swal.fire({
            title: 'Success',
            text: "Cập nhật thành công!",
            icon: 'success',
            showCancelButton: false,
            // cancelButtonColor: '#d33',
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'OK!'
          }).then((result) => {
            if (result) {
              // Xử lý khi người dùng chọn OK
              window.location.reload(true);
            }
          })
        } else {
          // Xử lý lỗi
          console.log('Error!');
        }
      },
      error: function(xhr) {
        // Xử lý lỗi khi gửi yêu cầu AJAX
        console.log(xhr.responseText);
      }
    });


})

  }
  function updateUser(data){
    console.log("data")
    console.log(data)
    let ele = $("#content").children().children().html("");
    let res = `
  <form id="formUpdateUser" method="post" action="../Controllers/C_updateUser.php" class="needs-validation my-4" novalidate>
    <h1 class="text-center">Thông Tin Cá Nhân</h1>
    <div class="d-sm-flex  flex-sm-row mt-4">
        <div class="form-group col-sm-7">
            <label for="name">Tên</label>
            <input value='${data.Hoten}' name="hoten" type="text" class="form-control py-3" id="name" placeholder="Nhập họ tên ở đây" required>
        </div>
        <div class="form-group col-sm-5">
            <label for="namework">Công việc</label>
            <input value='${data.Congviec}' name="congviec" type="text" class="form-control py-3" id="namework" placeholder="Nhập tên công việc ở đây" required>
        </div>

    </div>
    <div class="d-sm-flex flex-sm-row">

        <div class="form-group col-sm-3">
            <label for="ns">Ngày sinh</label>
            <input value='${data.ngaysinh}' name="ngaysinh" type="date" class="form-control " id="ns" required>
        </div>
        <div class="form-group col-sm-2">
            <label for="gt">Giới tính</label>
            <select value="${data.gioitinh}" name="gioitinh" class="form-control" id="gt" required>
                <option value="nam" ${data.gioitinh.toLowerCase() == "nam" ? "selected" : ""}>Nam</option>
                <option value="nữ" ${data.gioitinh.toLowerCase() == "nữ" ? "selected" : ""}>Nữ</option>
            </select>
        </div>
        <div class="form-group col-sm-4">
            <label for="loaicv">Loại công việc</label>
            <select name="loaicongviec" class="form-control" id="loaicv" required>
                <option value="1" ${data.Loaicongviec == "1" ? "selected" : ""}>Toàn thời gian</option>
                <option value="0" ${data.Loaicongviec  == "0" ? "selected" : ""}>Bán thời gian</option>
            </select>
        </div>
        <div class="form-group col-sm-3">
            <label for="linhvuc">Lĩnh vực</label>
            <select name="linhvuc" class="form-control" id="linhvuc">
                <option selected>${data.linhvuc}</option>
                <option>Công nghệ thông tin</option>
                <option>Viễn thông</option>
                <option>Marketing / Truyền thông / Quảng cáo</option>
                <option>Nhà hàng / Khách sạn</option>
                <option>Thời trang</option>
                <option>Internet / Online</option>
                <option>Bất động sản</option>
                <option>Dược phẩm / Y tế / Công nghệ sinh học</option>
                <option>Kế toán / Kiểm toán</option>
                <option>Kinh doanh</option>
                <option>Giáo dục</option>
                <option>Văn phòng</option>
                <option>Bảo hiểm</option>
                <option>Luật</option>
                <option>Giải trí</option>
                <option>Agency</option>
                <option>Tài chính / Ngân Hàng</option>
                <option>Khác</option>
            </select>
        </div>
    </div>
    <div class="d-sm-flex flex-sm-row">
        <div class="form-group col-sm-6">
            <label for="number">Số điện thoại</label>
            <input value='${data.SDT}' name="sdt" type="number" class="form-control py-3" id="number" placeholder="Nhập tên số điện thoại ở đây" required>
        </div>
        <div class="form-group col-sm-6">
            <label for="email">Email</label>
            <input readonly value='${data.Email}' name="email" type="email" class="form-control py-3" id="email" placeholder="Nhập tên email ở đây" required>
        </div>
    </div>
    <div class="d-sm-flex flex-sm-row">
        <div class="form-group col-sm-5">
            <label for="tp">Thành phố</label>

            <select  name="thanhpho" class="form-control" id="tp" required>
                <option disabled="disabled">Tỉnh / Thành phố</option>
                <option selected>${data.Thanhpho}</option>
            </select>
            <input class="billing_address_1" name="" type="hidden" value="">

        </div class="d-sm-flex flex-sm-row">
        <div class="form-group col-sm-7">
            <label for="diachi">Địa chỉ</label>
            <input value='${data.diachi}' name="diachi" type="text" class="form-control py-3" id="diachi" placeholder="Nhập tên địa chỉ ở đây" required>
        </div>
    </div>
    <div class="form-group col-12">
        <label for="comment1">Mục tiêu nghề nghiệp</label>
        <textarea  name="muctieunghenghiep" class="form-control" rows="3" id="comment1" placeholder="Nhập mô tả ở đây" required>${data.muctieunghenghiep}</textarea>
    </div>
    <div class="form-group col-12">
        <label for="comment2">Học vấn</label>
        <textarea  name="hocvan" class="form-control" rows="3" id="comment2" placeholder="Nhập mô tả ở đây" required>${data.hocvan}</textarea>
    </div>
    <div class="form-group col-12">
        <label for="comment3">Kỹ năng</label>
        <textarea  name="kinang" class="form-control" rows="3" id="comment3" placeholder="Nhập mô tả ở đây" required>${data.Kynang}</textarea>
    </div>
    <div class="form-group col-12">
        <label for="comment4">Kinh nghiệm làm việc</label>
        <textarea  name="kinhnghiemlamviec" class="form-control" rows="3" id="comment4" placeholder="Nhập mô tả ở đây" required>${data.kinhnghiem}</textarea>
    </div>
    <div class="form-group col-12">
        <label for="comment5">Chi tiết</label>
        <textarea  name="chitiet" class="form-control" rows="3" id="comment5" placeholder="Nhập mô tả ở đây" required>${data.chitiet}</textarea>
    </div>
    <div class="form-group">
      <label for="changepass">Cập nhật mật khẩu</label> 
      <input type="checkbox" name="changepass" id="changepass"/>
    </div>
    
    <div class="d-sm-flex flex-sm-row">
        <div class="form-group col-sm-4">
            <label for="passNow">Mật khẩu hiện tại</label>
            <input class="form-control py-2" name="passNow" id="passNow" type="password">
        </div>
        <div class="form-group col-sm-4">
            <label for="newpass">Mật khẩu mới</label>
            <input name="newpass" type="password" class="form-control py-2" id="newpass">
        </div>
        <div class="form-group col-sm-4">
            <label for="confirmPass">Nhập lại mật khẩu mới</label>
            <input name="confirmPass" type="password" class="form-control py-2" id="confirmPass">
        </div>
    </div>

    <div class="offset-sm-4">
        <button type="submit" class="mx-auto btn btn-primary">CẬP NHẬT</button>
    </div>
<!-- </div> -->
</form>

    `;
    ele.html(res);
    $('select[name="thanhpho"]').each(function() {
      var $this = $(this),
        stc = ''
      c.forEach(function(i, e) {
        stc += '<option>' + i + '</option>'
        if (address_1 = localStorage.getItem('address_1_saved')) {
          $('select[name="thanhpho"] option').each(function() {
            if ($(this).text() == address_1) {
              $(this).attr('selected', '')
            }
          })
        }
      })
      $(this).append(stc)
    })

  $("#formUpdateUser").submit(function (e){
    e.preventDefault();
    // Lấy dữ liệu từ biểu mẫu
    var formData = $(this).serialize();
    // Gửi yêu cầu AJAX đến server
    $.ajax({
      url: $(this).attr('action'),
      type: $(this).attr('method'),
      data: formData,
      success: function(response) {
        console.log(response)
        const res = JSON.parse(response)
        if (res.status === 1) {
          // Xử lý thành công
          console.log('Success!');
          // Tạo một cửa sổ thông báo với nội dung và tiêu đề tùy chỉnh
          Swal.fire({
            title: 'Success',
            text: "Cập nhật thành công!",
            icon: 'success',
            showCancelButton: false,
            // cancelButtonColor: '#d33',
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'OK!'
          }).then((result) => {
            if (result.isConfirmed) {
              // Xử lý khi người dùng chọn OK
            }
          })
        } else {
          // Xử lý lỗi
          Swal.fire({
            title: 'Fail',
            text: "Cập nhậtkhông thành công!",
            icon: 'warning',
            showCancelButton: false,
            // cancelButtonColor: '#d33',
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'OK!'
          }).then((result) => {
            if (result.isConfirmed) {
              // Xử lý khi người dùng chọn OK
            }
          })
        }
      },
      error: function(xhr) {
        // Xử lý lỗi khi gửi yêu cầu AJAX
        console.log(xhr.responseText);
      }
    });
  });
  }
  function getAllInfoUserByIdURL(id) {
    $.post("../Controllers/C_Inforuser.php", {
      type: 3,
      iduser: id,
    }).done(function (data, status) {
      data = JSON.parse(data);
      console.log(data);
      // console.log(status);
      if (status) {
        showAllDataUser(data);
      }
    });
  }
  // <div class="col-md-12 col-tuyenngay">
  //     <a class="btn btn-dark btn-outline-light btn-tuyenngay" tabindex="-1" role="button" href="#">Tuyển ngay</a>
  //     <button class="btn-luuyeu-thich" id="btn-luuyeuthich" aria-haspopup="true" aria-expanded="false">
  //         <span>
  //             <svg class="img-ungtuyenngay" width="50" height="40" role="img" aria-label="biểu tượng-lưu" focusable="false" viewBox="0 0 18 18">
  //                 <g>
  //                     <path d="M12.38,2.25A4.49,4.49,0,0,0,9,3.82,4.49,4.49,0,0,0,5.63,2.25,4.08,4.08,0,0,0,1.5,6.38c0,2.83,2.55,5.15,6.41,8.66L9,16l1.09-1C14,11.52,16.5,9.21,16.5,6.38A4.08,4.08,0,0,0,12.38,2.25ZM9.08,13.91L9,14l-0.08-.08C5.35,10.68,3,8.54,3,6.38A2.56,2.56,0,0,1,5.63,3.75,2.93,2.93,0,0,1,8.3,5.52H9.7a2.91,2.91,0,0,1,2.67-1.77A2.56,2.56,0,0,1,15,6.38C15,8.54,12.65,10.68,9.08,13.91Z"></path>
  //                 </g>
  //             </svg>
  //         </span>
  //     </button>
  // </div>
  