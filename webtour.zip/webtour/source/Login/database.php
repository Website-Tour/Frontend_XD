<?php

$host = "localhost";
$dbname = "WEB_TimViec";
$username = "root";
$password = "";

$conn = new mysqli($host, $username, $password, $dbname);
mysqli_options($conn, MYSQLI_OPT_LOCAL_INFILE, 1);
if($conn -> connect_error)
{   
    die("Connection error: ". $conn-> connect_error);
}
// $sql = "SELECT * FROM CONGTY";
// $result = $conn->query($sql);
// if ($result->num_rows > 0) {
// // Load dữ liệu lên website
// while($row = $result->fetch_assoc()) {
// echo "id: " . $row["ID_CTY"]. " - Tên: " . $row["TenCTY"]. " "
// . " - diachi: ". $row["diachi"]."<br>";
// }
// } else {
// echo "0 results";
// }
// $conn->close();
?>