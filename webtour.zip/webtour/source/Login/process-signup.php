<?php
session_start();
    if(empty($_POST["name"])){
        $_SESSION['error_message'] = "Vui lòng nhập tên";
        header("Location: signin.php");
        exit;
    }
    if(!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)){
        $_SESSION['error_message'] = "Vui lòng nhập email";
        header("Location: signin.php");
        exit;
    }
    if(strlen($_POST["password"])<6){
        $_SESSION['error_message'] = "Mật khẩu ít nhất 6 kí tự";
        header("Location: signin.php");
        exit;
    }
    if($_POST["password"] !== $_POST["confirm-password"])
    {
        $_SESSION['error_message'] = "Mật khẩu không khớp";
        header("Location: signin.php");
        exit;
    }
    if(empty($_POST["flexRadioDefault"]))
    {
        $_SESSION['error_message'] = "Choose someone";
        header("Location: signin.php");
        exit;
    }

    // $password_hash = password_hash($_POST["password"], PASSWORD_DEFAULT);
    $password_hash = $_POST["password"];

    require __DIR__. "/database.php";
// echo $_POST["flexRadioDefault"];
$inserted_id=0;
    if($_POST["flexRadioDefault"] === "User")
    {
        $useremail = $_POST["email"];
        $sql = $conn -> query("SELECT count(Email) soluong FROM `ad_ntv` WHERE Email='$useremail';");
        $r = $sql->fetch_assoc();
        $count = $r['soluong'];
        if ($count>0){
            $_SESSION['error_message'] = "Email đã tồn tại";
            header("Location: signin.php");
            exit;
        }
        $username = $_POST['name'];
        $sqlString = "INSERT INTO NguoiTimViec(`Hoten`) VALUES('$username')";
        $sql = $conn->query($sqlString);
        if ($sql) {
            $inserted_id = $conn->insert_id;
            // echo "Bản ghi vừa được thêm vào có ID là: " . $inserted_id;
         }
        $sql = "INSERT INTO ad_ntv (`ID_NTV`,`Tendangnhap`, `Email`, `Matkhau`) Values(?,?, ?, ?)";
    }
    if($_POST["flexRadioDefault"] === "Company")
    {
        $useremail = $_POST["email"];
        $sql = $conn -> query("SELECT count(Email) soluong FROM `ad_cty` WHERE Email='$useremail';");
        $r = $sql->fetch_assoc();
        $count = $r['soluong'];
        if ($count>0){
            $_SESSION['error_message'] = "Email đã tồn tại";
            header("Location: signin.php");
            exit;
        }
        $username = $_POST['name'];
        $sqlString = "INSERT INTO CONGTY(`TenCTY`) VALUES('$username')";
        $sql = $conn->query($sqlString);
        if ($sql) {
            $inserted_id = $conn->insert_id;
            // echo "Bản ghi vừa được thêm vào có ID là: " . $inserted_id;
         }
        $sql = "INSERT INTO ad_cty (`ID_CTY`,`Tendangnhap`, `Email`, `Matkhau`) Values(?,?, ?, ?)";
    }
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("isss",
                        $inserted_id,
                        $_POST["name"],
                        $_POST["email"],
                        $password_hash);

    if($stmt -> execute()){
        // $_SESSION["session.userId"] = $inserted_id;
        header("Location: signup-success.php");
        exit;
    }
    else 
    {
        if($mysql -> errno === 1062)
        {
            die("email already taken");
        }
        else{
            // die($mysql->error . " " . $mysql->errno);
            $_SESSION['error_message'] = $mysql->error . " " . $mysql->errno;
            header("Location: signin.php");
            exit;
        }
        
    }


    $conn->close();
?>