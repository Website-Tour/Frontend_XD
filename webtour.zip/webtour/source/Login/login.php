<?php
    session_start();
    //kiểm tra session user tồn tại thì login luôn
    if(isset($_SESSION["user_id"])){
        $home_page = '../User/userhome.php';
        // include('final web/User/index.php');
        header("Location: $home_page");
        exit;
    }
    if(isset($_SESSION["company_id"])){
        $home_page = '../Company/Comhome.php';
        // include('final web/User/index.php');
        header("Location: $home_page");
        exit;
    }

    $email = $passwordPost = $who = "";
       
    if($_SERVER['REQUEST_METHOD']==="POST"){
        $email = $_POST["email"];
        $passwordPost = $_POST["password"];
        $who = $_POST["accout_type"];
        
        if (empty($email) || empty($passwordPost)) {
            $error = "Vui lòng nhập email và mật khẩu.";
        }
        else
        {
            require_once "./database.php";

            if ($who == "User"){
                $sql = sprintf("SELECT * FROM ad_ntv
                WHERE email = '%s'",
                $conn ->real_escape_string($_POST["email"]));
                $result = $conn -> query($sql);
                $user = $result -> fetch_assoc();
                if (!$user){
                    $error = "Email không tồn tại";
                }
                $verri = password_verify($_POST["password"], $user["Matkhau"]);
                if ($user && $user["Matkhau"]==$passwordPost)
                    $verri = true;
                if($user){
                    if($verri)
                    {
                        $_SESSION["user_id"] = $user["ID_NTV"];
                        $home_page = '../User/userhome.php';
                        // include('final web/User/index.php');
                        header("Location: $home_page");
                        exit;
                    }
                    else
                    {
                        $error = "Sai thông tin đăng nhập";
                    }
                }
            } else if ($who == "Company"){
                $sql1 = sprintf("SELECT * FROM ad_cty
                WHERE email = '%s'",
                $conn ->real_escape_string($_POST["email"]));
                $result1 = $conn -> query($sql1);
                $company = $result1 -> fetch_assoc();
                if (!$company){
                    $error = "Email không tồn tại";
                }
                $verri = password_verify($_POST["password"], $company["Matkhau"]);
                if ($company && $company["Matkhau"]==$passwordPost)
                    $verri = true;
                if($company){
                    if($verri)
                    {
                        session_start();

                        $_SESSION["company_id"] = $company["ID_CTY"];
                        
                        print($_SESSION);

                        $home_page = '../Company/Comhome.php';
                        // include('final web/User/index.php');

                        header("Location: $home_page");
                        exit;
                    }
                    else 
                    {
                        $error = "sai thông tin đăng nhập";
                    }

                }
            }else $error = "Choose someone";
        }
       
    }
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link  href = "../style.css" rel = "stylesheet"> 
    
    <!-- font -->
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@1,700&family=Tilt+Warp&display=swap" rel="stylesheet">
    <!-- icons -->
    
    <link href=" https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" rel = "stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <title> Choose A Job, Decide Your Future</title>
</head>


<body class = "bg-light">
    <header>
        <nav class = "navbar navbar-expand-md bg">
            <a style="text-decoration: none;" href="" class = "narbar-brand fs-3 ms-5 text-white" >Pham</a>

            <button class="navbar-toggler me-3 text-white" type="button" data-bs-toggle="collapse" data-bs-target="#btn"><i class = 'bx bx-menu bx-md'></i></button>
            <div class="collapse navbar-collapse ul-bg" id="btn">
                <ul class="navbar-nav ms-auto" >
                    <li class = "nav-item">
                        <a href="../index.php"  class="nav-link mx-4 text-white fs-8">Trang chủ</a>
                    </li>
                </ul>
            </div>
        </nav>  
    </header>

    
    
    <div class="container" style="height: 700px; ">
        <br>
    
        <div class="row mt-5" >
            <div class = "col-lg-4 bg-white m-auto rounded-top wrapper">
                <h2 class = "text-center pt-3">Login Now</h2>
                
                <?php if(!empty($error)){ ?>
                    <span class = "error" style="color: red; top: 50px; right: 50px; font-size: 15px;" id = "last-error"><?php echo $error ?></span>
                <?php } ?>
                
                    
                <p class= "text-center text-muted lead"> </p>


                <form method = "post"  >
                            
                    <div class="input-group mb-3">
                        <span class="input-group-text"><i class="fa fa-envelope"></i></span>
                        <input type="email" id="email" name = "email" class = "form-control" placeholder="Email" value= "<?= htmlspecialchars($_POST["email"] ?? "")?>">
                           
                    </div>
                    <div class="input-group mb-3">
                        <span class="input-group-text"><i class="fa fa-lock"></i></span>
                        <input type="password" id = "password" name="password" class = "form-control" placeholder="Password">
                        
                   </div>
                
                   <div class="form-check mb-3">
                        <input class="form-check-input" type="radio" name="accout_type" id="accout_type1" value ="User" >
                        <label class="form-check-label" for="accout_type1">
                            For User
                        </label>
                        <span class = "error" style="color: red; position: absolute; bottom: -16px; right: 17px; font-size: 15px;" id = "check1-error" ></span>
                      </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="radio" name="accout_type" value ="Company" id="accout_type2">
                        <label class="form-check-label" for="accout_type2">
                            For Company
                        </label>  
                    </div>

                    <div class="d-grid mb-4">
                        <input type="submit" value="Login"class="btn btn-dark"></input>
                       
                        <p class="text-center">
                            Register Now for Free <a href="signin.php " style="color: #336B87;">Create An Account</a>
                        </p>
                    
                    </div>
                    
                </form>
     
            </div>

        </div> 

    </div>

    <!-- footer -->

    <style>
        a {
            color: #BCBABE;
        }
        strong{
            color: #BCBABE;
        }
    </style>
    <footer class="bg-dark text-white pt-5 pb4">

        <div class = "container text-center text-md-left">

            <div class =" row text-center g-4 text-md-left">
                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>About</h3><br>
                        
                        <p><a href="#" >our services</a></li>
                        <p><a href="#" >privacy policy</a></li>
                        <p><a href="#" >affiliate program</a></li>
                    

                </div>

                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>Company</h3><br>
                        <p><a href="#" >about us</a></li>
                        <p><a href="#" >our services</a></li>
                        <p><a href="#" >privacy policy</a></li>
                </div>
                

                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3 >Get Help</h3><br>
                    
                        <p><a href="#" >FAQ</a></li>
                        <p><a href="#" >Contact</a></li>
        
                </div>
                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>follow us</h3><br>
                    <div class="social-links">
                        <a href="#" ><i class="fab fa-facebook-f"></i></a>
                        <a href="#" ><i class="fab fa-twitter"></i></a>
                        <a href="#" ><i class="fab fa-instagram"></i></a>
                        <a href="#" ><i class="fab fa-linkedin-in"></i></a>
                    </div>

                </div>
                
            </div>

            <hr class="mb-4">
            <div class="row align-items-center">
                <div class="col-md-7 col-lg-8">
                    <b>Copyright @2022 All rights reserved by:
                        <a href=""# style="text-decoration: none;">
                            <strong class=" text-white">Pham Company</strong>
                        </a>
                    </b>
                    <p style="font-size: medium; color:#BCBABE;"> Contact: Ho Chi Minh:(+84) 0965323966 - Email: PhamCompany@gmail.com</li>
                    
                </div>
                
            </div>
            
        </div>

    </footer>

</body>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>