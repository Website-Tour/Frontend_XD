
const form = document.getElementById('signup')
const first = document.getElementById('First')
const last = document.getElementById('Last')
const email = document.getElementById('email')
const password = document.getElementById('password')
const confirmpass = document.getElementById('confirm-password');
const check1 = document.getElementById("flexRadioDefault1");
const check2 = document.getElementById("flexRadioDefault2");

form.addEventListener('submit', e=>{
    
    validateInputs(e);
})

const setError = (element, message, event) => {
    event.preventDefault();
    const inputControl = element.parentElement;
    const errorDisplay = inputControl.querySelector('.error');

    errorDisplay.innerText = message;
    inputControl.classList.add('error');
    inputControl.classList.remove('success')
}

const setSuccess = element => {
    const inputControl = element.parentElement;
    const errorDisplay = inputControl.querySelector('.error');

    errorDisplay.innerText = '';
    inputControl.classList.add('success');
    inputControl.classList.remove('error');
};

const isValidEmail = email => {
    const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

const validateInputs = (e) => {
    const firstValue = first.value.trim();
    const lastValue = first.value.trim();
    const emailValue = email.value.trim();
    const passwordValue = password.value.trim();
    const confirmpassValue = confirmpass.value.trim();
    
    if(firstValue === '') {
        setError(first, 'First is required', e);
    } else {
        setSuccess(first);
    }

    if(lastValue === '') {
        setError(last, 'Last is required',e);
    } else {
        setSuccess(last);
    }

    if(emailValue === '') {
        setError(email, 'Email is required',e);
    } else if (!isValidEmail(emailValue)) {
        setError(email, 'Provide a valid email address');
    } else {
        setSuccess(email);
    }

    if(passwordValue === '') {
        setError(password, 'Password is required',e);
    } else if (passwordValue.length < 8 ) {
        setError(password, 'Password must be at least 8 character.',e)
    } else {
        setSuccess(password);
    }

    if(confirmpassValue === '') {
        setError(confirmpass, 'Confirm your password',e);
    } else if (confirmpassValue !== passwordValue) {
        setError(confirmpass, "Passwords doesn't match",e);
    } else {
        setSuccess(confirmpass);
    }

    if(check1.checked) {
        setSuccess(check1);
    }
    else if(check2.checked){
        setSuccess(check1);
    }
    else{
        setError(check1, "Please chose someone",e);
    }
};




