    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css"/>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <style>
        nav {
    height: 80px;
    width: 100%;
    z-index: 1000;
}

.navbar-nav {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    height: 100%;
}

.navbar-nav .nav-item {
    margin-left: 20px;
}

.navbar-nav .nav-item:first-child {
    margin-left: 0;
}

.navbar-nav .nav-item .nav-link:hover {
    color: rgb(203, 242, 209);
    text-decoration: underline;
}



    </style>
    <header>
    <div class="container">
        <nav class="navbar navbar-expand-md bg">
            <a style="text-decoration: none;" href="" class="fs-8 ms-5 text-white" style="font-size: 30px;">CONSIDERATE - TOUR</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a href="Uptour.html" class="nav-link mx-4 text-white fs-8" style = "text-decoration: none";>Đăng Tour</a>
                    </li>
                    <li class="nav-item">
                        <a href="Uped.php" class="nav-link mx-4 text-white fs-8" style = "text-decoration: none">Bài Đăng</a>
                    </li>
                    <li class="nav-item">
                        <a href="CV.php" class="nav-link mx-4 text-white fs-8" style = "text-decoration: none">Quản Lí Bài Đăng</a>
                    </li>
                    <li class="nav-item">
                        <a href="Edithome.php" class="nav-link mx-4 text-white fs-8" style = "text-decoration: none">Quản Lí File CV</a>
                    </li>
                    <li class="nav-item">
                        <a href="../Login/logout.php" class="nav-link mx-4 text-white fs-8" style = "text-decoration: none">Đăng Xuất</a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</header>


    <script type="text/javascript">
    $(function() {
    var datepickerVisible = false; 

    $('.navbar-toggler-icon').click(function() {
        if (!datepickerVisible) { 
            $('#datepicker input').datepicker({
            }).datepicker('show');
            datepickerVisible = true; 
        } else { 
            $('#datepicker input').datepicker('hide'); 
            datepickerVisible = false;
        }
    });
});

</script>