<?php
$servername = "localhost"; 
$username = "root"; 
$password = "";
$dbname = "tour5"; 

// Tạo kết nối
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $admin_name = $_POST["ten"];
    $phone_number = $_POST["phone"];
    $email = $_POST["email"];
    $tour_name = $_POST["tentour"];
    $area = $_POST["area"];
    $address = $_POST["address"];
    $limit = $_POST["limit"];
    $start_date = $_POST["start"];
    $end_date = $_POST["end"];
    $tour_price = $_POST["money"];
    $tour_detail = $_POST["chitiet"];
    $image = $_POST["image"];
    $images = $_POST["images"];

    $sql = "INSERT INTO tour (adminname, adminphone, mail, tentour, area, tendiadiem, gioihannguoi, thoigiandi, thoigianve, giatour, chitiet, image, images) VALUES ('$admin_name', '$phone_number', '$email', '$tour_name', '$area', '$address', '$limit', '$start_date', '$end_date', '$tour_price', '$tour_detail', '$image', '$images'  )";
    if ($conn->query($sql) === TRUE) {
        $last_admin_id = $conn->insert_id;
        if ($conn->query($sql) === TRUE) {
            echo "Tour created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
