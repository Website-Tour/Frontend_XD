<?php
    // kiểm tra chưa có session thì về login
    session_start();
    if(!isset($_SESSION["company_id"])){
        $login_page = '../Login/login.php';
        // include('final web/User/index.php');
        header("Location: $login_page");
        exit;
    }
    if (isset($_GET["idbaidang"])) {
        $idbaidang = $_GET["idbaidang"];
    } else {
    $idbaidang = 1;
    }
    require_once "../Login/database.php";
    $sql = "SELECT * FROM DangViec WHERE ID_Dangviec = '$idbaidang'";
    $result = $conn->query($sql);
    $row2 = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link  href = "../style.css" rel = "stylesheet"> 
    
    <!-- font -->
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@1,700&family=Tilt+Warp&display=swap" rel="stylesheet">
    <!-- icons -->
    
    <link href=" https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" rel = "stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
        <!-- jquery -->
        <script src="https://code.jquery.com/jquery-3.6.4.slim.min.js" integrity="sha256-a2yjHM4jnF9f54xUQakjZGaqYs/V1CYvWpoqZzC2/Bw=" crossorigin="anonymous"></script>
    <title> Choose A Job, Decide Your Future</title>
    <!-- font awesome    -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/brands.min.css" integrity="sha512-9YHSK59/rjvhtDcY/b+4rdnl0V4LPDWdkKceBl8ZLF5TB6745ml1AfluEU6dFWqwDw9lPvnauxFgpKvJqp7jiQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/fontawesome.min.css" integrity="sha512-SgaqKKxJDQ/tAUAAXzvxZz33rmn7leYDYfBP+YoMRSENhf3zJyx3SBASt/OfeQwBHA1nxMis7mM3EV/oYT6Fdw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/regular.min.css" integrity="sha512-WidMaWaNmZqjk3gDE6KBFCoDpBz9stTsTZZTeocfq/eDNkLfpakEd7qR0bPejvy/x0iT0dvzIq4IirnBtVer5A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/solid.min.css" integrity="sha512-yDUXOUWwbHH4ggxueDnC5vJv4tmfySpVdIcN1LksGZi8W8EVZv4uKGrQc0pVf66zS7LDhFJM7Zdeow1sw1/8Jw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>
<body class = "bg-light">
<?php include("header.php");?>
    
    <div class="container" style="height: auto; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); margin-bottom: 40px;">
        <form class="row g-3" style="margin-top: 100px; ">
            <div>
                <div>
                    <h3 style="text-align: center;"> <?php echo $row2["Tencongviec"]?></h3>                    
		            <img src="../image/ig<?php echo $row2["ID_CTY"]?>.png" alt="Company Logo" class="rounded float-right " style =" max-width: 400px;display: block;margin: 20px auto;">
                    <p> <?php echo $row2["Diachi"]?></p>
                </div>  
            </div>
            <div>
                <h4 style="text-align: center;"> Mô tả công việc</h4>
                <div>
                    <h5> Tên công việc</h5>
                    <p> <?php echo $row2["Tencongviec"]?></p>
                    <br>
                    <h5> Lĩnh vực</h5>
                    <p> <?php echo $row2["Linhvuc"]?></p>
                    <br>
                    <h5> Chức vụ</h5>
                    <p> <?php echo $row2["Chucvu"]?></p>
                    <br>
                    <h5> Hình thức</h5>
                    <p> <?php echo $row2["Loaicongviec"] == "1" ? "Fulltime":"Partime"?></p>
                    <br>
                    <h5>Lương</h5>
                    <p><?php echo number_format($row2["Luong"], 0, ",", ".") . " VND"; ?></p>
                    <br>
                    <h5> Mô tả công việc</h5>
                    <p> <?php echo $row2["Mota"]?></p>
                    <br>
                    <h5> Kĩ năng</h5>
                    <p> <?php echo $row2["Kynang"]?>g</p>
                    <br>
                    <h5> Yêu cầu công việc</h5>
                    <p> <?php echo $row2["Yeucau"]?></p>
                    <br>
                    <h5> Phúc lợi</h5>
                    <p> <?php echo $row2["Quyenloi"]?></p>
                    <br>
                </div>
            </div>
        </form>
        
        <!-- <div class="container" style="margin-bottom: 90px;">
            <div class="d-grid gap-2">
                <button id="addbookmark" class="btn btn-dark" type="button">Thêm vào Bookmark</button>
                <button id="ungtuyen" class="btn btn-secondary" type="button">Ứng tuyển</button>
            </div>
        </div> -->
    </div>

    

    <!-- footer -->
   
    <style>
        a {
            color: #BCBABE;
        }
        strong{
            color: #BCBABE;
        }
    </style>
    <footer class="bg-dark text-white pt-5 pb4">

        <div class = "container text-center text-md-left">

            <div class =" row text-center g-4 text-md-left">
                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>About</h3><br>
                        
                        <p><a href="#" >our services</a></li>
                        <p><a href="#" >privacy policy</a></li>
                        <p><a href="#" >affiliate program</a></li>
                    

                </div>

                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>Company</h3><br>
                        <p><a href="#" >about us</a></li>
                        <p><a href="#" >our services</a></li>
                        <p><a href="#" >privacy policy</a></li>
                </div>
                

                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3 >Get Help</h3><br>
                    
                        <p><a href="#" >FAQ</a></li>
                        <p><a href="#" >Contact</a></li>
        
                </div>
                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>follow us</h3><br>
                    <div class="social-links">
                        <a href="#" ><i class="fab fa-facebook-f"></i></a>
                        <a href="#" ><i class="fab fa-twitter"></i></a>
                        <a href="#" ><i class="fab fa-instagram"></i></a>
                        <a href="#" ><i class="fab fa-linkedin-in"></i></a>
                    </div>

                </div>
                
            </div>

            <hr class="mb-4">
            <div class="row align-items-center">
                <div class="col-md-7 col-lg-8">
                    <b>Copyright @2022 All rights reserved by:
                        <a href=""# style="text-decoration: none;">
                            <strong class=" text-white">Pham Company</strong>
                        </a>
                    </b>
                    <p style="font-size: medium; color:#BCBABE;"> Contact: Ho Chi Minh:(+84) 0965323966 - Email: PhamCompany@gmail.com</li>
                    
                </div>
                
            </div>
            
        </div>

    </footer>

<script>
    $("#addbookmark").on("click", function(e){
        let idbaidang = <?php echo $idbaidang?>;
        let idcty = <?php echo $row2["ID_CTY"]?>;
        console.log(idbaidang, idcty);
        $.ajax({
            url: "../Controllers/C_bookmark.php",
            type: "POST", // Thay đổi phương thức thành POST
            data: {idbaidang,idcty},
            success: function(data){
                // console.log(data);
                const result = JSON.parse(data);
                // console.log(result);
                if (result.status==1){
                    Swal.fire({
                        title: 'success',
                        text: "Thêm vào bookmark thành công!",
                        icon: 'success',
                        showCancelButton: false,
                        // cancelButtonColor: '#d33',
                        confirmButtonColor: '#3085d6',
                        confirmButtonText: 'OK!'
                    })
                }else{
                    let text = result.message || "Thêm thất bại!"
                    Swal.fire({
                        title: 'warning',
                        text: text,
                        icon: 'warning',
                        showCancelButton: false,
                        // cancelButtonColor: '#d33',
                        confirmButtonColor: '#3085d6',
                        confirmButtonText: 'OK!'
                    })
                }
            },
            error: function(xhr, textStatus, errorThrown){
                console.log(xhr.status)
                Swal.fire({
                    title: 'warning',
                    text: "Thêm thất bại!",
                    icon: 'warning',
                    showCancelButton: false,
                    // cancelButtonColor: '#d33',
                    confirmButtonColor: '#3085d6',
                    confirmButtonText: 'OK!'
                })
            }
        })
    });

    $("#ungtuyen").on("click", function(e){
        let idbaidang = <?php echo $idbaidang?>;
        $.ajax({
            url: "../Controllers/C_UngTuyen.php",
            type: "POST", // Thay đổi phương thức thành POST
            data: {idbaidang},
            success: function(data){
                console.log(data);
                const result = JSON.parse(data);
                // console.log(result);
                if (result.status==1){
                    Swal.fire({
                        title: 'success',
                        text: "Ứng tuyển thành công!\nVui lòng chờ phản hồi",
                        icon: 'success',
                        showCancelButton: false,
                        // cancelButtonColor: '#d33',
                        confirmButtonColor: '#3085d6',
                        confirmButtonText: 'OK!'
                    })
                }else{
                    let text = result.message || "Thêm thất bại!"
                    Swal.fire({
                        title: 'warning',
                        text: text,
                        icon: 'warning',
                        showCancelButton: false,
                        // cancelButtonColor: '#d33',
                        confirmButtonColor: '#3085d6',
                        confirmButtonText: 'OK!'
                    })
                }
            },
            error: function(xhr, textStatus, errorThrown){
                console.log(xhr.status)
                Swal.fire({
                    title: 'warning',
                    text: "Thêm thất bại!",
                    icon: 'warning',
                    showCancelButton: false,
                    // cancelButtonColor: '#d33',
                    confirmButtonColor: '#3085d6',
                    confirmButtonText: 'OK!'
                })
            }
        })
    });
</script>
    
</body>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <!-- Nhúng sweetalert2 từ CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  </body>
</html>