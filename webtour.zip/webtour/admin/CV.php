<?php
    // kiểm tra chưa có session thì về login
    session_start();
    if(!isset($_SESSION["company_id"])){
        $login_page = '../Login/login.php';
        // include('final web/User/index.php');
        header("Location: $login_page");
        exit;
    }
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link  href = "../style.css" rel = "stylesheet"> 
    
    <!-- font -->
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@1,700&family=Tilt+Warp&display=swap" rel="stylesheet">
    <!-- icons -->
    
    <link href=" https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" rel = "stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <title> Choose A Job, Decide Your Future</title>
</head>
<body class = "bg-light">
    <?php include("header.php");?>

    
    <div class="container" style="height: 1000px; margin-bottom: 40px; margin-top: 200px;">
        

    <div class="table-responsive">
                <table id="yeucautuyendung" class="table align-middle mb-0 bg-white format-table">
                    <thead class="format-thead-background">
                        <tr class="format-text">
                            <th></th>
                            <th>Tên Người Tuyển dụng</th>
                            <th>Công Việc</th>
                            <th>Chi Tiết</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                    require_once "../Login/database.php";
                    $idcompany = $_SESSION["company_id"];
                    $sql = "SELECT * FROM Ungtuyen inner join DangViec inner join CONGTY inner join NguoiTimViec where Ungtuyen.ID_NTV = NguoiTimViec.ID_NTV and  DangViec.ID_CTY = CONGTY.ID_CTY and Ungtuyen.ID_Dangviec = DangViec.ID_DangViec and CONGTY.ID_CTY = $idcompany";
                    // Thực hiện truy vấn và lưu kết quả vào biến $result
                    $result = $conn->query($sql);
                    // var_dump($result->fetch_assoc());
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()){
                            $image = "../image/ig".$row["ID_CTY"].".png";
                            if ($row["Daduyet"] == -1) $status = "Đã từ chối";
                            else if ($row["Daduyet"] == 1) $status = "Đồng ý phỏng vấn";
                            else $status ="Chờ duyệt";
                            if ($row["Daduyet"]==0)
                            $thaotac = "<button onclick='dongy($row[ID_NTV],$row[ID_Dangviec])' class='btn btn-primary'>Đồng ý</button>
                            <button onclick='tuchoi($row[ID_NTV],$row[ID_Dangviec])' class='btn btn-warning'>Từ chối</button>";
                            else if ($row["Daduyet"]==-1)
                            $thaotac = "<button class='btn btn-secondary' disabled>Đã từ chối</button>";
                            else $thaotac = "<button class='btn btn-primary' disabled>Đã đồng ý phỏng vấn</button>";
                            echo 
                                '
                                <tr class="format-text">
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="../image/user.png" alt="" style="width: 45px; height: 45px" class="rounded-circle" />
                                    </div>
                                </td>
                                <td>
                                    <p class="fw-normal mb-1">'.$row['Hoten'].'</p>
                                </td>
                                <td>'.$row["Tencongviec"].'</td>
                                <td class="format-td">
                                    <div class="format-td-hoso">
                                        <a class="format-hoso" role="button" href="detail.php?idbaidang='.$row["ID_Dangviec"].'" class="btn btn-primary  btn-rounded">
                                            Xem hồ sơ
                                        </a>
                                    </div>
    
                                </td>
                                <td>
                                    '.$thaotac.'
                                </td>
                            </tr>
                                ';
                        }
                    }
                ?>    
                    </tbody>
                </table>
            </div>
        
    </div>
    
</div>

<script>
    // $(document).ready(function() {
        function dongy(iduser,idbaidang){
            $.ajax({
                url: "../Controllers/C_UngTuyen.php",
                type: "post",
                data: {iduser,idbaidang,type:1},
                success: function(data){
                    const res = JSON.parse(data);
                    if (res.status ==1 ){
                                  Swal.fire({
            title: 'Success',
            text: "Cập nhật thành công!",
            icon: 'success',
            showCancelButton: false,
            // cancelButtonColor: '#d33',
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'OK!'
          })
                    }
                }
    })
}
function tuchoi(iduser,idbaidang){
            $.ajax({
                url: "../Controllers/C_UngTuyen.php",
                type: "post",
                data: {iduser,idbaidang,type:-1},
                success: function(data){
                    const res = JSON.parse(data);
                    if (res.status ==1 ){
                                  Swal.fire({
            title: 'Success',
            text: "Cập nhật thành công!",
            icon: 'success',
            showCancelButton: false,
            // cancelButtonColor: '#d33',
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'OK!'
          })
                    }
                }
    })
}
    // })
</script>

    <!-- footer -->
   
    <style>
        a {
            color: #BCBABE;
        }
        strong{
            color: #BCBABE;
        }
    </style>
    <footer class="bg-dark text-white pt-5 pb4">

        <div class = "container text-center text-md-left">

            <div class =" row text-center g-4 text-md-left">
                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>About</h3><br>
                        
                        <p><a href="#" >our services</a></li>
                        <p><a href="#" >privacy policy</a></li>
                        <p><a href="#" >affiliate program</a></li>
                    

                </div>

                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>Company</h3><br>
                        <p><a href="#" >about us</a></li>
                        <p><a href="#" >our services</a></li>
                        <p><a href="#" >privacy policy</a></li>
                </div>
                

                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3 >Get Help</h3><br>
                    
                        <p><a href="#" >FAQ</a></li>
                        <p><a href="#" >Contact</a></li>
        
                </div>
                <div class = "col-md 3 col-lg-3 col-xl-3 mx auto mt-3">
                    <h3>follow us</h3><br>
                    <div class="social-links">
                        <a href="#" ><i class="fab fa-facebook-f"></i></a>
                        <a href="#" ><i class="fab fa-twitter"></i></a>
                        <a href="#" ><i class="fab fa-instagram"></i></a>
                        <a href="#" ><i class="fab fa-linkedin-in"></i></a>
                    </div>

                </div>
                
            </div>

            <hr class="mb-4">
            <div class="row align-items-center">
                <div class="col-md-7 col-lg-8">
                    <b>Copyright @2022 All rights reserved by:
                        <a href=""# style="text-decoration: none;">
                            <strong class=" text-white">Pham Company</strong>
                        </a>
                    </b>
                    <p style="font-size: medium; color:#BCBABE;"> Contact: Ho Chi Minh:(+84) 0965323966 - Email: PhamCompany@gmail.com</li>
                    
                </div>
                
            </div>
            
        </div>

    </footer>

</body>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <!-- Nhúng sweetalert2 từ CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  </body>
</html>