<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link  href = "../style.css" rel = "stylesheet">  
    
    <!-- font -->
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@1,700&family=Tilt+Warp&display=swap" rel="stylesheet">
    <!-- icons -->
    
    <link href=" https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" rel = "stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="../Styles/pageinfouser.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <!-- jquery -->
    <script src="https://code.jquery.com/jquery-3.6.4.slim.min.js" integrity="sha256-a2yjHM4jnF9f54xUQakjZGaqYs/V1CYvWpoqZzC2/Bw=" crossorigin="anonymous"></script>
    <title> Choose A Job, Decide Your Future</title>
</head>
<body>
<?php include("header.php");?>
    <!-- showcase -->
    <div id="main">
        <div id="content" class="container container-pageinfouser">
            <div class="col-xs-12 col-sm-10 my-5 mx-auto row-container col-content-pageinfouser">
                <div class="row ds-row-pageinfouser mx-auto">
                </div>
            </div>
        </div>
	</div>
<script>
    $(document).ready(function () {
    getAllInfoUser();
});
  function getAllInfoUser() {
    $.post("../Controllers/C_Inforuser.php", {
      type: "1",
    }).done(function (data, status) {
      data = JSON.parse(data);
      dataG = data;
      console.log(data);
      console.log(status);
      if (status) {
        showAllDataUser(data);
      }
    });
  }
  function showAllDataUser(data) {
    let ele = $("#content").children().children();
    let res = `
                      <div class="col-sm-12 infor-userxinviec col-pageinfouserabove">
                          <div class="card-info-userxinviec">
                              <div class="body">
                                  <div class="row">
                                      <div class="col-sm-12 img-userxinviec-right">
                                          <button title="Thay ảnh đại diện" id="avatarInfo" type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" style="border:none;background-color: transparent;">
                                          <span><img class="format-img-userxinviec-right" src="${
                                            data.Linkavatar == "" ? "../image/user.png":data.Linkavatar
                                          }" alt="avatar"></span>
                                      </button>
                                      </div>
                                      <div class="col-sm-12">
                                          <h5 class="card-title format-text-bold">${
                                            data.Hoten
                                          }</h5>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="col-sm-12 ">
                          <div class="card-basicinfo">
                              <div class="body">
                                  <div class="row">
                                      <div class="col-sm-12 mgl-col-content2-right-below">
                                          <h5 class="card-title format-text-bold">Thông tin cơ bản</h5>
                                      </div>
                                      <div class="col-sm-12  mgl-col-content2-right-below format-mt-item">
                                          <p class="format-span-img-cake"><img class="format-img-cake" src="../../../../src/assets/Images/ic_cake_24px.png" alt="">
                                          Ngày sinh: ${
                                            data.ngaysinh
                                          }</p>
                                          <p class="format-span-img-gender"><img class="format-img-gender" src="../../../../src/assets/Images/ic_wc_24px.png" alt="">
                                          Giới tính: ${
                                            data.gioitinh
                                          }</p>
                                      </div>
                                      <div class="col-sm-12  mgl-col-content2-right-below format-mt-item">
                                          <p class="format-span-img-call"><img class="format-img-call" src="../../../../src/assets/Images/ic_call_24px.png" alt="">
                                          Số điện thoại: ${
                                            data.SDT
                                          }</p>
                                          <p class="format-span-img-letter"><img class="format-img-letter" src="../../../../src/assets/Images/ic_markunread_24px.png" alt="">
                                          Email: ${
                                            data.Email
                                          }</p>
                                      </div>
                                      <div class="col-sm-12  mgl-col-content2-right-below format-mt-item">
                                          <p><img class="format-img-place" src="../../../../src/assets/Images/ic_place_24px.png" alt="">
                                          Địa chỉ: ${
                                            data.diachi
                                          }</p>
                                      </div>
                                      <div class="col-sm-12 mgl-col-content2-right-below col-muctieu">
                                          <h5 class="card-title format-text-bold">Mục tiêu nghề nghiệp</h5>
                                          <span><p class="p-muctieu">${
                                            data.muctieunghenghiep
                                          }</p></span>
                                      </div>
                                      <div class="col-sm-12 mgl-col-content2-right-below col-hocvan">
                                          <h5 class="card-title format-text-bold">Học vấn</h5>
                                          <span><p class="p-hocvan">${
                                            data.hocvan
                                          }</p></span>
                                      </div>
                                      <div class="col-sm-12 mgl-col-content2-right-below col-kynang">
                                          <h5 class="card-title format-text-bold">Kỹ năng</h5>
                                          <span><p class="p-kynang">${
                                            data.Kynang
                                          }</p></span>
                                      </div>
                                      <div class="col-sm-12 mgl-col-content2-right-below col-kinhnghiem">
                                          <h5 class="card-title format-text-bold">Kinh nghiệm làm việc</h5>
                                          <span><p class="p-kinhnghiem">${
                                            data.kinhnghiem
                                          }</p></span>
                                      </div>
                                      <div class="col-sm-12 mgl-col-content2-right-below col-linhvuc">
                                      <h5 class="card-title format-text-bold">Lĩnh vực</h5>
                                      <span>
                                          <p class="p-linhvuc">
                                              ${data.linhvuc}
              
                                          </p>
                                      </span>
                                  </div>
                                      <div class="col-sm-12 mgl-col-content2-right-below col-chitiet">
                                          <h5 class="card-title format-text-bold">Chi tiết</h5>
                                          <span><p class="p-chitiet">${
                                            data.chitiet
                                          }</p></span>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <button onclick="updateUser(dataG)" class="btn btn-primary col-sm-8 mx-auto" > Cập nhật thông tin cá nhân</button>
      `;
    ele.html(res);

    console.log(c)
    $('select[name="thanhpho"]').each(function() {
      var $this = $(this),
        stc = ''
      c.forEach(function(i, e) {
        stc += '<option>' + i + '</option>'
        if (address_1 = localStorage.getItem('address_1_saved')) {
          $('select[name="thanhpho"] option').each(function() {
            if ($(this).text() == address_1) {
              $(this).attr('selected', '')
            }
          })
        }
      })
      $(this).append(stc)
    })

  $("#formUpdateUser").submit(function (e){
    e.preventDefault();
    // Lấy dữ liệu từ biểu mẫu
    var formData = $(this).serialize();
    // Gửi yêu cầu AJAX đến server
    $.ajax({
      url: $(this).attr('action'),
      type: $(this).attr('method'),
      data: formData,
      success: function(response) {
        const res = JSON.parse(response)
        if (res.status === 1) {
          // Xử lý thành công
          console.log('Success!');
          // Tạo một cửa sổ thông báo với nội dung và tiêu đề tùy chỉnh
          Swal.fire({
            title: 'Success',
            text: "Cập nhật thành công!",
            icon: 'success',
            showCancelButton: false,
            // cancelButtonColor: '#d33',
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'OK!'
          }).then((result) => {
            if (result) {
              // Xử lý khi người dùng chọn OK
              window.location.reload(true);
            }
          })
        } else {
          // Xử lý lỗi
          console.log('Error!');
        }
      },
      error: function(xhr) {
        // Xử lý lỗi khi gửi yêu cầu AJAX
        console.log(xhr.responseText);
      }
    });


})

  }
</script>

<!-- api để lấy dữ liệu tỉnh của việt nam -->
  <script src='https://cdn.jsdelivr.net/gh/vietblogdao/js/districts.min.js'></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Nhúng sweetalert2 từ CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>
</html>