<?php
    include("database.php");
    $result = sendActivationEmail('havyd7@gmail.com', 'hello');
    var_dump( $result );