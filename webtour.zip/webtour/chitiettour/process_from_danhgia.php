<?php
$servername = "localhost"; 
$username = "root"; 
$password = "";
$dbname = "tour5"; 

// Tạo kết nối
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


session_start();
$_SESSION['userid'] = 1;
if(isset($_SESSION['userid'])) {
    $userid = $_SESSION['userid'];
} else {
    header("Location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["idbaidang"])) {
        $tourid = $_POST["idbaidang"];
        $tenuser = $_POST["username"];
        $rating = $_POST["rating"];
        $cmt = $_POST["comment"];

        $sql = "INSERT INTO danhgia (tourid, tenuser, rating, cmt, userid) VALUES ('$tourid', '$tenuser', '$rating', '$cmt', '$userid')";
        
        if ($conn->query($sql) === TRUE) {
            echo "<h1>Đánh giá được gửi thành công</h1>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Missing tourid";
    }
}

$conn->close();
?>




