<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tour</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css"/>
  <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>



  <style>
    *{
      padding: 0;
      margin: 0;
      text-decoration: none;
      list-style: none;
      box-sizing: border-box;
  }
  
  

  .image{
      display: flex;
  }
  
  .icon a{
      color: white;
  }
  
  .icon a:hover{
      color: gray;
  }
  
  .form{
      display: inline-block;
  }
  
  .divider {
      height: 95%; 
      width: 1px;
      background-color: black; 
      margin: 0 auto;
  }
  .custom-btn {
    border-color: white; 
    color: black; 
}

.custom-btn:hover {
    background-color: rgba(211, 210, 210, 0.578); 
    color: rgb(0, 0, 0); 
}
  
  .footer ul{
      display: inline-block;
  }
    .card-text {
        font-family: 'Times New Roman', Times, serif;
    }

    .card-title {
        font-family: 'Times New Roman', Times, serif;
    }

    .ui-datepicker {
        background-color: rgb(240, 245, 247); 
    }
    .ui-datepicker {
        width: 220px; 
        font-size: 14px; 
    }
    
    .ui-datepicker-calendar {
        font-size: 14px; 
        color: black; 
    }
    
    .ui-datepicker-calendar tbody td {
        padding: 8px;
        color: black;
    }
    .ui-datepicker-calendar tbody td a{
        color: black; 
        text-decoration: none;
    }
    .pt {
        width: 300px; 
        height: 380px; 
    }
    .horizontal-line {
        width: 150px; 
        height: 2px; 
        background-color: black; 
        margin: 0 auto; 
        margin-top: 10px;
    }

    a h5 b:hover{
        text-decoration: none;
    }


    
    

</style>
</head>
<body>

  <div class="header">
      
  <script>
      $(function(){
          $(".header").load("../chitiettour/header.php");
      });
  </script>
  </div>


<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tour5";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}
if (isset($_GET["idbaidang"])) {
    $idbaidang = $_GET["idbaidang"];

    $sql = "SELECT * FROM tour WHERE tourid = '$idbaidang'";
    $result = $conn->query($sql);
    $results = $result->fetch_assoc();

    $columns_info = array();

    // Truy vấn SQL để lấy thông tin về các cột có tiền tố là "ngay"
    $sql_columns = "SELECT COLUMN_NAME
                FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = 'tour5'
                AND TABLE_NAME = 'tour'
                AND COLUMN_NAME LIKE 'ngay%'";

    
$result_columns = $conn->query($sql_columns);


if (!$result_columns) {
die("Lỗi trong truy vấn: " . $conn->error);
}


$columns_info = array();

if ($result_columns->num_rows > 0) {
    while ($row = $result_columns->fetch_assoc()) {
        $column_name = $row["COLUMN_NAME"];
        $columns_info[$column_name] = true;
    }
}




echo '
<div class="body">
    <div class="container">
        <div class="tieude">
            <center><h1 style="font-family: \'Times New Roman\', Times, serif;padding: 20px;"><b>' . $results['tentour'] . '</b></h1></center>
        </div>
            <div class="row">
                <div class="col-md-8" style="background-color: rgb(246, 249, 245);padding-top: 10px">
                    <img src="../image/' . $results['image'] . '" alt="" class="img-fluid" style="width: auto;">
                    <div class="tua" style="margin: 20px 10px; background-color: white;">
                        <div class="container">
                            <h2 style="padding-top: 10px; padding-bottom: 10px">' . $results['chitiet'] . '</h2>
                            <p style="padding-bottom: 10px;">' . $results['ndchitiet'] . '</p>
                        </div>
                    </div>
                    <div class="chuongtrinh" style="margin: 20px 10px; background-color: white;padding-bottom: 20px">
                        <div class="container">
                            <h2>Chương trình tour</h2>';


            $column_exist = false; // Biến flag để kiểm tra xem có ngày nào có dữ liệu không

for ($i = 1; $i <= 7; $i++) {
    $column_name = 'ngay'.$i;
    if (array_key_exists($column_name, $columns_info)) {
        // Tạo câu lệnh SQL chỉ lấy dữ liệu cho ngày hiện tại
        $sql = "SELECT $column_name, nd$column_name, image$column_name FROM tour WHERE tourid = $idbaidang AND $column_name IS NOT NULL";
        
        $result = $conn->query($sql);
        
        if (!$result) {
            die("Lỗi truy vấn: " . $conn->error);
        }
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            echo '<div class="ngay'.$i.'">
                        <h3>'.$row[$column_name].'</h3>
                        <p>'.$row['nd'.$column_name].'</p>
                        <img src="../image/'.$row['image'.$column_name].'" alt="" class="img-fluid d-block mx-auto" style="width: auto;">
                    </div>';
            
            $column_exist = true; 
        }
    }
}

// Nếu không có ngày nào có dữ liệu, hiển thị thông báo
if (!$column_exist) {
    echo "Không có thông tin chương trình tour.";
}

            
echo '</div>
        </div>
        <div class="chinhsach" style="margin: 20px 10px; background-color: white;padding-bottom: 20px">
            <div class="container">
                <h2><i class="fa-solid fa-bookmark"></i> Chính sách trẻ em</h2>
                <p>Trẻ em từ 2 tuổi trở xuống: miễn giá tour (cha mẹ tự lo cho bé). Trẻ em từ 2 -> 12 tuổi: 75% giá tour, bao gồm các dịch vụ ăn uống, ghế ngồi, tham quan cho bé. Trẻ em từ 12 tuổi trở lên: 100% giá tour như người lớn.</p>
            </div>
        </div>
    </div>
    

<div class="col-md-4 d-flex flex-column">
                        <h3 class="text-center">Lịch trình và Giá tour</h3>
                        <p>Chọn lịch trình và xem giá:</p>
                        <div class="banggia border rounded" style="background-color: rgb(246, 249, 245);">
                            <div class="nguoilon border p-3 mb-3 rounded" style="margin: 10px; background-color: white;">
                                <div class="row align-items-center">
                                    <div class="col-md-5">
                                        <p class="text-center m-0">Người lớn <br><span style="color: gray"> > 12 tuổi</span></p>
                                    </div>
            
                                    <div class="col-md-3">
                                        <p class="text-center m-0">' . $results['giatour'] . '$</p>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="quantity d-flex justify-content-center">
                                            <button class="btn btn-sm btn-secondary minus">-</button>
                                            <span class="count mx-2">0</span>
                                            <button class="btn btn-sm btn-secondary plus">+</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                

                            <div class="treem border p-3 mb-3 rounded"  style="margin: 10px; background-color: white;">
                                <div class="row align-items-center">
                                    <div class="col-md-5">
                                        <p class="text-center m-0">
                                        Trẻ em <br>
                                        <span style="color: gray"> 2 -> 12 tuổi</span>
                                        </p>
                                    </div>
                                    <div class="col-md-3">
                                        <p class="text-center m-0">' . ($results['giatour'] *0.75). '$</p>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="quantity d-flex justify-content-center">
                                            <button class="btn btn-sm btn-secondary minus">-</button>
                                            <span class="count mx-2">0</span>
                                            <button class="btn btn-sm btn-secondary plus">+</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
            

                            <div class="trenho border p-3 mb-3 rounded"  style="margin: 10px; background-color: white;">
                                <div class="row align-items-center">
                                    <div class="col-md-5">
                                        <p class="text-center m-0">
                                        Trẻ nhỏ <br>
                                        <span style="color: gray">&lt; 2 tuổi</span>
                                        </p>
                                    </div>
                                    <div class="col-md-3">
                                        <p class="text-center m-0">0$</p>
                                    </div>
                                <div class="col-md-4">
                                    <div class="quantity d-flex justify-content-center">
                                        <button class="btn btn-sm btn-secondary minus">-</button>
                                        <span class="count mx-2">0</span>
                                        <button class="btn btn-sm btn-secondary plus">+</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="total" style = "padding-bottom: 10px;">
                            <div class="container">
                                <div class="thongke">
                                    <div class="row">
                                        <div class="col-md-6">
                                            Tổng số lượng: <span>12</span>
                                        </div>
                                    <div class="col-md-6">
                                        Tổng tiền: <span>360214$</span>
                                    </div>
                                </div>
                            </div>
                    
                            <div class="thanhtoan">
                                <div class="row">
                                    <div class="col-md-6"  style = "padding-top: 10px;">
                                        <button type="submit" class="btn btn-danger">Thêm vào giỏ hàng</button>
                                    </div>
                                    <div class="col-md-6"  style = "padding-top: 10px;">
                                        <button type="submit" class="btn btn-success">Thanh Toán</button>
                                    </div>
                                </div>
                            </div>
                    
                        </div>
                    </div>
                </div>
</div>';
}

// Đóng kết nối
$conn->close();
?>

</body>