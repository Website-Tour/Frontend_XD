<!DOCTYPE html>
<html>
<head>
    <title>Ví dụ phân trang trong PHP và MySQL</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css"/>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>

    <style>
        .pt {
            width: auto;
            height: 380px;
        }
        .custom-btn {
            background-color: rgba(211, 210, 210, 0.578); 
            border-color: white;
            color: white;
            text-align: center;
        }
        .custom-btn:hover {
            background-color: #bbb;
            color: white;
        }
        .card-text {
            font-family: 'Times New Roman', Times, serif;
        }
        .card-title {
            font-family: 'Times New Roman', Times, serif;
        }
    .pagination a {
        color: #007bff; 
        text-decoration: none; 
        margin: 0 5px; 
    }

    .pagination a:hover {
        color: #0056b3;
    }

    
    </style>
</head>
<body>

<div>
    <div class="row" style ="position: relative;" id="tour-container">
        <?php require_once ('main/connect.php');

        $total_records = $dbCon->query('SELECT count(tourid) as total FROM tour')->fetchColumn();
        $limit = 4;
        $total_pages = ceil($total_records / $limit);
        $current_page = isset($_GET['page']) && is_numeric($_GET['page']) ? $_GET['page'] : 1;

        if ($current_page < 1) {
            $current_page = 1;
        } elseif ($current_page > $total_pages) {
            $current_page = $total_pages;
        }

        $start = ($current_page - 1) * $limit;

        $stmt = $dbCon->prepare("SELECT * FROM tour LIMIT :start, :limit");
        $stmt->bindValue(':start', $start, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data as $tour) {
            echo "<div class='col-md-6 mb-4'>";
            echo "<div class='card text-bg-dark'>";
            echo "<img src='image/{$tour['image']}' class='card-img image pt' alt='image/{$tour['image']}'>";
            echo "<div class='card-img-overlay'>";
            echo "<div class='card-title text-right text-light mb-auto' style = 'font-size: 15px; padding-bottom: 20%'>From {$tour['giatour']}$</div>";
            echo "<div class= 'flex-column h-100 justify-content-center'>";
            echo "<div class='text-center text-light'>";
            echo "<p class='card-text mb-2 text-left' style='font-size: 13px;'><i>{$tour['tendiadiem']}</i></p>";
            echo "<h5 class='card-title mb-3 text-center'style='font-size: 30px;'><b>{$tour['tentour']}</b></h5>";
            $start_date = new DateTime($tour['thoigiandi']);
            $end_date = new DateTime($tour['thoigianve']);
            $duration = $start_date->diff($end_date);
            echo "<div class='card-title text-left text-light' style='font-size: 15px;'><i class='far fa-clock'></i> {$duration->days} days</div>";

            echo "<div class='mt-3 text-center'>";
            echo "<button class='btn btn-outline-primary border border-white text-dark custom-btn'>More Information<i class='fa-solid fa-arrow-right'></i></button>";
            echo "</div>";
            echo "</div>"; 
            echo "</div>"; 
            echo "</div>"; 
            echo "</div>"; 
            echo "</div>"; 
        } ?>
    </div>

    <div id="pagination-container" class="pagination-container">
    <div class="pagination mt-3">
    <?php
    if ($total_pages > 1) {
        if ($current_page > 1) {
            echo "<a href='upload.php?page=" . ($current_page - 1) . "'>Prev</a> | ";
        }
        for ($i = 1; $i <= $total_pages; $i++) {
            if ($i == $current_page) {
                echo "<a href='#' class='page-link active'>{$i}</a> | "; // Sử dụng phần tử <a> thay vì <span>
            } else {
                echo "<a href='phantrang.php?page={$i}' class='page-link'>{$i}</a> | ";
            }
        }
        if ($current_page < $total_pages) {
            echo "<a href='phantrang.php?page=" . ($current_page + 1) . "'>Next</a> | ";
        }
    }
?>
    </div>
</div>

<script>
$(document).ready(function(){
    $(".pagination a.page-link").click(function(e){
        e.preventDefault();
        var page = $(this).text();
        $("#tour-container").load("phantrang.php?page=" + page + " #tour-container");
    });
});
</script>


</body>
</html>
