<footer class="footer bg-light py-5">
    <div class="container">
      <div class="d-flex align-items-center justify-content-between mb-4">
          <h2 class="title" style = "margin-bottom: 50px;">Quamon Travelling</h2>
          <div style = "margin-bottom: 50px;">
              <a href="#" style = "color: black"><i class="fab fa-facebook-square fa-2x"></i></a>
              <a href="#" style = "color: black"></a><i class="fab fa-instagram fa-2x"></i></a>
              <a href="#" style = "color: black"></a><i class="fab fa-linkedin fa-2x"></i></a>
          </div>
      </div>
      
        <div class="row">
            <div class="col-md-3">
                <h5>CONNECT WITH US</h5>
                <ul class="list-unstyled">
                    <li><a href="#" style = "color: black">Instagram</a></li>
                    <li><a href="#" style = "color: black">Twitter</a></li>
                    <li><a href="#" style = "color: black">Facebook</a></li>
                    <li><a href="#" style = "color: black">LinkedIn</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <h5>LOCATIONS</h5>
                <ul class="list-unstyled">
                    <li>Amsterdam Van Diemenstraat 38 1013NH Amsterdam The Netherlands</li>
                </ul>
            </div>
            <div class="col-md-3">
                <h5></h5>
                <ul class="list-unstyled">
                  <li> </li>
                    <li>OSLO </li>
                    <li>Trondheimssveien 1350570 Oslo Norway</li>
                </ul>
            </div>
            <div class="col-md-3">
                <h5></h5>
                <ul class="list-unstyled">
                  <li> </li>
                    <li>LONDON</li>
                    <li>23 Englefield Rd London N1 4JX United Kingdom</li>
                </ul>
            </div>
        </div>
    </div>
</footer>