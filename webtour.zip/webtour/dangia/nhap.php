<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tour5";

// Tạo kết nối đến cơ sở dữ liệu
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối đến cơ sở dữ liệu thất bại: " . $conn->connect_error);
}
// Xử lý khi gửi form đánh giá
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $rating = $_POST['rating'];
    $comment = $_POST['comment'];
    $tourid = $_POST['tourid'];

    $sql = "INSERT INTO danhgia (tenuser, rating, cmt, tourid) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql); // Sửa đổi ở đây
    $stmt->bind_param("sisi", $username, $rating, $comment, $tourid);
    
    if ($stmt->execute()) {
        echo "Đánh giá đã được thêm thành công!";
    } else {
        echo "Lỗi: " . $stmt->error;
    }
}

if (isset($_GET["idbaidang"])) {
  $idbaidang = $_GET["idbaidang"];
    // Truy vấn đánh giá từ cơ sở dữ liệu
    $sql = "SELECT * FROM danhgia WHERE tourid = idbaidang";
    $stmt = $conn->prepare($sql); // Sửa đổi ở đây
    $stmt->bind_param("i", $tourid);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo '<h3>Các đánh giá</h3><ul id="ratings" class="list-group">';
        while ($row = $result->fetch_assoc()) {
            echo '<li class="list-group-item">';
            echo '<strong>' . $row['tenuser'] . ': </strong>';
            for ($i = 1; $i <= $row['rating']; $i++) {
                echo '&#9733;';
            }
            echo '<br>' . $row['cmt'] . '</li>';
        }
        echo '</ul>';
    } else {
        echo "Chưa có đánh giá nào cho tour này.";
    }
}

// Đóng kết nối
$conn->close(); // Sửa đổi ở đây
?>

<h3>Các đánh giá</h3>
    <ul id="ratings" class="list-group">
      <?php if ($result->num_rows > 0) :
          while ($row = $result->fetch_assoc()) : ?>
            <li class="list-group-item">
              <strong><?php echo $row['username']; ?>: </strong>
              <?php for ($i = 1; $i <= $row['rating']; $i++) : ?>
                &#9733;
              <?php endfor; ?><br>
              <?php echo $row['comment']; ?>
            </li>
          <?php endwhile;
      endif; ?>
    </ul>
  </div>


  <?php
// Kết nối đến cơ sở dữ liệu MySQL
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tour5";

$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối đến cơ sở dữ liệu thất bại: " . $conn->connect_error);
}

// Xử lý khi form đánh giá được submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $rating = $_POST['rating'];
    $comment = $_POST['comment'];
    $tourid = $_POST['tourid'];

    // Thêm đánh giá vào cơ sở dữ liệu
    $sql = "INSERT INTO danhgia (tenuser, rating, cmt, tourid) VALUES ('$username', '$rating', '$comment', '$tourid')";

    if ($conn->query($sql) === TRUE) {
        echo "Đánh giá đã được thêm thành công!";
    } else {
        echo "Lỗi: " . $sql . "<br>" . $conn->error;
    }
}

// Lấy tourid từ URL
if(isset($_GET['tourid'])) {
    $tourid = $_GET['tourid'];
} else {
    $tourid = ""; // Đặt mặc định là rỗng nếu không có tourid từ URL
}