<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tour Rating</title>
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .rating {
      display: inline-block;
    }

    .rating input {
      display: none;
    }

    .rating label {
      font-size: 25px;
      color: #ccc;
      cursor: pointer;
    }

    .rating label:hover,
    .rating label:hover ~ label {
      color: #FFD700;
    }

    .rating input:checked ~ label,
    .rating input:checked ~ label ~ label {
      color: #FFD700;
    }

    .btn {
      margin-top: 10px;
    }
  </style>
</head>
<body>
<script>
    $(document).ready(function() {
        var idtour = <?php echo $idbaidang; ?>;
        $("#tourid").val(idtour);
        
        // Sự kiện khi thay đổi idtour
        $("#idbaidang").change(function() {
            idtour = $(this).val();
            $("#tourid").val(idtour);
        });
    });
</script>

<div class="container mt-5">
    <h2>Đánh giá tour</h2>
    <!-- Form để thêm đánh giá mới -->
    <form id="ratingForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="form-group">
            <label for="username">Tên của bạn:</label>
            <input type="text" class="form-control" id="username" name="username" required>
        </div>
        <div class="form-group">
            <label for="rating">Đánh giá:</label>
            <div class="rating">
                <?php for ($i = 5; $i >= 1; $i--) : ?>
                    <input type="radio" id="star<?php echo $i; ?>" name="rating" value="<?php echo $i; ?>">
                    <label for="star<?php echo $i; ?>">&#9733;</label>
                <?php endfor; ?>
            </div>
        </div>
        <div class="form-group">
            <label for="comment">Bình luận:</label>
            <textarea class="form-control" id="comment" name="comment" rows="3" required></textarea>
        </div>
        <input type="hidden" id="tourid" name="tourid" value=""> <!-- Trường ẩn để lưu tourid -->
        <button type="submit" class="btn btn-primary">Gửi đánh giá</button>
    </form>
</div>



    <?php
    require_once ('../main/connect.php'); 

    if (isset($_GET["idbaidang"])) {
        $idbaidang = $_GET["idbaidang"];
    
        $sql = "SELECT * FROM danhgia WHERE tourid = '$idbaidang'";
    
        $stmt = $dbCon->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        

        foreach ($results as $tour) {
          echo '<h3>Các đánh giá</h3><ul id="ratings" class="list-group">';
            foreach ($results as $row) {
              echo '<li class="list-group-item">';
              echo "<strong>" . $row["tenuser"] . ": </strong>";
            for ($i = 1; $i <= $row["rating"]; $i++) {
              echo "&#9733;";
        }
        echo "<br>" . $row["comment"];
        echo '</li>';
    }
    echo '</ul>';

        }
    }    
    ?>


  <!-- Bootstrap JS và jQuery -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
// Đóng kết nối đến cơ sở dữ liệu
// $conn->close();
?>
