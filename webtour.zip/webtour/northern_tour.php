<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css"/>
  <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<style>
    .horizontal-line {
        width: 150px; 
        height: 2px; 
        background-color: black; 
        margin: 0 auto; 
        margin-top: 10px;
    }
</style>
</head>
<body>

<?php
require_once ('main/connect.php'); 

$sql = "SELECT * FROM tour WHERE area LIKE 'Northern Viet Nam' LIMIT 6";

$stmt = $dbCon->prepare($sql);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo '<div class = "row">';
    foreach ($results as $row) {
      echo '<div class="col-md-4">'; // Start of column
      echo '<div class="card mb-4">';
        echo '<div class="card" style="background-color: rgb(225, 225, 225);">';
        echo '<img class="card-img-top" style = "width: auto; height: 250px" src="image/' . $row["image"] . '" alt="">';
        echo '<div class="card-body">';
        echo '<p class="card-text">' . $row["tendiadiem"] . '</p>';
        echo '<h5 class="card-title"><b>' . $row["tentour"] . '</b></h5>';
        $start_date = new DateTime($row['thoigiandi']);
        $end_date = new DateTime($row['thoigianve']);
        $duration = $start_date->diff($end_date);
        echo '<p class="card-text"><i class="far fa-clock"></i> ' . $duration->days . ' days</p>';
        echo '<center><div class="horizontal-line"></div></center>';
        echo '<div class="row">';
        echo '<div class="col-md-4 card-text">' . $row["giatour"] . '$</div>';
        echo '<div class="col-md-8 card-text" style="padding-left: 50px"><a href="">More Information<i class="fa-solid fa-arrow-right" style="padding-left: 10px"></i></a></div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
} 
echo '</div>';
?>

<div id="footer">
    <?php include 'main/footer_tour.php'; ?>
  </div>
</body>
</html>