<?php
// start session
session_start();
 
// include classes
include_once "config/database.php";
include_once "objects/tour.php";
include_once "objects/tour_image.php";
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// initialize objects
$tour = new Tour($db);
$tour_image = new Tour_imaget($db);
    // get ID of the tour to be edited
    $id = isset($_GET['id']) ? $_GET['id'] : die('ERROR: missing ID.');
    
    // set the id as product id property
    $tour->id = $id;
    
    // to read single record product
    $tour->readOne();
    
    // set page title
    $page_title = $tour->name;
    
    $tour_image->tour_id=$id;
 
    // read all related product image
    $stmt_tour_image = $tour_image->readByProductId();
    
    // count all relatd product image
    $num_tour_image = $stmt_tour_image->rowCount();
 
// include page header HTML
include_once 'header.php';
    echo "<div class='col-md-1'>";
    // if count is more than zero
    if($num_tour_image>0){
        // loop through all product images
        while ($row = $stmt_tour_image->fetch(PDO::FETCH_ASSOC)){
            // image name and source url
            $tour_image_name = $row['name'];
            $source="uploads/images/{$tour_image_name}";
            echo "<img src='{$source}' class='tour-img-thumb' data-img-id='{$row['id']}' />";
        }
    }else{ echo "No images."; }
    echo "</div>";

    // product image will be here
    echo "<div class='col-md-4' id='product-img'>";

    // read all related product image
    $stmt_tour_image = $tour_image->readByProductId();
    $num_tour_image = $stmt_tour_image->rowCount();

    // if count is more than zero
    if($num_tour_image>0){
    // loop through all product images
    $x=0;
    while ($row = $stmt_tour_image->fetch(PDO::FETCH_ASSOC)){
        // image name and source url
        $tour_image_name = $row['name'];
        $source="uploads/images/{$tour_image_name}";
        $show_tour_img=$x==0 ? "display-block" : "display-none";
        echo "<a href='{$source}' target='_blank' id='tour-img-{$row['id']}' class='tour-img {$show_tour_img}'>";
            echo "<img src='{$source}' style='width:100%;' />";
        echo "</a>";
        $x++;
    }
    }else{ echo "No images."; }
    echo "</div>";

    // product details will be here
    echo "<div class='col-md-5'>";

    echo "<div class='tour-detail'>Price:</div>";
    echo "<h4 class='m-b-10px price-description'>$" . number_format($tour->price, 2, '.', ',') . "</h4>";

    echo "<div class='tour-detail'>Tour description:</div>";
    echo "<div class='m-b-10px'>";
        // make html
        $page_description = htmlspecialchars_decode(htmlspecialchars_decode($tour->description));

        // show to user
        echo $page_description;
    echo "</div>";

    echo "<div class='product-detail'>Product category:</div>";
    echo "<div class='m-b-10px'>{$tour->category_name}</div>";

    echo "</div>";

    echo "<div class='col-md-2'>";

    // if product was already added in the cart
    if(array_key_exists($id, $_SESSION['cart'])){
    echo "<div class='m-b-10px'>This tour is already in your bag.</div>";
    echo "<a href='bag.php' class='btn btn-success w-100-pct'>";
        echo "Update Bag";
    echo "</a>";

    }

    // if product was not added to the cart yet
    else{

    echo "<form class='add-to-bag-form'>";
        // product id
        echo "<div class='tour-id display-none'>{$id}</div>";

        echo "<div class='m-b-10px f-w-b'>Quantity:</div>";
        echo "<input type='number' value='1' class='form-control m-b-10px bag-quantity' min='1' />";

        // enable add to cart button
        echo "<button style='width:100%;' type='submit' class='btn btn-primary bag-to-bag m-b-10px'>";
            echo "<span class='glyphicon glyphicon-shopping-bag'></span> Add to bag";
        echo "</button>";

    echo "</form>";
    }
    echo "</div>";
    

// include page footer HTML
include_once 'footer.php';
?>

