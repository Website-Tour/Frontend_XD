<?php
// 'product image' object
class Tour_imaget{
 
    // database connection and table name
    private $conn;
    private $table_name = "tour_images";
 
    // object properties
    public $id;
    public $tour_id;
    public $name;
    public $timestamp;
 
    // constructor
    public function __construct($db){
        $this->conn = $db;
    }

    function readFirst(){
 
        // select query
        $query = "SELECT id, tour_id, name
                FROM " . $this->table_name . "
                WHERE tour_id = ?
                ORDER BY name DESC
                LIMIT 0, 1";
     
        // prepare query statement
        $stmt = $this->conn->prepare( $query );
     
        // sanitize
        $this->id=htmlspecialchars(strip_tags($this->id));
     
        // bind prodcut id variable
        $stmt->bindParam(1, $this->tour_id);
     
        // execute query
        $stmt->execute();
     
        // return values
        return $stmt;
    }

    // read all product image related to a product
function readByProductId(){
 
    // select query
    $query = "SELECT id, tour_id, name
            FROM " . $this->table_name . "
            WHERE tour_id = ?
            ORDER BY name ASC";
 
    // prepare query statement
    $stmt = $this->conn->prepare( $query );
 
    // sanitize
    $this->tour_id=htmlspecialchars(strip_tags($this->tour_id));
 
    // bind prodcut id variable
    $stmt->bindParam(1, $this->tour_id);
 
    // execute query
    $stmt->execute();
 
    // return values
    return $stmt;
}
}