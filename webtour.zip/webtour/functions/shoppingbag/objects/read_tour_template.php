<?php
if(!isset($_SESSION['cart'])){
    $_SESSION['cart']=array();
}

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
    extract($row);
    $name = $row['name'];
    $id = $row['id'];
    // creating box
    echo "<div class='col-md-4 m-b-20px'>";

    // product id for javascript access
    echo "<div class='tour-id display-none'>{$id}</div>";

    echo "<a href='tour.php?id={$id}' class='tour-link'>";
        // select and show first product image
        $tour_image->tour_id=$id;
        $stmt_tour_image=$tour_image->readFirst();

        while ($row_tour_image = $stmt_tour_image->fetch(PDO::FETCH_ASSOC)){
            echo "<div class='m-b-10px'>";
                echo "<img src='uploads/images/{$row_tour_image['name']}' class='w-100-pct' />";
            echo "</div>";
        }

        // product name
        echo "<div class='tour-name m-b-10px'>{$name}</div>";
    echo "</a>";

    // add to cart button
    echo "<div class='m-b-10px'>";
        if(array_key_exists($id, $_SESSION['cart'])){
            echo "<a href='cart.php' class='btn btn-success w-100-pct'>";
                echo "Update Cart";
            echo "</a>";
        }else{
            echo "<a href='add_to_cart.php?id={$id}&page={$page}' class='btn btn-primary w-100-pct'>Add to Cart</a>";
        }
    echo "</div>";

    echo "</div>";
}

 
include_once "paging.php";
?>
