<?php
// start session
session_start();
 
// connect to database
include 'config/database.php';
 
// include objects
include_once "objects/tour.php";
include_once "objects/tour_image.php";
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// initialize objects
$tour = new Tour($db);
$tour_image = new  Tour_imaget($db);
 
// set page title
$page_title="Bag";
 
// include page header html
include 'include/header.php';
 
// contents will be here 
 
// layout footer
include 'include/footer.php';
?>